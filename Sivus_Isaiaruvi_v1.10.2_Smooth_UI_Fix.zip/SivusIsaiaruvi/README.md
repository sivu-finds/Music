# Sivu’s Isaiaruvi v1.10.2

Incremental UI responsiveness and playback interaction update.

## Changes in this build
- Library category changes retain the current search text and reset pagination predictably.
- Album list/grid switch is shown only in the Albums category.
- Artist results are paginated instead of building every artist row at once.
- Similar Songs popup no longer includes its search field; tapping a recommendation dismisses the popup before playback starts.
- Added a short fade-in on screen redraws and a swipe cooldown to reduce accidental repeated track changes.
- Removed per-row synchronous play-history database counts from the song list.
- Removed an immediate redundant screen redraw when playback starts; screen updates after MediaPlayer is prepared.

## Build status
This ZIP has not been compiled in an Android/Gradle environment. Run the repository GitHub Actions workflow and inspect its result before installing the APK. The fade animation is intentionally subtle; it does not replace a full UI architecture rewrite or a dedicated background playback service.

# Sivu's Isaiaruvi — v1.15.0 UX interaction pass

This pass is based on observed local-library use and publicly documented Wynk patterns. Airtel's public Wynk FAQ describes search across singer/artist and film/album names, playlists, local music and radio; public marketing material also shows a home feed with local MP3 access and album collections. It does not expose a complete private design specification, so this project uses familiar interaction conventions without copying proprietary assets.

## Interaction changes
- Tap an album, artist, year, folder, or playlist to open a collection-detail view with its tracks.
- Long-press collection cards to open Play collection, Shuffle collection, Add all to queue, and Create playlist from collection actions.
- Search stays in Search while changing Songs / Albums / Artists / Folders modes. Tapping an album or artist opens its contents instead of switching to Library.
- Collection detail has Back, Play, Shuffle, More actions, and a collection-specific filter.
- Leaving a collection through bottom navigation clears the detail state; Android Back returns from collection detail first.
- Library categories use a bounded number of visible rows where applicable to reduce expensive view creation.

## Verification status
- ZIP archive integrity should be checked after packaging.
- Android compilation and real-device responsiveness have not been verified in this environment; run the repository's GitHub Actions workflow and test on the target phone before treating this build as release-ready.

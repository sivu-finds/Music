# Sivu's Isaiaruvi — PocketBuilder project

A native Android local music player project for importing into an Android build app such as PocketBuilder.

## Import/build
1. Download this ZIP to your Android phone.
2. In PocketBuilder, choose its option to import/open an existing Android project or source ZIP.
3. Select this ZIP (or extract it first if PocketBuilder requires a folder).
4. Open the project folder `SivusIsaiaruvi` — the folder containing `settings.gradle.kts`.
5. Allow the builder to sync/download the Android Gradle plugins, then build an APK.
6. Install the APK and grant music/audio access when prompted.

If PocketBuilder only accepts a single source file or a web project, it may not support this native Kotlin/Gradle project format. Choose its existing Android/Gradle project import mode if available.

## App features
- Scans local music stored on the device
- Searchable song library
- Smart shuffle biased toward less-played songs and away from recent repeats
- Similar-song radio based on artist, album and title keywords
- Listening history and play-count insights by date range
- Compact emerald-and-white interface with a persistent mini-player

## Project details
- Native Android app written in Kotlin
- Gradle Kotlin DSL
- Namespace/application ID: `com.melo.localmusic`
- Minimum Android version: Android 8.0 (API 26)
- Version: 1.1.0

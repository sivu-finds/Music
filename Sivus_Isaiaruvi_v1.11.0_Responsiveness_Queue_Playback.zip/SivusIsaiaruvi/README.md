# Sivu’s Isaiaruvi v1.11.0

Incremental responsiveness, queue, discovery and playback-control update.

## Changes in this build
- Similar Songs has no search field; selecting a recommendation closes the popup before playback. The overflow menu’s Play now action also dismisses it.
- Queue is a scrollable, paginated list instead of a single AlertDialog item array containing up to 1,363 tracks.
- Song Radio picker sorts songs, albums and artists, starts with a manageable page, and has Load more plus search across song title, album/movie and artist.
- Smart Shuffle reads play counts and last-played timestamps in one grouped database query rather than thousands of individual queries.
- Insights per-song counts and Auto Mix ordering use one grouped play-history query.
- Now Playing shuffle offers normal shuffle, Smart Shuffle, and shuffle off. Repeat cycles through Off, Repeat all, and Repeat one.
- Library category search state and album List/Grid control are retained as before.

## Build status
This source ZIP has not been compiled or tested on a physical Android device. Run the GitHub Actions build workflow and inspect the result before installing. These changes reduce several known expensive UI-thread operations but are not a guarantee that all ANRs or transition issues are solved. A complete long-term fix would involve moving to a lifecycle-aware list UI and a dedicated background playback service.

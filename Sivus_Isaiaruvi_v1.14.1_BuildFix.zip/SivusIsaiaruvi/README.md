# Sivu's Isaiaruvi — v1.14.0 Music-first UX rebuild

Android local music player project for the existing GitHub Actions APK workflow.

## Visual and navigation direction
- Adaptive light/dark palette with red as the default accent and selectable accent colours.
- Music-first bottom navigation: Home, Search, Library, Profile/Settings.
- Home provides quick search, Smart Shuffle and Song Radio entry points.
- Search is a dedicated screen for local song, artist, album/movie and path matching, with quick category navigation.
- Profile groups listening insights, settings, queue, library scan, and app information.
- Library retains Songs, Albums, Artists, Years, Folders, Playlists and Auto mixes, plus album List/Grid display.
- Now Playing retains queue, playlist, similar songs, shuffle and repeat controls.

## Responsiveness improvements
- Avoid the full-screen fade that made every refresh appear to blink.
- Keep the app shell and mini-player mounted when switching between main sections.
- Refresh the active content area instead of replacing the activity for tab and category changes.
- Preserve the content scroll position on same-section refreshes where possible.
- Avoid a whole-screen redraw on ordinary track completion.
- Keep lists capped/paginated where the existing screen supports it.

## Existing functionality retained
- Local MediaStore scanning, listening history and 80% listened tracking logic (without the explanatory label in the UI).
- Song Radio picker with Songs, Albums, Artists, search and load-more.
- Similar Songs recommendations, queue, playlists, smart shuffle, sleep timer, playback speed, device equalizer presets, folder exclusions and theme/accent preferences.

## Build
Upload the project files to the existing repository and keep `.github/workflows/build-apk.yml`. Run the workflow and download the APK artifact only if the job succeeds.

## Verification status and limitations
The ZIP archive integrity was checked. This environment does not include the Android SDK or a configured Gradle build, so **the APK has not been compiled or tested on a physical device here**. GitHub Actions must verify compilation, followed by testing on the target Samsung device.

This is a broader UX/navigation pass, not yet a full production audio-engine rewrite. Playback still uses the legacy `MediaPlayer` API in the activity; a dedicated foreground Media3 playback service, robust gapless/crossfade playback, lyrics, ReplayGain and device-level transition/performance testing remain future work. Device equalizer availability depends on the Android audio effects provided by the device.

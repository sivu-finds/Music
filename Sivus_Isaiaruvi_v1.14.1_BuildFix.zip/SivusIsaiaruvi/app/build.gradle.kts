plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.melo.localmusic"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.melo.localmusic"
        minSdk = 26
        targetSdk = 35
        versionCode = 15
        versionName = "1.14.0"
    }
}

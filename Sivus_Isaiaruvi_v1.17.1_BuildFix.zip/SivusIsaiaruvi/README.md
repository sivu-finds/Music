# Sivu's Isaiaruvi — v1.17.0 stability and discovery candidate

Android local music player for the existing GitHub Actions APK workflow.

## This release candidate
- Keeps the music-first Home / Search / Library / Profile navigation and collection-detail interactions.
- Collection tap opens contents; long-press offers Play collection, Shuffle collection, Add all to queue, and Create playlist from collection.
- Search remains in Search when opening album/artist/folder results.
- Similar Songs uses metadata-based relevance scoring, randomized weighted selection, artist/album diversity penalties, and per-seed recommendation memory to avoid repeating the same batch immediately.
- Reads listening-history stats in a grouped query rather than issuing per-track database queries for each candidate.
- Keeps same album/movie excluded by default.

## Build and test
Use the matching workflow file `build-apk-v1.17.0.yml` provided alongside this project ZIP. Copy it to `.github/workflows/build-apk.yml` in the GitHub repository. It selects this exact versioned ZIP instead of arbitrarily building the first ZIP found.

The project ZIP has been integrity-checked. **This environment does not have a configured Android SDK/Gradle build, so this APK has not been compiled or device-tested here. Do not treat this candidate as confirmed stable until GitHub Actions succeeds and the resulting APK is tested on the phone.**

## Known scope
This is not yet a complete production audio-engine rewrite. Playback still uses Android `MediaPlayer` inside the activity; a dedicated Media3 foreground playback service and physical-device regression testing remain necessary for production-grade background playback, gapless playback and transition behavior. Similarity is based on local metadata (artist, album/movie, title words, year and inferred mood tags), not audio fingerprinting or acoustic embeddings, because the local library does not provide those features by default.

# Sivu's Isaiaruvi v1.17.0 — UI/UX redesign candidate

## Design direction
- Unified Explore destination replaces separate Search and Library bottom tabs.
- Four primary destinations: Home, Explore, Insights, You.
- Explore includes Songs, Albums, Artists, Folders and Playlists with collection detail navigation.
- Header secondary actions are grouped into a single overflow menu.
- Home has a stronger headline, music-mix hero card and a more intentional hierarchy.
- Insights now leads with a high-contrast listening summary and proportional top-track bars; removed the duplicate all-library per-song stats list from the Insights screen.
- Search result rendering is debounced to avoid rebuilding result rows for every keystroke.
- Bottom navigation updates the existing content container rather than reconstructing the full Activity shell, reducing visible blink.

## Honest validation status
- ZIP archive integrity is checked separately.
- Android compilation/device performance has NOT been verified in this environment (Android SDK/Gradle executable unavailable).
- No UI redesign can honestly guarantee zero lag across all devices without profiling the actual APK on the target phone. This candidate reduces avoidable work and changes the interaction hierarchy, but it still requires GitHub Actions compilation and real-device scrolling/navigation/playback tests.

package com.melo.localmusic

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

private const val GREEN = 0xFF18794E.toInt()
private const val INK = 0xFF17221C.toInt()
private const val MUTED = 0xFF748078.toInt()
private const val PALE = 0xFFF2F7F3.toInt()
private const val DEEP = 0xFF0D3828.toInt()
private const val MINT = 0xFFD8F3E3.toInt()
private const val REQ_AUDIO = 441

data class Track(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val durationMs: Long)

class PlayHistory(context: android.content.Context) : SQLiteOpenHelper(context, "sivus_isaiaruvi_history.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE plays(id INTEGER PRIMARY KEY AUTOINCREMENT, track_id INTEGER NOT NULL, title TEXT, artist TEXT, played_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX plays_date ON plays(played_at)")
        db.execSQL("CREATE INDEX plays_track ON plays(track_id)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun record(t: Track) { writableDatabase.execSQL("INSERT INTO plays(track_id,title,artist,played_at) VALUES(?,?,?,?)", arrayOf(t.id, t.title, t.artist, System.currentTimeMillis())) }
    fun count(id: Long): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM plays WHERE track_id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    fun lastPlayed(id: Long): Long = readableDatabase.rawQuery("SELECT MAX(played_at) FROM plays WHERE track_id=?", arrayOf(id.toString())).use { if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else 0L }
    fun total(from: Long = 0L, to: Long = Long.MAX_VALUE): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM plays WHERE played_at>=? AND played_at<=?", arrayOf(from.toString(), to.toString())).use { if(it.moveToFirst()) it.getInt(0) else 0 }
    fun top(from: Long, to: Long): List<Pair<String,Int>> {
        val out = mutableListOf<Pair<String,Int>>()
        readableDatabase.rawQuery("SELECT title,COUNT(*) c FROM plays WHERE played_at>=? AND played_at<=? GROUP BY track_id ORDER BY c DESC LIMIT 8", arrayOf(from.toString(),to.toString())).use { c -> while(c.moveToNext()) out += (c.getString(0) ?: "Unknown") to c.getInt(1) }
        return out
    }
}

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var history: PlayHistory
    private val tracks = mutableListOf<Track>()
    private var player: MediaPlayer? = null
    private var current: Track? = null
    private var queue = mutableListOf<Track>()
    private var queueIndex = 0
    private var tab = "Home"
    private var period = "Month"
    private var customDay = ""
    private var nowPlayingLabel: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        history = PlayHistory(this)
        window.statusBarColor = android.graphics.Color.WHITE
        window.navigationBarColor = android.graphics.Color.WHITE
        if (hasAudioPermission()) { scan(); render() } else requestAudioPermission()
    }
    private fun hasAudioPermission(): Boolean = if (Build.VERSION.SDK_INT >= 33) checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    private fun requestAudioPermission() { requestPermissions(arrayOf(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE), REQ_AUDIO) }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == REQ_AUDIO) { if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) { scan(); render() } else showPermissionScreen() } }

    private fun scan() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.IS_MUSIC)
        contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC}=1 AND ${MediaStore.Audio.Media.DURATION}>30000", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST); val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM); val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while(c.moveToNext()) { val id=c.getLong(idCol); tracks += Track(id, c.getString(titleCol) ?: "Unknown track", c.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "Unknown artist", c.getString(albumCol) ?: "", ContentUris.withAppendedId(collection,id), c.getLong(durCol)) }
        }
    }
    private fun showPermissionScreen() { root = LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(32,32,32,32); setBackgroundColor(-1) }; root.addView(text("Allow music access so Sivu's Isaiaruvi can find audio stored on your phone.",18f,INK)); root.addView(button("Grant music access") { requestAudioPermission() }); setContentView(root) }
    private fun text(s: String, size: Float=14f, color: Int=INK, bold: Boolean=false): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0,2,0,2) }
    private fun button(s: String, action: () -> Unit): Button = Button(this).apply {
        text=s
        textSize=13f
        isAllCaps=false
        minHeight=0
        minimumHeight=0
        minWidth=0
        minimumWidth=0
        setPadding(12,8,12,8)
        setTextColor(GREEN)
        background=android.graphics.drawable.GradientDrawable().apply {
            setColor(PALE)
            cornerRadius=14f
            setStroke(1,0xFFDCE9DF.toInt())
        }
        setOnClickListener { action() }
    }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation=1; setPadding(14,8,14,8); background = android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius=16f }; val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,4,0,4); layoutParams=p }
    private fun render() {
        root=LinearLayout(this).apply { orientation=1; setBackgroundColor(0xFFF8FAF8.toInt()) }
        val header=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(18,12,18,10) }
        val brand=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        brand.addView(text("SIVU’S  ISAIARUVI",18f,DEEP,true)); brand.addView(text("LOCAL MUSIC PLAYER",10f,MUTED,true))
        header.addView(brand); header.addView(button("⟳") { scan(); render() }); root.addView(header)
        val scroll=ScrollView(this).apply { isFillViewport=true }; val content=LinearLayout(this).apply { orientation=1; setPadding(16,4,16,14) }; scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        when(tab) { "Home" -> home(content); "Library" -> library(content); else -> insights(content) }
        val mini=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(12,8,12,8); background=android.graphics.drawable.GradientDrawable().apply { setColor(DEEP); cornerRadius=18f }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(12,4,12,6); layoutParams=lp }
        val trackName=if(current==null) "Choose a song to begin" else current!!.title
        val trackArtist=if(current==null) "Sivu’s Isaiaruvi" else current!!.artist
        val labels=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        labels.addView(text(trackName,13f,-1,true)); labels.addView(text(trackArtist,10f,0xFFBBD7C8.toInt()))
        mini.addView(labels); mini.addView(button("Ⅱ") { player?.pause() }); mini.addView(button("▶") { if(current!=null) { try { player?.start() } catch (_:Exception) { play(current!!) } } }); mini.addView(button("›") { next() }); root.addView(mini)
        val nav=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER; setPadding(10,3,10,8); setBackgroundColor(0xFFF8FAF8.toInt()) }
        listOf("Home","Library","Insights").forEach { t -> val selected=t==tab; val b=TextView(this).apply { text=(when(t){"Home"->"⌂";"Library"->"♫";else->"◷"})+"  "+t; textSize=12f; gravity=Gravity.CENTER; setTypeface(null,if(selected) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL); setTextColor(if(selected) -1 else MUTED); setPadding(6,11,6,11); background=android.graphics.drawable.GradientDrawable().apply { setColor(if(selected) GREEN else 0xFFF8FAF8.toInt()); cornerRadius=24f }; setOnClickListener { tab=t; render() } }; val lp=LinearLayout.LayoutParams(0,-2,1f); lp.setMargins(4,0,4,0); nav.addView(b,lp) }
        root.addView(nav); setContentView(root)
    }
    private fun home(c: LinearLayout) {
        val welcome=LinearLayout(this).apply { orientation=1; setPadding(2,8,2,12) }
        welcome.addView(text("Your sound, your space.",24f,DEEP,true)); welcome.addView(text("A little more discovery. A lot less repetition.",12f,MUTED)); c.addView(welcome)
        val hero=LinearLayout(this).apply { orientation=1; setPadding(16,14,16,13); background=android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,intArrayOf(DEEP,0xFF176343.toInt())).apply { cornerRadius=20f }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,10); layoutParams=lp }
        hero.addView(text("✦  SMART SHUFFLE",11f,MINT,true)); hero.addView(text("Find your next\nfavourite again.",23f,-1,true)); hero.addView(text("Underplayed tracks first. Recent repeats pushed back.",12f,0xFFD4E7DC.toInt())); val sh=button("  SHUFFLE MY LIBRARY  ↗  ") { smartShuffle() }; sh.setTextColor(DEEP); sh.setBackgroundTintList(android.content.res.ColorStateList.valueOf(MINT)); val blp=LinearLayout.LayoutParams(-2,-2); blp.topMargin=7; hero.addView(sh,blp); c.addView(hero)
        val stats=LinearLayout(this).apply { orientation=0; setPadding(14,14,14,14); background=android.graphics.drawable.GradientDrawable().apply { setColor(-1); cornerRadius=20f }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,18); layoutParams=lp }
        fun stat(value:String,label:String): LinearLayout { val box=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }; box.addView(text(value,21f,GREEN,true)); box.addView(text(label,10f,MUTED)); return box }
        stats.addView(stat(tracks.size.toString(),"SONGS ON DEVICE")); val line=View(this).apply { setBackgroundColor(0xFFE3EBE5.toInt()) }; stats.addView(line,LinearLayout.LayoutParams(1,42)); stats.addView(stat(history.total().toString(),"PLAYS RECORDED")); c.addView(stats)
        sectionTitle(c,"Forgotten gems","Your least-played tracks")
        if(tracks.isEmpty()) c.addView(emptyStateView("No music found yet","Add audio files to your phone, then tap scan.")) else tracks.sortedWith(compareBy<Track> { history.count(it.id) }.thenBy { val l=history.lastPlayed(it.id); if(l==0L) 0L else l }).take(5).forEach { trackRow(c,it) }
        sectionTitle(c,"Similar-song radio","Pick a track to build a related queue")
        tracks.take(4).forEach { t -> radioRow(c,t) }
        if(tracks.isEmpty()) c.addView(emptyStateView("Your library is waiting","Scan your device to see your songs here."))
    }
    private fun radioRow(parent: LinearLayout, t: Track) {
        val row = LinearLayout(this).apply {
            orientation = 0
            gravity = Gravity.CENTER_VERTICAL
            setPadding(10,8,10,8)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(-1)
                cornerRadius = 14f
            }
            val lp = LinearLayout.LayoutParams(-1,-2)
            lp.setMargins(0,3,0,3)
            layoutParams = lp
        }
        val glyph = TextView(this).apply {
            text = "♫"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(GREEN)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(MINT)
                cornerRadius = 12f
            }
        }
        row.addView(glyph, LinearLayout.LayoutParams(38,38))
        val labels = LinearLayout(this).apply {
            orientation = 1
            setPadding(10,0,6,0)
            layoutParams = LinearLayout.LayoutParams(0,-2,1f)
        }
        val title = text(t.title,13f,DEEP,true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val artist = text(t.artist,10f,MUTED).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        labels.addView(title)
        labels.addView(artist)
        row.addView(labels)
        val action = TextView(this).apply {
            text = "Radio  ›"
            textSize = 11f
            setTextColor(GREEN)
            gravity = Gravity.CENTER
            setPadding(8,8,8,8)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(PALE)
                cornerRadius = 12f
            }
            setOnClickListener { startRadio(t) }
        }
        row.addView(action)
        parent.addView(row)
    }

    private fun sectionTitle(c:LinearLayout,title:String,subtitle:String) { val box=LinearLayout(this).apply { orientation=1; setPadding(2,7,2,7) }; box.addView(text(title,17f,DEEP,true)); box.addView(text(subtitle,11f,MUTED)); c.addView(box) }
    private fun emptyStateView(title:String,subtitle:String): LinearLayout = LinearLayout(this).apply { orientation=1; setPadding(14,14,14,14); background=android.graphics.drawable.GradientDrawable().apply { setColor(-1); cornerRadius=16f }; addView(text(title,14f,DEEP,true)); addView(text(subtitle,11f,MUTED)) }
    private fun library(c: LinearLayout) {
        c.addView(text("Your library",23f,DEEP,true)); c.addView(text("${tracks.size} tracks · stored on this device",12f,MUTED))
        val search=EditText(this).apply { hint="Search songs or artists"; isSingleLine=true; setPadding(14,12,14,12); background=android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius=20f } }; c.addView(search)
        val list=LinearLayout(this).apply { orientation=1 }; c.addView(list)
        fun fill(q:String) { list.removeAllViews(); tracks.filter { it.title.contains(q,true)||it.artist.contains(q,true)||it.album.contains(q,true) }.forEach { trackRow(list,it) } }
        fill(""); search.addTextChangedListener(object: android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){fill(s?.toString()?:"")}; override fun afterTextChanged(s:android.text.Editable?){} })
        c.addView(button("Smart shuffle all songs") { smartShuffle() })
    }
    private fun insights(c: LinearLayout) {
        c.addView(text("Listening insights",25f,INK,true)); c.addView(text("Play counts are recorded when you start a song.",14f,MUTED))
        val row=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
        listOf("Day","Month","Year","All time").forEach { p -> val b=TextView(this).apply { text=p; textSize=12f; setTextColor(if(period==p) -1 else GREEN); setPadding(10,10,10,10); background=android.graphics.drawable.GradientDrawable().apply { setColor(if(period==p) GREEN else PALE); cornerRadius=18f }; setOnClickListener { period=p; render() } }; val lp=LinearLayout.LayoutParams(0,-2,1f); lp.setMargins(2,2,2,2); row.addView(b,lp) }; c.addView(row)
        val (from,to,label)=dateRange(); val total=history.total(from,to)
        val summary=card(); summary.addView(text(label.uppercase(Locale.getDefault()),12f,GREEN,true)); summary.addView(text("$total plays",28f,INK,true)); summary.addView(text("Listening events recorded by Sivu's Isaiaruvi",13f,MUTED)); c.addView(summary)
        c.addView(text("Most played in this period",19f,INK,true)); val top=history.top(from,to); if(top.isEmpty()) c.addView(text("No plays recorded for this period yet. Start listening and your stats will appear here.",14f,MUTED)) else top.forEachIndexed { i,p -> c.addView(text("${i+1}.  ${p.first}  ·  ${p.second} plays",14f,INK)) }
        c.addView(text("Custom date",19f,INK,true)); c.addView(text("Enter a date as YYYY-MM-DD",13f,MUTED)); val date=EditText(this).apply { hint="2026-10-22"; setSingleLine(); setText(customDay); setPadding(12,8,12,8) }; c.addView(date); c.addView(button("Show that day's plays") { customDay=date.text.toString().trim(); period="Custom"; render() })
        if(period=="Custom") { val (a,b,l)=dateRange(); c.addView(text("$l: ${history.total(a,b)} plays",16f,GREEN,true)) }
        c.addView(text("Per-song play counts",19f,INK,true)); tracks.sortedByDescending { history.count(it.id) }.take(30).forEach { t -> c.addView(text("${t.title}  ·  ${history.count(t.id)} plays",14f,INK)); c.addView(text(t.artist,12f,MUTED)) }
    }
    private fun dateRange(): Triple<Long,Long,String> {
        val cal=Calendar.getInstance(); val now=System.currentTimeMillis()
        if(period=="Custom" && customDay.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) { try { val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply { isLenient=false }.parse(customDay)!!; val a=Calendar.getInstance().apply { time=d; set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis; return Triple(a,a+86_399_999,customDay) } catch (_:Exception){} }
        when(period) { "Day" -> { cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; "Month" -> { cal.set(Calendar.DAY_OF_MONTH,1); cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; "Year" -> { cal.set(Calendar.DAY_OF_YEAR,1); cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; else -> return Triple(0L,now,"All time") }
        val label=when(period) { "Day" -> "Today"; "Month" -> SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(Date()); else -> cal.get(Calendar.YEAR).toString() }
        return Triple(cal.timeInMillis,now,label)
    }
    private fun trackRow(parent: LinearLayout,t:Track) {
        val r=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(8,7,8,7); background=android.graphics.drawable.GradientDrawable().apply { setColor(-1); cornerRadius=14f }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,3,0,3); layoutParams=lp }
        val art=TextView(this).apply { text="♫"; textSize=19f; gravity=Gravity.CENTER; setTextColor(GREEN); background=android.graphics.drawable.GradientDrawable().apply { setColor(MINT); cornerRadius=12f } }; r.addView(art,LinearLayout.LayoutParams(42,42))
        val labels=LinearLayout(this).apply { orientation=1; setPadding(10,0,4,0); layoutParams=LinearLayout.LayoutParams(0,-2,1f) }; labels.addView(text(t.title,13f,DEEP,true).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
        labels.addView(text("${t.artist}  ·  ${history.count(t.id)} plays",10f,MUTED).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
        r.addView(labels)
        val play=TextView(this).apply { text="▶"; textSize=15f; gravity=Gravity.CENTER; setTextColor(-1); background=android.graphics.drawable.GradientDrawable().apply { setColor(GREEN); cornerRadius=24f }; setOnClickListener { play(t) } }; r.addView(play,LinearLayout.LayoutParams(38,38)); parent.addView(r)
    }
    private fun play(t:Track) {
        try { player?.release() } catch (_:Exception) {}; player=null
        try { player=MediaPlayer().apply { setDataSource(this@MainActivity,t.uri); setOnPreparedListener { it.start() }; setOnCompletionListener { next() }; prepareAsync() }; current=t; history.record(t); nowPlayingLabel?.text="${t.title}  ·  ${t.artist}" } catch(e:Exception) { Toast.makeText(this,"Couldn't play this track",Toast.LENGTH_SHORT).show() }
        if(::root.isInitialized) render()
    }
    private fun smartShuffle() {
        if(tracks.isEmpty()) { Toast.makeText(this,"No music found. Add audio files and scan again.",Toast.LENGTH_LONG).show(); return }
        val now=System.currentTimeMillis(); queue=tracks.sortedBy { t -> val plays=history.count(t.id); val last=history.lastPlayed(t.id); (plays*100L) + (if(last==0L) -50_000_000L else max(0L, 50_000_000L-(now-last)/1000L)) }.toMutableList()
        // Shuffle within low-play-count groups, preserving the bias toward underplayed tracks.
        queue=queue.groupBy { history.count(it.id) }.toSortedMap().values.flatMap { it.shuffled() }.toMutableList(); queueIndex=0; play(queue[queueIndex]); tab="Home"; render(); Toast.makeText(this,"Smart shuffle started",Toast.LENGTH_SHORT).show()
    }
    private fun startRadio(seed:Track) {
        val seedWords=(seed.title+" "+seed.artist+" "+seed.album).lowercase(Locale.getDefault()).split(Regex("[^a-z0-9]+")).filter { it.length>2 }.toSet()
        queue=tracks.filter { it.id!=seed.id }.sortedByDescending { t -> var score=0; if(t.artist.equals(seed.artist,true)) score+=5; if(t.album.isNotBlank()&&t.album.equals(seed.album,true)) score+=4; val words=(t.title+" "+t.artist+" "+t.album).lowercase(Locale.getDefault()).split(Regex("[^a-z0-9]+")).toSet(); score+=words.intersect(seedWords).size; score*100-history.count(t.id) }.toMutableList()
        queue.add(0,seed); queueIndex=0; play(seed); render()
    }
    private fun next() { if(queue.isEmpty()) { smartShuffle(); return }; queueIndex=(queueIndex+1)%queue.size; play(queue[queueIndex]) }
    override fun onDestroy() { try { player?.release() } catch (_:Exception) {}; player=null; super.onDestroy() }
}

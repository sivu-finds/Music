package com.melo.localmusic

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

private const val GREEN = 0xFF18794E.toInt()
private const val INK = 0xFF17221C.toInt()
private const val MUTED = 0xFF748078.toInt()
private const val PALE = 0xFFF2F7F3.toInt()
private const val REQ_AUDIO = 441

data class Track(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val durationMs: Long)

class PlayHistory(context: android.content.Context) : SQLiteOpenHelper(context, "sivus_isaiaruvi_history.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE plays(id INTEGER PRIMARY KEY AUTOINCREMENT, track_id INTEGER NOT NULL, title TEXT, artist TEXT, played_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX plays_date ON plays(played_at)")
        db.execSQL("CREATE INDEX plays_track ON plays(track_id)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun record(t: Track) { writableDatabase.execSQL("INSERT INTO plays(track_id,title,artist,played_at) VALUES(?,?,?,?)", arrayOf(t.id, t.title, t.artist, System.currentTimeMillis())) }
    fun count(id: Long): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM plays WHERE track_id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    fun lastPlayed(id: Long): Long = readableDatabase.rawQuery("SELECT MAX(played_at) FROM plays WHERE track_id=?", arrayOf(id.toString())).use { if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else 0L }
    fun total(from: Long = 0L, to: Long = Long.MAX_VALUE): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM plays WHERE played_at>=? AND played_at<=?", arrayOf(from.toString(), to.toString())).use { if(it.moveToFirst()) it.getInt(0) else 0 }
    fun top(from: Long, to: Long): List<Pair<String,Int>> {
        val out = mutableListOf<Pair<String,Int>>()
        readableDatabase.rawQuery("SELECT title,COUNT(*) c FROM plays WHERE played_at>=? AND played_at<=? GROUP BY track_id ORDER BY c DESC LIMIT 8", arrayOf(from.toString(),to.toString())).use { c -> while(c.moveToNext()) out += (c.getString(0) ?: "Unknown") to c.getInt(1) }
        return out
    }
}

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var history: PlayHistory
    private val tracks = mutableListOf<Track>()
    private var player: MediaPlayer? = null
    private var current: Track? = null
    private var queue = mutableListOf<Track>()
    private var queueIndex = 0
    private var tab = "Home"
    private var period = "Month"
    private var customDay = ""
    private var nowPlayingLabel: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        history = PlayHistory(this)
        window.statusBarColor = android.graphics.Color.WHITE
        window.navigationBarColor = android.graphics.Color.WHITE
        if (hasAudioPermission()) { scan(); render() } else requestAudioPermission()
    }
    private fun hasAudioPermission(): Boolean = if (Build.VERSION.SDK_INT >= 33) checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    private fun requestAudioPermission() { requestPermissions(arrayOf(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE), REQ_AUDIO) }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == REQ_AUDIO) { if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) { scan(); render() } else showPermissionScreen() } }

    private fun scan() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.IS_MUSIC)
        contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC}=1 AND ${MediaStore.Audio.Media.DURATION}>30000", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST); val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM); val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while(c.moveToNext()) { val id=c.getLong(idCol); tracks += Track(id, c.getString(titleCol) ?: "Unknown track", c.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "Unknown artist", c.getString(albumCol) ?: "", ContentUris.withAppendedId(collection,id), c.getLong(durCol)) }
        }
    }
    private fun showPermissionScreen() { root = LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(32,32,32,32); setBackgroundColor(-1) }; root.addView(text("Allow music access so Sivu's Isaiaruvi can find audio stored on your phone.",18f,INK)); root.addView(button("Grant music access") { requestAudioPermission() }); setContentView(root) }
    private fun text(s: String, size: Float=14f, color: Int=INK, bold: Boolean=false): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0,2,0,2) }
    private fun button(s: String, action: () -> Unit): Button = Button(this).apply {
        text=s
        textSize=13f
        minHeight=0
        minimumHeight=0
        minWidth=0
        minimumWidth=0
        setPadding(10,4,10,4)
        setTextColor(GREEN)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(PALE))
        setOnClickListener { action() }
    }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation=1; setPadding(14,8,14,8); background = android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius=16f }; val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,4,0,4); layoutParams=p }
    private fun render() {
        root=LinearLayout(this).apply { orientation=1; setBackgroundColor(-1) }
        val header=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(18,8,18,4) }
        val brand=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        brand.addView(text("Sivu’s Isaiaruvi",23f,GREEN,true)); brand.addView(text("Your music. Your rhythm.",13f,MUTED))
        header.addView(brand); header.addView(button("↻ Scan") { scan(); render() }); root.addView(header)
        val scroll=ScrollView(this); val content=LinearLayout(this).apply { orientation=1; setPadding(22,8,22,18) }; scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        when(tab) {
            "Home" -> home(content)
            "Library" -> library(content)
            else -> insights(content)
        }
        val nav=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER; setPadding(8,6,8,8); setBackgroundColor(-1) }
        listOf("Home","Library","Insights").forEach { t -> val b=TextView(this).apply { text=(if(t==tab) "●  " else "○  ")+t; textSize=14f; gravity=Gravity.CENTER; setTextColor(if(t==tab) GREEN else MUTED); setPadding(6,8,6,8); setOnClickListener { tab=t; render() } }; nav.addView(b,LinearLayout.LayoutParams(0,-2,1f)) }
        root.addView(nav)
        val mini=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(12,4,12,4); setBackgroundColor(0xFFF8FAF8.toInt()) }
        nowPlayingLabel=text(if(current==null) "Nothing playing yet" else "${current!!.title} · ${current!!.artist}",12f,INK)
        mini.addView(nowPlayingLabel,LinearLayout.LayoutParams(0,-2,1f)); mini.addView(button("▶") { if(current!=null) { try { player?.start() } catch (_:Exception) { play(current!!) } } }); mini.addView(button("Ⅱ") { player?.pause() }); mini.addView(button("⏭") { next() }); root.addView(mini)
        setContentView(root)
    }
    private fun home(c: LinearLayout) {
        c.addView(text("Good music, rediscovered.",21f,INK,true)); c.addView(text("Your music, with smarter shuffle.",13f,MUTED))
        val hero=card(); hero.setBackgroundColor(0xFFEAF4ED.toInt()); hero.addView(text("SMART SHUFFLE",12f,GREEN,true)); hero.addView(text("Rediscover your music",18f,INK,true)); hero.addView(text("Least-played tracks rise up. Recent plays take a break.",13f,MUTED)); hero.addView(button("Shuffle my library  ↗") { smartShuffle() }); c.addView(hero)
        val stats=card(); stats.addView(text("YOUR LISTENING",12f,GREEN,true)); stats.addView(text("${tracks.size} songs on this device",18f,INK,true)); stats.addView(text("${history.total()} recorded plays",14f,MUTED)); c.addView(stats)
        c.addView(text("Forgotten gems",18f,INK,true)); c.addView(text("Songs with the fewest recorded plays",13f,MUTED))
        tracks.sortedWith(compareBy<Track> { history.count(it.id) }.thenByDescending { System.currentTimeMillis()-history.lastPlayed(it.id) }).take(8).forEach { trackRow(c,it) }
        c.addView(text("Similar-song radio",18f,INK,true)); c.addView(text("Start with a song and Sivu's Isaiaruvi will queue tracks sharing its artist, album, or title keywords.",13f,MUTED))
        tracks.take(5).forEach { t -> c.addView(button("▶  ${t.title}  ·  ${t.artist}") { startRadio(t) }) }
    }
    private fun library(c: LinearLayout) {
        c.addView(text("Your library",25f,INK,true)); c.addView(text("${tracks.size} tracks found on this device",14f,MUTED))
        val search=EditText(this).apply { hint="Search songs or artists"; isSingleLine=true; setPadding(14,12,14,12); background=android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius=20f } }; c.addView(search)
        val list=LinearLayout(this).apply { orientation=1 }; c.addView(list)
        fun fill(q:String) { list.removeAllViews(); tracks.filter { it.title.contains(q,true)||it.artist.contains(q,true)||it.album.contains(q,true) }.forEach { trackRow(list,it) } }
        fill(""); search.addTextChangedListener(object: android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){fill(s?.toString()?:"")}; override fun afterTextChanged(s:android.text.Editable?){} })
        c.addView(button("Smart shuffle all songs") { smartShuffle() })
    }
    private fun insights(c: LinearLayout) {
        c.addView(text("Listening insights",25f,INK,true)); c.addView(text("Play counts are recorded when you start a song.",14f,MUTED))
        val row=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
        listOf("Day","Month","Year","All time").forEach { p -> val b=TextView(this).apply { text=p; textSize=12f; setTextColor(if(period==p) -1 else GREEN); setPadding(10,10,10,10); background=android.graphics.drawable.GradientDrawable().apply { setColor(if(period==p) GREEN else PALE); cornerRadius=18f }; setOnClickListener { period=p; render() } }; val lp=LinearLayout.LayoutParams(0,-2,1f); lp.setMargins(2,2,2,2); row.addView(b,lp) }; c.addView(row)
        val (from,to,label)=dateRange(); val total=history.total(from,to)
        val summary=card(); summary.addView(text(label.uppercase(Locale.getDefault()),12f,GREEN,true)); summary.addView(text("$total plays",28f,INK,true)); summary.addView(text("Listening events recorded by Sivu's Isaiaruvi",13f,MUTED)); c.addView(summary)
        c.addView(text("Most played in this period",19f,INK,true)); val top=history.top(from,to); if(top.isEmpty()) c.addView(text("No plays recorded for this period yet. Start listening and your stats will appear here.",14f,MUTED)) else top.forEachIndexed { i,p -> c.addView(text("${i+1}.  ${p.first}  ·  ${p.second} plays",14f,INK)) }
        c.addView(text("Custom date",19f,INK,true)); c.addView(text("Enter a date as YYYY-MM-DD",13f,MUTED)); val date=EditText(this).apply { hint="2026-10-22"; setSingleLine(); setText(customDay); setPadding(12,8,12,8) }; c.addView(date); c.addView(button("Show that day's plays") { customDay=date.text.toString().trim(); period="Custom"; render() })
        if(period=="Custom") { val (a,b,l)=dateRange(); c.addView(text("$l: ${history.total(a,b)} plays",16f,GREEN,true)) }
        c.addView(text("Per-song play counts",19f,INK,true)); tracks.sortedByDescending { history.count(it.id) }.take(30).forEach { t -> c.addView(text("${t.title}  ·  ${history.count(t.id)} plays",14f,INK)); c.addView(text(t.artist,12f,MUTED)) }
    }
    private fun dateRange(): Triple<Long,Long,String> {
        val cal=Calendar.getInstance(); val now=System.currentTimeMillis()
        if(period=="Custom" && customDay.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) { try { val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply { isLenient=false }.parse(customDay)!!; val a=Calendar.getInstance().apply { time=d; set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis; return Triple(a,a+86_399_999,customDay) } catch (_:Exception){} }
        when(period) { "Day" -> { cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; "Month" -> { cal.set(Calendar.DAY_OF_MONTH,1); cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; "Year" -> { cal.set(Calendar.DAY_OF_YEAR,1); cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; else -> return Triple(0L,now,"All time") }
        val label=when(period) { "Day" -> "Today"; "Month" -> SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(Date()); else -> cal.get(Calendar.YEAR).toString() }
        return Triple(cal.timeInMillis,now,label)
    }
    private fun trackRow(parent: LinearLayout,t:Track) {
        val r=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(6,4,4,4) }
        val art=TextView(this).apply { text="♫"; textSize=22f; gravity=Gravity.CENTER; setTextColor(GREEN); background=android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius=16f } }; r.addView(art,LinearLayout.LayoutParams(40,40))
        val labels=LinearLayout(this).apply { orientation=1; setPadding(9,0,4,0); layoutParams=LinearLayout.LayoutParams(0,-2,1f) }; labels.addView(text(t.title,14f,INK,true)); labels.addView(text("${t.artist} · ${history.count(t.id)} plays",11f,MUTED)); r.addView(labels); val play=TextView(this).apply { text="▶"; textSize=18f; setTextColor(GREEN); setPadding(10,10,10,10); setOnClickListener { play(t) } }; r.addView(play); parent.addView(r)
    }
    private fun play(t:Track) {
        try { player?.release() } catch (_:Exception) {}; player=null
        try { player=MediaPlayer().apply { setDataSource(this@MainActivity,t.uri); setOnPreparedListener { it.start() }; setOnCompletionListener { next() }; prepareAsync() }; current=t; history.record(t); nowPlayingLabel?.text="${t.title}  ·  ${t.artist}" } catch(e:Exception) { Toast.makeText(this,"Couldn't play this track",Toast.LENGTH_SHORT).show() }
        if(::root.isInitialized) render()
    }
    private fun smartShuffle() {
        if(tracks.isEmpty()) { Toast.makeText(this,"No music found. Add audio files and scan again.",Toast.LENGTH_LONG).show(); return }
        val now=System.currentTimeMillis(); queue=tracks.sortedBy { t -> val plays=history.count(t.id); val last=history.lastPlayed(t.id); (plays*100L) + (if(last==0L) -50_000_000L else max(0L, 50_000_000L-(now-last)/1000L)) }.toMutableList()
        // Shuffle within low-play-count groups, preserving the bias toward underplayed tracks.
        queue=queue.groupBy { history.count(it.id) }.toSortedMap().values.flatMap { it.shuffled() }.toMutableList(); queueIndex=0; play(queue[queueIndex]); tab="Home"; render(); Toast.makeText(this,"Smart shuffle started",Toast.LENGTH_SHORT).show()
    }
    private fun startRadio(seed:Track) {
        val seedWords=(seed.title+" "+seed.artist+" "+seed.album).lowercase(Locale.getDefault()).split(Regex("[^a-z0-9]+")).filter { it.length>2 }.toSet()
        queue=tracks.filter { it.id!=seed.id }.sortedByDescending { t -> var score=0; if(t.artist.equals(seed.artist,true)) score+=5; if(t.album.isNotBlank()&&t.album.equals(seed.album,true)) score+=4; val words=(t.title+" "+t.artist+" "+t.album).lowercase(Locale.getDefault()).split(Regex("[^a-z0-9]+")).toSet(); score+=words.intersect(seedWords).size; score*100-history.count(t.id) }.toMutableList()
        queue.add(0,seed); queueIndex=0; play(seed); render()
    }
    private fun next() { if(queue.isEmpty()) { smartShuffle(); return }; queueIndex=(queueIndex+1)%queue.size; play(queue[queueIndex]) }
    override fun onDestroy() { try { player?.release() } catch (_:Exception) {}; player=null; super.onDestroy() }
}

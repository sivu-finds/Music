# Sivu's Isaiaruvi v1.10.0 — responsiveness and discovery update

Changes in this source update:
- Home uses a compact two-card layout for Smart Shuffle and Song Radio; the four-item Song Radio teaser list has been removed.
- Song Radio picker supports searching song title, album/movie name, and artist, with Songs / Albums / Artists filters.
- Album display can be switched between list and two-column artwork grid in the Library screen; preference is saved on device.
- Song and album lists are initially limited to 100 rows with a Load more action to reduce main-thread view creation and UI freezes.
- Home no longer runs per-track history database queries for its initial forgotten-gems teaser.
- Keeps v1.9.0 background library scanning and background similar-song ranking changes.

Build status: source package only. This project has not been compiled in this environment; use GitHub Actions to verify before installing.

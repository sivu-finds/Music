package com.melo.localmusic

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.media.MediaMetadata
import android.os.Handler
import android.os.Looper
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import android.view.MotionEvent
import java.util.concurrent.Executors
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

private const val GREEN = 0xFFE51B35.toInt()
private const val INK = 0xFF202020.toInt()
private const val MUTED = 0xFF777777.toInt()
private const val PALE = 0xFFF5F5F5.toInt()
private const val DEEP = 0xFF202020.toInt()
private const val MINT = 0xFFFCE8EC.toInt()
private const val REQ_AUDIO = 441

data class Track(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val durationMs: Long, val path: String = "", val year: Int = 0, val albumId: Long = -1L)

class PlayHistory(context: android.content.Context) : SQLiteOpenHelper(context, "sivus_isaiaruvi_history.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE plays(id INTEGER PRIMARY KEY AUTOINCREMENT, track_id INTEGER NOT NULL, title TEXT, artist TEXT, played_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX plays_date ON plays(played_at)")
        db.execSQL("CREATE INDEX plays_track ON plays(track_id)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun record(t: Track) { writableDatabase.execSQL("INSERT INTO plays(track_id,title,artist,played_at) VALUES(?,?,?,?)", arrayOf(t.id, t.title, t.artist, System.currentTimeMillis())) }
    fun count(id: Long): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM plays WHERE track_id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    fun lastPlayed(id: Long): Long = readableDatabase.rawQuery("SELECT MAX(played_at) FROM plays WHERE track_id=?", arrayOf(id.toString())).use { if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else 0L }
    fun total(from: Long = 0L, to: Long = Long.MAX_VALUE): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM plays WHERE played_at>=? AND played_at<=?", arrayOf(from.toString(), to.toString())).use { if(it.moveToFirst()) it.getInt(0) else 0 }
    fun top(from: Long, to: Long): List<Pair<String,Int>> {
        val out = mutableListOf<Pair<String,Int>>()
        readableDatabase.rawQuery("SELECT title,COUNT(*) c FROM plays WHERE played_at>=? AND played_at<=? GROUP BY track_id ORDER BY c DESC LIMIT 8", arrayOf(from.toString(),to.toString())).use { c -> while(c.moveToNext()) out += (c.getString(0) ?: "Unknown") to c.getInt(1) }
        return out
    }
}

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var history: PlayHistory
    private val tracks = mutableListOf<Track>()
    private val libraryExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var scanInProgress = false
    private var swipeStartX = 0f
    private var swipeStartY = 0f
    private var player: MediaPlayer? = null
    private var mediaSession: MediaSession? = null
    private val notificationChannelId = "sivus_isaiaruvi_playback"
    private val playbackNotificationId = 1808
    private var current: Track? = null
    private var queue = mutableListOf<Track>()
    private var queueIndex = 0
    private var tab = "Home"
    private var period = "Month"
    private var customDay = ""
    private var nowPlayingLabel: TextView? = null
    private var playbackReady = false
    private var shuffleEnabled = false
    private var repeatEnabled = false
    private val handler = Handler(Looper.getMainLooper())
    private var listeningStartMs = 0L
    private var lastRecordedTrackId = -1L
    private var listenedMs = 0L
    private val listenedRanges = mutableListOf<Pair<Long, Long>>()
    private var lastPositionMs = -1
    private var lastProgressTrackId = -1L
    private var libraryMode = "Songs"
    private var albumDisplayMode = "List"
    private var libraryVisibleLimit = 100
    private var playerScreenOpen = false
    private var fullPlayerSeek: SeekBar? = null
    private var fullPlayerElapsed: TextView? = null
    private var fullPlayerTotal: TextView? = null
    private val progressTicker = object : Runnable {
        override fun run() {
            val t = current
            val p = player
            if (t != null && p != null && playbackReady && tryIsPlaying()) {
                try {
                    val pos = p.currentPosition
                    if (lastProgressTrackId != t.id) { lastProgressTrackId = t.id; lastPositionMs = pos }
                    else if (lastPositionMs >= 0) {
                        val delta = pos - lastPositionMs
                        // Count real-time playback progress, not seeks or time spent paused.
                        // Count only forward playback segments. Seeking, pausing, and replaying an
                        // already-heard segment cannot inflate unique listened coverage.
                        if (delta in 1..1800) addListenedRange(lastPositionMs.toLong(), pos.toLong())
                        lastPositionMs = pos
                    }
                    val threshold = (t.durationMs * 0.80).toLong()
                    if (listenedMs >= threshold && lastRecordedTrackId != t.id) {
                        history.record(t)
                        lastRecordedTrackId = t.id
                        Toast.makeText(this@MainActivity, "Meaningful listen recorded · 80%", Toast.LENGTH_SHORT).show()
                        if (::root.isInitialized) render()
                    }
                } catch (_: Exception) { lastPositionMs = -1 }
            } else lastPositionMs = -1
            if (playerScreenOpen) {
                try { val pos = player?.currentPosition?.toLong() ?: 0L; fullPlayerSeek?.progress = ((pos.toFloat() / (current?.durationMs ?: 1L).coerceAtLeast(1L)) * 1000).toInt(); fullPlayerElapsed?.text = formatTime(pos); fullPlayerTotal?.text = formatTime(current?.durationMs ?: 0L) } catch (_: Exception) {}
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        history = PlayHistory(this)
        createPlaybackNotificationChannel()
        mediaSession = MediaSession(this, "SivusIsaiaruvi").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { runOnUiThread {
                    if (player == null) current?.let { play(it) } ?: tracks.firstOrNull()?.let { play(it) }
                    else try { if (playbackReady && player?.isPlaying != true) player?.start() } catch (_: Exception) {}
                    updatePlaybackNotification(); if (::root.isInitialized) render()
                } }
                override fun onPause() { runOnUiThread {
                    try { if (playbackReady && player?.isPlaying == true) player?.pause() } catch (_: Exception) {}
                    updatePlaybackNotification(); if (::root.isInitialized) render()
                } }
                override fun onSkipToNext() { runOnUiThread { next(); render(); updatePlaybackNotification() } }
                override fun onSkipToPrevious() { runOnUiThread { previous(); render(); updatePlaybackNotification() } }
            })
            isActive = true
        }
        window.statusBarColor = 0xFFFFFFFF.toInt()
        window.navigationBarColor = 0xFFFFFFFF.toInt()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        if (hasAudioPermission()) { scan(); render() } else requestAudioPermission()
        handler.postDelayed(progressTicker, 1000L)
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun createPlaybackNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(notificationChannelId, "Music playback", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Now playing controls for Sivu’s Isaiaruvi"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notificationAction(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, MainActivity::class.java).apply {
            this.action = action
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(this, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun updatePlaybackNotification() {
        val t = current ?: return
        val session = mediaSession ?: return
        val playing = tryIsPlaying()
        val state = if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED
        session.setMetadata(MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, displayTitle(t.title))
            .putString(MediaMetadata.METADATA_KEY_ARTIST, displayArtist(t.artist))
            .putLong(MediaMetadata.METADATA_KEY_DURATION, t.durationMs)
            .build())
        session.setPlaybackState(PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO)
            .setState(state, try { player?.currentPosition?.toLong() ?: 0L } catch (_: Exception) { 0L }, if (playing) 1f else 0f)
            .build())
        val openIntent = notificationAction("OPEN_PLAYER", 10)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, notificationChannelId) else Notification.Builder(this)
        builder.setSmallIcon(R.drawable.ic_music_note)
            .setContentTitle(displayTitle(t.title))
            .setContentText(displayArtist(t.artist))
            .setContentIntent(openIntent)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .setShowWhen(false)
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_previous), "Previous", notificationAction("PREVIOUS", 11)).build())
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, if (playing) R.drawable.ic_pause else R.drawable.ic_play), if (playing) "Pause" else "Play", notificationAction("TOGGLE", 12)).build())
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_next), "Next", notificationAction("NEXT", 13)).build())
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_shuffle), if (shuffleEnabled) "Shuffle on" else "Shuffle", notificationAction("SHUFFLE", 14)).build())
        if (Build.VERSION.SDK_INT >= 21) builder.setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2))
        getSystemService(NotificationManager::class.java).notify(playbackNotificationId, builder.build())
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        when (intent.action) {
            "TOGGLE" -> togglePlayback()
            "NEXT" -> next()
            "PREVIOUS" -> previous()
            "SHUFFLE" -> toggleShuffle()
            "OPEN_PLAYER" -> playerScreenOpen = true
        }
        if (intent.action != null) { render(); updatePlaybackNotification() }
    }

    private fun playerControl(label: String, description: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        contentDescription = description
        textSize = if (label == "▶|") 16f else 20f
        gravity = Gravity.CENTER
        setTextColor(if (label == "▶") DEEP else -1)
        minimumWidth = dp(48)
        minimumHeight = dp(48)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(if (label == "▶") MINT else 0xFF1B684A.toInt())
            cornerRadius = dp(14).toFloat()
        }
        val lp = LinearLayout.LayoutParams(dp(48), dp(48))
        lp.setMargins(dp(3), 0, 0, 0)
        layoutParams = lp
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun tryIsPlaying(): Boolean = try { player?.isPlaying == true } catch (_: Exception) { false }

    private fun addListenedRange(start: Long, end: Long) {
        if (end <= start) return
        var mergedStart = start.coerceAtLeast(0L)
        var mergedEnd = end
        val merged = mutableListOf<Pair<Long, Long>>()
        var inserted = false
        for ((a, b) in listenedRanges.sortedBy { it.first }) {
            if (b < mergedStart) merged.add(a to b)
            else if (mergedEnd < a) {
                if (!inserted) { merged.add(mergedStart to mergedEnd); inserted = true }
                merged.add(a to b)
            } else {
                mergedStart = minOf(mergedStart, a)
                mergedEnd = maxOf(mergedEnd, b)
            }
        }
        if (!inserted) merged.add(mergedStart to mergedEnd)
        listenedRanges.clear()
        listenedRanges.addAll(merged)
        listenedMs = listenedRanges.sumOf { (a, b) -> (b - a).coerceAtLeast(0L) }
    }

    private fun togglePlayback() {
        val p = player
        if (p == null || current == null) {
            if (queue.isNotEmpty()) play(queue.getOrNull(queueIndex) ?: queue.first())
            else if (tracks.isNotEmpty()) play(tracks.first())
            else Toast.makeText(this, "No music found. Scan your library first.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            if (playbackReady && p.isPlaying) p.pause() else if (playbackReady) p.start()
            render()
        } catch (_: IllegalStateException) {
            current?.let { play(it) }
        }
        updatePlaybackNotification()
    }

    private fun hasAudioPermission(): Boolean = if (Build.VERSION.SDK_INT >= 33) checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    private fun requestAudioPermission() { requestPermissions(arrayOf(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE), REQ_AUDIO) }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == REQ_AUDIO) { if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) { scan(); render() } else showPermissionScreen() } }

    private fun scan() {
        if (scanInProgress) return
        scanInProgress = true
        if (::root.isInitialized) {
            Toast.makeText(this, "Scanning your music in the background…", Toast.LENGTH_SHORT).show()
        }
        libraryExecutor.execute {
            val found = mutableListOf<Track>()
            try {
                val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.IS_MUSIC, MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.YEAR, MediaStore.Audio.Media.ALBUM_ID)
                val excluded = getSharedPreferences("sivu_settings", MODE_PRIVATE).getString("excluded_folders", "").orEmpty().split(",").map { it.trim().lowercase(Locale.ROOT) }.filter { it.isNotBlank() }
                contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC}=1 AND ${MediaStore.Audio.Media.DURATION}>30000", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                    val idCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val titleCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artistCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST); val albumCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM); val durCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val pathCol=c.getColumnIndex(MediaStore.Audio.Media.DATA); val yearCol=c.getColumnIndex(MediaStore.Audio.Media.YEAR); val albumIdCol=c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                    while(c.moveToNext()) {
                        val id=c.getLong(idCol); val filePath=if(pathCol>=0) c.getString(pathCol).orEmpty() else ""
                        if(excluded.any { filePath.lowercase(Locale.ROOT).contains("/$it/") || filePath.lowercase(Locale.ROOT).endsWith("/$it") }) continue
                        val year=if(yearCol>=0 && !c.isNull(yearCol)) c.getInt(yearCol) else 0
                        found += Track(id, c.getString(titleCol) ?: "Unknown track", c.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "Unknown artist", c.getString(albumCol) ?: "", ContentUris.withAppendedId(collection,id), c.getLong(durCol), filePath, year, if(albumIdCol>=0 && !c.isNull(albumIdCol)) c.getLong(albumIdCol) else -1L)
                    }
                }
            } catch (_: Exception) { }
            runOnUiThread {
                tracks.clear(); tracks.addAll(found)
                scanInProgress = false
                if (::root.isInitialized) render()
                Toast.makeText(this, "Library ready · ${tracks.size} songs", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun showSettings() {
        val prefs = getSharedPreferences("sivu_settings", MODE_PRIVATE)
        val box = LinearLayout(this).apply { orientation = 1; setPadding(dp(20), dp(8), dp(20), 0) }
        val excluded = EditText(this).apply {
            hint = "Excluded folder names, comma separated"; setText(prefs.getString("excluded_folders", "") ?: "")
            minLines = 2
        }
        box.addView(text("Exclude music folders", 16f, DEEP, true))
        box.addView(text("Enter folder names such as WhatsApp, Telegram, Recordings. Scan filters matching folder paths.", 12f, MUTED))
        box.addView(excluded)
        val themeLabel = text("Appearance", 16f, DEEP, true).apply { setPadding(0, dp(14), 0, dp(4)) }
        box.addView(themeLabel)
        val themeOptions = arrayOf("Follow system", "Light", "Dark")
        val themeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, themeOptions)
            setSelection(prefs.getInt("theme_mode", 0).coerceIn(0, 2))
        }
        box.addView(themeSpinner)
        val crossfadeLabel = text("Crossfade duration", 16f, DEEP, true).apply { setPadding(0, dp(14), 0, dp(4)) }
        box.addView(crossfadeLabel)
        val crossfadeOptions = arrayOf("Off", "2 seconds", "3 seconds", "5 seconds")
        val crossfadeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, crossfadeOptions)
            setSelection(prefs.getInt("crossfade_seconds_index", 0).coerceIn(0, 3))
        }
        box.addView(crossfadeSpinner)
        AlertDialog.Builder(this).setTitle("Isaiaruvi settings").setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("excluded_folders", excluded.text.toString()).putInt("theme_mode", themeSpinner.selectedItemPosition).putInt("crossfade_seconds_index", crossfadeSpinner.selectedItemPosition).apply()
                scan(); render(); Toast.makeText(this, "Settings saved · crossfade preference stored", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showPermissionScreen() { root = LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(32,32,32,32); setBackgroundColor(-1) }; root.addView(text("Allow music access so Sivu's Isaiaruvi can find audio stored on your phone.",18f,INK)); root.addView(button("Grant music access") { requestAudioPermission() }); setContentView(root) }
    private fun text(s: String, size: Float=14f, color: Int=INK, bold: Boolean=false): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0,2,0,2) }
    // Clean source-site suffixes for display only; MediaStore metadata remains untouched.
    private fun displayTitle(value: String): String = value
        .replace(Regex("(?i)\\s*[-–—]\\s*MassTamilan(?:\\.com|\\.dev|\\.fm|\\.io)?\\s*$"), "")
        .replace(Regex("\\s{2,}"), " ").trim()
    private fun displayArtist(value: String): String = value
        .replace(Regex("(?i)\\s*[-–—]\\s*MassTamilan(?:\\.com|\\.dev|\\.fm|\\.io)?\\s*$"), "")
        .ifBlank { "Unknown artist" }.trim()
    private fun songCountLabel(count: Int): String = if (count == 1) "1 song" else "$count songs"
    private fun albumCollectionRow(name: String, items: List<Track>): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = 0; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = android.graphics.drawable.GradientDrawable().apply { setColor(-1); cornerRadius = dp(14).toFloat(); setStroke(dp(1), 0xFFDCE9DF.toInt()) }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(3), 0, dp(3)); layoutParams = lp
            isClickable = true; isFocusable = true
        }
        val cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = android.graphics.drawable.GradientDrawable().apply { setColor(MINT); cornerRadius = dp(8).toFloat() }
            val albumId = items.firstOrNull()?.albumId ?: -1L
            if (albumId > 0) try { setImageURI(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)) } catch (_: Exception) {}
        }
        row.addView(cover, LinearLayout.LayoutParams(dp(54), dp(54)))
        val labels = LinearLayout(this).apply { orientation = 1; setPadding(dp(12), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        labels.addView(text(displayTitle(name), 14f, DEEP, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        labels.addView(text(songCountLabel(items.size), 12f, MUTED))
        row.addView(labels)
        row.setOnClickListener { showGroup(name, items) }
        return row
    }

    private fun collectionRow(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        setTextColor(GREEN)
        gravity = Gravity.CENTER_VERTICAL or Gravity.START
        setPadding(dp(14), dp(12), dp(12), dp(12))
        maxLines = 2
        ellipsize = android.text.TextUtils.TruncateAt.END
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(-1); cornerRadius = dp(12).toFloat()
            setStroke(dp(1), 0xFFDCE9DF.toInt())
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, dp(3), 0, dp(3))
        layoutParams = lp
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun button(s: String, action: () -> Unit): Button = Button(this).apply {
        text=s
        textSize=13f
        isAllCaps=false
        minHeight=0
        minimumHeight=0
        minWidth=0
        minimumWidth=0
        setPadding(12,8,12,8)
        setTextColor(GREEN)
        background=android.graphics.drawable.GradientDrawable().apply {
            setColor(PALE)
            cornerRadius=14f
            setStroke(1,0xFFDCE9DF.toInt())
        }
        setOnClickListener { action() }
    }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation=1; setPadding(14,8,14,8); background = android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius=16f }; val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,4,0,4); layoutParams=p }
    private fun render() {
        root=LinearLayout(this).apply { orientation=1; setBackgroundColor(0xFFFFFFFF.toInt()); fitsSystemWindows = true }
        if (playerScreenOpen) { renderFullPlayerScreen(); return }
        val header=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(18),dp(8),dp(18),dp(8)) }
        val brand=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        brand.addView(text("SIVU’S  ISAIARUVI",18f,DEEP,true)); brand.addView(text("LOCAL MUSIC PLAYER",10f,MUTED,true))
        header.addView(brand)
        header.addView(button("⚙") { showSettings() })
        header.addView(button("⟳ Scan") { scan(); render(); Toast.makeText(this, "Library rescanned · ${tracks.size} songs", Toast.LENGTH_SHORT).show() })
        root.addView(header)
        val scroll=ScrollView(this).apply { isFillViewport=true }; val content=LinearLayout(this).apply { orientation=1; setPadding(dp(16),dp(4),dp(16),dp(14)) }; scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        when(tab) { "Home" -> home(content); "Library" -> library(content); else -> insights(content) }
        val mini=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(12),dp(8),dp(10),dp(8)); background=android.graphics.drawable.GradientDrawable().apply { setColor(DEEP); cornerRadius=dp(18).toFloat() }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(dp(12),dp(4),dp(12),dp(6)); layoutParams=lp }
        val trackName=if(current==null) "Choose a song to begin" else current!!.title
        val trackArtist=if(current==null) "Sivu’s Isaiaruvi" else current!!.artist
        val labels=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f); setPadding(0,0,dp(6),0) }
        labels.addView(text(displayTitle(trackName),13f,-1,true).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
        labels.addView(text(displayArtist(trackArtist),10f,0xFFBBD7C8.toInt()).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
        mini.addView(labels)
        labels.setOnClickListener { showFullPlayer() }
        mini.setOnClickListener { showFullPlayer() }
        mini.addView(playerControl(if (playbackReady && tryIsPlaying()) "Ⅱ" else "▶", "Play or pause") { togglePlayback() })
        mini.addView(playerControl("▶|", "Next track") { next() })
        root.addView(mini)
        val nav=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER; setPadding(dp(10),dp(3),dp(10),dp(10)); setBackgroundColor(0xFFFFFFFF.toInt()); fitsSystemWindows = true }
        listOf("Home","Library","Insights").forEach { t -> val selected=t==tab; val b=TextView(this).apply { text=(when(t){"Home"->"⌂";"Library"->"♫";else->"◷"})+"  "+t; textSize=12f; gravity=Gravity.CENTER; setTypeface(null,if(selected) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL); setTextColor(if(selected) -1 else MUTED); setPadding(dp(6),dp(10),dp(6),dp(10)); minimumHeight=dp(48); background=android.graphics.drawable.GradientDrawable().apply { setColor(if(selected) GREEN else 0xFFF8FAF8.toInt()); cornerRadius=24f }; setOnClickListener { tab=t; render() } }; val lp=LinearLayout.LayoutParams(0,-2,1f); lp.setMargins(4,0,4,0); nav.addView(b,lp) }
        root.addView(nav); setContentView(root)
    }
    private fun home(c: LinearLayout) {
        val welcome=LinearLayout(this).apply { orientation=1; setPadding(2,8,2,12) }
        welcome.addView(text("Your sound, your space.",22f,DEEP,true)); welcome.addView(text("A little more discovery. A lot less repetition.",12f,MUTED)); c.addView(welcome)
        val discovery = LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; layoutParams=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(14) } }
        val shuffleCard = LinearLayout(this).apply { orientation=1; setPadding(dp(12),dp(12),dp(12),dp(12)); background=android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,intArrayOf(DEEP,0xFF444444.toInt())).apply { cornerRadius=dp(18).toFloat() }; layoutParams=LinearLayout.LayoutParams(0,-2,1f).apply { marginEnd=dp(8) } }
        shuffleCard.addView(text("✦ SMART SHUFFLE",10f,MINT,true)); shuffleCard.addView(text("Rediscover your music",15f,-1,true)); shuffleCard.addView(button("Shuffle library ↗") { smartShuffle() })
        val radioCard = LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(dp(10),dp(12),dp(10),dp(12)); background=android.graphics.drawable.GradientDrawable().apply { setColor(MINT); cornerRadius=dp(18).toFloat() }; layoutParams=LinearLayout.LayoutParams(0,dp(124),1f) }
        radioCard.addView(text("♫",25f,GREEN,true).apply { gravity=Gravity.CENTER }); radioCard.addView(text("SONG RADIO",11f,GREEN,true).apply { gravity=Gravity.CENTER }); radioCard.addView(text("Choose a song",10f,MUTED).apply { gravity=Gravity.CENTER }); radioCard.setOnClickListener { showRadioPicker() }
        discovery.addView(shuffleCard); discovery.addView(radioCard); c.addView(discovery)
        val stats=LinearLayout(this).apply { orientation=0; setPadding(14,14,14,14); background=android.graphics.drawable.GradientDrawable().apply { setColor(-1); cornerRadius=20f }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,18); layoutParams=lp }
        fun stat(value:String,label:String): LinearLayout { val box=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }; box.addView(text(value,21f,GREEN,true)); box.addView(text(label,10f,MUTED)); return box }
        stats.addView(stat(tracks.size.toString(),"SONGS ON DEVICE")); val line=View(this).apply { setBackgroundColor(0xFFE3EBE5.toInt()) }; stats.addView(line,LinearLayout.LayoutParams(1,42)); stats.addView(stat(history.total().toString(),"PLAYS RECORDED")); c.addView(stats)
        sectionTitle(c,"Forgotten gems","Your least-played tracks")
        if(tracks.isEmpty()) c.addView(emptyStateView("No music found yet","Add audio files to your phone, then tap scan.")) else tracks.take(5).forEach { trackRow(c,it) }
        if(tracks.isEmpty()) c.addView(emptyStateView("Your library is waiting","Scan your device to see your songs here."))
    }
    private fun radioRow(parent: LinearLayout, t: Track) {
        val row = LinearLayout(this).apply {
            orientation = 0
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10),dp(8),dp(8),dp(8))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(-1)
                cornerRadius = 14f
            }
            val lp = LinearLayout.LayoutParams(-1,-2)
            lp.setMargins(0,3,0,3)
            layoutParams = lp
        }
        val glyph = TextView(this).apply {
            text = "♫"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(GREEN)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(MINT)
                cornerRadius = 12f
            }
        }
        row.addView(glyph, LinearLayout.LayoutParams(dp(40),dp(40)))
        val labels = LinearLayout(this).apply {
            orientation = 1
            setPadding(10,0,6,0)
            layoutParams = LinearLayout.LayoutParams(0,-2,1f)
        }
        val title = text(t.title,13f,DEEP,true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val artist = text(t.artist,10f,MUTED).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        labels.addView(title)
        labels.addView(artist)
        row.addView(labels)
        val action = TextView(this).apply {
            text = "Radio  ›"
            textSize = 11f
            setTextColor(GREEN)
            gravity = Gravity.CENTER
            setPadding(dp(10),dp(8),dp(10),dp(8))
            minimumWidth = dp(68)
            minimumHeight = dp(48)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(PALE)
                cornerRadius = 12f
            }
            setOnClickListener { startRadio(t) }
        }
        row.addView(action)
        parent.addView(row)
    }

    private fun sectionTitle(c:LinearLayout,title:String,subtitle:String) { val box=LinearLayout(this).apply { orientation=1; setPadding(2,7,2,7) }; box.addView(text(title,17f,DEEP,true)); box.addView(text(subtitle,11f,MUTED)); c.addView(box) }
    private fun emptyStateView(title:String,subtitle:String): LinearLayout = LinearLayout(this).apply { orientation=1; setPadding(14,14,14,14); background=android.graphics.drawable.GradientDrawable().apply { setColor(-1); cornerRadius=16f }; addView(text(title,14f,DEEP,true)); addView(text(subtitle,11f,MUTED)) }
    private fun library(c: LinearLayout) {
        albumDisplayMode=getSharedPreferences("sivu_ui",MODE_PRIVATE).getString("album_display","List")?:"List"
        c.addView(text("Your library",23f,DEEP,true)); c.addView(text("${tracks.size} tracks · stored on this device",12f,MUTED))
        val search=EditText(this).apply { hint="Search songs, artists or albums"; isSingleLine=true; setPadding(14,12,14,12); background=android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius=dp(16).toFloat() } }; c.addView(search)
        val modes=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
        listOf("Songs","Albums","Artists","Years","Folders","Playlists","Auto mixes").forEach { mode ->
            val b=button(mode) { libraryMode=mode; render() }
            b.setTextColor(if (libraryMode == mode) -1 else GREEN)
            b.background=android.graphics.drawable.GradientDrawable().apply { setColor(if (libraryMode == mode) GREEN else PALE); cornerRadius=dp(18).toFloat() }
            val lp=LinearLayout.LayoutParams(-2,-2); lp.setMargins(dp(3),dp(4),dp(3),dp(4)); modes.addView(b,lp)
        }
        c.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false; addView(modes) })
        val viewOptions=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(0,dp(4),0,dp(4)) }
        viewOptions.addView(text("Album display",12f,MUTED).apply { layoutParams=LinearLayout.LayoutParams(0,-2,1f) })
        val viewToggle=button(if(albumDisplayMode=="List") "☷ List" else "▦ Grid") { albumDisplayMode=if(albumDisplayMode=="List") "Grid" else "List"; getSharedPreferences("sivu_ui",MODE_PRIVATE).edit().putString("album_display",albumDisplayMode).apply(); fill(search.text.toString()) }
        viewOptions.addView(viewToggle); c.addView(viewOptions)
        val list=LinearLayout(this).apply { orientation=1 }; c.addView(list)
        fun fill(q:String) {
            list.removeAllViews()
            val matched=tracks.filter { it.title.contains(q,true)||it.artist.contains(q,true)||it.album.contains(q,true)||it.path.contains(q,true) }
            when(libraryMode) {
                "Albums" -> {
                    val albums=matched.groupBy { it.album.ifBlank { "Unknown album" } }.toSortedMap().toList()
                    if(albumDisplayMode=="Grid") {
                        val grid=android.widget.GridLayout(this@MainActivity).apply { columnCount=2; useDefaultMargins=false }
                        albums.take(libraryVisibleLimit).forEach { (name,items) ->
                            val tile=LinearLayout(this@MainActivity).apply { orientation=1; gravity=Gravity.CENTER_HORIZONTAL; setPadding(dp(8),dp(8),dp(8),dp(8)); background=android.graphics.drawable.GradientDrawable().apply { setColor(0xFFF8F8F8.toInt()); cornerRadius=dp(12).toFloat() }; isClickable=true; isFocusable=true }
                            val cover=ImageView(this@MainActivity).apply { scaleType=ImageView.ScaleType.CENTER_CROP; setBackgroundColor(MINT); val id=items.firstOrNull()?.albumId?:-1L; if(id>0) try { setImageURI(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"),id)) } catch (_:Exception){} }
                            tile.addView(cover,LinearLayout.LayoutParams(-1,dp(130))); tile.addView(text(displayTitle(name),13f,DEEP,true).apply { maxLines=2; ellipsize=android.text.TextUtils.TruncateAt.END; gravity=Gravity.CENTER; setPadding(0,dp(5),0,0) }); tile.addView(text(songCountLabel(items.size),11f,MUTED).apply { gravity=Gravity.CENTER }); tile.setOnClickListener { showGroup(name,items) }
                            val glp=android.widget.GridLayout.LayoutParams().apply { width=0; height=-2; columnSpec=android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED,1f); setMargins(dp(3),dp(3),dp(3),dp(3)) }; grid.addView(tile,glp)
                        }; list.addView(grid)
                    } else albums.take(libraryVisibleLimit).forEach { (name,items) -> list.addView(albumCollectionRow(name,items)) }
                    if(albums.size>libraryVisibleLimit) list.addView(button("Load more albums (${albums.size-libraryVisibleLimit} remaining)") { libraryVisibleLimit+=100; fill(q) })
                }
                "Artists" -> matched.groupBy { it.artist }.toSortedMap().forEach { (name,items) -> list.addView(collectionRow("♫   ${displayArtist(name)}\n${songCountLabel(items.size)}") { showGroup(name,items) }) }
                "Years" -> matched.groupBy { if(it.year>0) it.year.toString() else "Year unknown" }.toSortedMap(compareByDescending { it }).forEach { (name,items) -> list.addView(collectionRow("◷   $name\n${songCountLabel(items.size)}") { showGroup(name,items) }) }
                "Folders" -> matched.groupBy { it.path.substringBeforeLast('/', "Unknown folder") }.toSortedMap().forEach { (name,items) -> list.addView(collectionRow("▤   ${name.substringAfterLast('/')}\n${songCountLabel(items.size)}") { showGroup(name,items) }) }
                "Playlists" -> { val prefs=getSharedPreferences("sivu_playlists", MODE_PRIVATE); val names=prefs.getStringSet("names", emptySet()).orEmpty().toList().sorted(); if(names.isEmpty()) list.addView(emptyStateView("No playlists yet","Use Add to playlist from a song or the full player.")); names.forEach { name -> list.addView(button("♫  $name") { val ids=prefs.getStringSet("playlist_$name",emptySet()).orEmpty(); showGroup(name,tracks.filter { ids.contains(it.id.toString()) }) }) } }
                "Auto mixes" -> {
                    list.addView(collectionRow("Recently added") { showGroup("Recently added",matched.sortedByDescending { it.id }.take(100)) })
                    list.addView(collectionRow("Most played") { showGroup("Most played",matched.sortedByDescending { history.count(it.id) }.take(100)) })
                    list.addView(collectionRow("Least played / forgotten gems") { showGroup("Forgotten gems",matched.sortedWith(compareBy<Track>{history.count(it.id)}.thenBy{history.lastPlayed(it.id)}).take(100)) })
                    list.addView(collectionRow("Never played") { showGroup("Never played",matched.filter { history.count(it.id)==0 }) })
                }
                else -> matched.take(libraryVisibleLimit).forEach { trackRow(list,it) }
            }
            if(libraryMode=="Songs" && matched.size>libraryVisibleLimit) list.addView(button("Load more songs (${matched.size-libraryVisibleLimit} remaining)") { libraryVisibleLimit+=100; fill(q) })
        }
        fill(""); search.addTextChangedListener(object: android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){libraryVisibleLimit=100;fill(s?.toString()?:"")}; override fun afterTextChanged(s:android.text.Editable?){} })
        c.addView(button("Smart shuffle all songs") { smartShuffle() })
    }
    private fun showRadioPicker() {
        if(tracks.isEmpty()) { Toast.makeText(this,"Scan your music first",Toast.LENGTH_SHORT).show(); return }
        val box=LinearLayout(this).apply { orientation=1; setPadding(dp(16),dp(8),dp(16),0) }
        val search=EditText(this).apply { hint="Search song, movie/album, or artist"; isSingleLine=true }
        box.addView(search)
        val categories=LinearLayout(this).apply { orientation=0 }
        var category="Songs"
        val list=LinearLayout(this).apply { orientation=1 }
        val scroll=ScrollView(this).apply { addView(list); layoutParams=LinearLayout.LayoutParams(-1,dp(360)) }
        fun refresh() {
            list.removeAllViews(); val q=search.text.toString().trim()
            val results=when(category) {
                "Albums" -> tracks.filter { it.album.contains(q,true) }.distinctBy { it.album.lowercase(Locale.ROOT) }.take(80)
                "Artists" -> tracks.filter { it.artist.contains(q,true) }.distinctBy { it.artist.lowercase(Locale.ROOT) }.take(80)
                else -> tracks.filter { it.title.contains(q,true)||it.album.contains(q,true)||it.artist.contains(q,true) }.take(100)
            }
            results.forEach { t ->
                val label=when(category) { "Albums" -> "▣  ${t.album} · ${tracks.count { it.album==t.album }} songs"; "Artists" -> "♫  ${t.artist}"; else -> "♫  ${displayTitle(t.title)}\n${displayArtist(t.artist)} · ${displayTitle(t.album)}" }
                list.addView(collectionRow(label) {
                    val seed=if(category=="Albums") tracks.firstOrNull { it.album==t.album }?:t else if(category=="Artists") tracks.firstOrNull { it.artist==t.artist }?:t else t
                    startRadio(seed); Toast.makeText(this,"Song radio started · ${displayTitle(seed.title)}",Toast.LENGTH_SHORT).show()
                    radioDialog?.dismiss()
                })
            }
            if(results.isEmpty()) list.addView(text("No matches found",13f,MUTED))
        }
        arrayOf("Songs","Albums","Artists").forEach { item -> val b=button(item) { category=item; refresh() }; categories.addView(b); if(item==category) { b.setTextColor(-1); b.backgroundTintList=android.content.res.ColorStateList.valueOf(GREEN) } }
        box.addView(categories); box.addView(scroll)
        search.addTextChangedListener(object:android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refresh()}; override fun afterTextChanged(s:android.text.Editable?){} })
        refresh()
        radioDialog=AlertDialog.Builder(this).setTitle("Create song radio").setView(box).setNegativeButton("Close",null).create().also { it.setOnDismissListener { radioDialog=null }; it.show() }
    }
    private var radioDialog: AlertDialog? = null

    private fun showGroup(name:String, items:List<Track>) {
        if(items.isEmpty()) { Toast.makeText(this,"No songs in this collection",Toast.LENGTH_SHORT).show(); return }
        val options=arrayOf("Play collection","Shuffle collection","Add all to queue","Create playlist from collection")
        AlertDialog.Builder(this).setTitle(name).setItems(options) { _,which -> when(which) {
            0 -> { queue=items.toMutableList(); queueIndex=0; play(items.first()) }
            1 -> { queue=items.shuffled().toMutableList(); queueIndex=0; shuffleEnabled=true; play(queue.first()) }
            2 -> { queue=items.toMutableList(); queueIndex=0; Toast.makeText(this,"${items.size} songs added to queue",Toast.LENGTH_SHORT).show() }
            3 -> { val input=EditText(this).apply { hint="Playlist name"; setText(name) }; AlertDialog.Builder(this).setTitle("Create playlist").setView(input).setPositiveButton("Save") { _,_ -> val n=input.text.toString().trim(); if(n.isNotEmpty()) { val prefs=getSharedPreferences("sivu_playlists",MODE_PRIVATE); val names=prefs.getStringSet("names",emptySet())?.toMutableSet()?:mutableSetOf(); names.add(n); prefs.edit().putStringSet("names",names).apply(); prefs.edit().putStringSet("playlist_$n",items.map{it.id.toString()}.toSet()).apply(); Toast.makeText(this,"Created $n",Toast.LENGTH_SHORT).show() } }.setNegativeButton("Cancel",null).show() }
        } }.show()
    }
    private fun insights(c: LinearLayout) {
        c.addView(text("Listening insights",25f,DEEP,true)); c.addView(text("Your listening, counted only after 80% is genuinely heard.",13f,MUTED))
        val row=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
        listOf("Day","Month","Year","All time").forEach { p -> val b=TextView(this).apply { text=p; textSize=12f; setTextColor(if(period==p) -1 else GREEN); setPadding(10,10,10,10); background=android.graphics.drawable.GradientDrawable().apply { setColor(if(period==p) GREEN else PALE); cornerRadius=18f }; setOnClickListener { period=p; render() } }; val lp=LinearLayout.LayoutParams(0,-2,1f); lp.setMargins(2,2,2,2); row.addView(b,lp) }; c.addView(row)
        val (from,to,label)=dateRange(); val total=history.total(from,to)
        val summary=card(); summary.addView(text(label.uppercase(Locale.getDefault()),12f,GREEN,true)); summary.addView(text("$total plays",28f,INK,true)); summary.addView(text("Listening events recorded by Sivu's Isaiaruvi",13f,MUTED)); c.addView(summary)
        c.addView(text("Most played in this period",19f,DEEP,true)); val top=history.top(from,to); if(top.isEmpty()) c.addView(card().apply { addView(text("No plays recorded yet",15f,DEEP,true)); addView(text("Keep listening. A track appears here after you have genuinely heard 80% of it.",12f,MUTED)) }) else top.forEachIndexed { i,p -> c.addView(card().apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; addView(text(String.format(Locale.getDefault(), "%02d", i+1),15f,GREEN,true), LinearLayout.LayoutParams(dp(34),-2)); val labels=LinearLayout(this@MainActivity).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }; labels.addView(text(displayTitle(p.first),14f,DEEP,true).apply { maxLines=2; ellipsize=android.text.TextUtils.TruncateAt.END }); labels.addView(text("${p.second} plays",11f,MUTED)); addView(labels) }) }
        c.addView(text("Custom date",19f,INK,true)); c.addView(text("Enter a date as YYYY-MM-DD",13f,MUTED)); val date=EditText(this).apply { hint="2026-10-22"; setSingleLine(); setText(customDay); setPadding(12,8,12,8) }; c.addView(date); c.addView(button("Show that day's plays") { customDay=date.text.toString().trim(); period="Custom"; render() })
        if(period=="Custom") { val (a,b,l)=dateRange(); c.addView(text("$l: ${history.total(a,b)} plays",16f,GREEN,true)) }
        c.addView(text("Per-song play counts",19f,DEEP,true)); tracks.sortedByDescending { history.count(it.id) }.take(30).forEach { t -> c.addView(card().apply { addView(text(displayTitle(t.title),14f,DEEP,true).apply { maxLines=2; ellipsize=android.text.TextUtils.TruncateAt.END }); addView(text(displayArtist(t.artist),11f,MUTED).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END }); addView(text("${history.count(t.id)} plays",11f,GREEN,true)) }) }
    }
    private fun dateRange(): Triple<Long,Long,String> {
        val cal=Calendar.getInstance(); val now=System.currentTimeMillis()
        if(period=="Custom" && customDay.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) { try { val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply { isLenient=false }.parse(customDay)!!; val a=Calendar.getInstance().apply { time=d; set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis; return Triple(a,a+86_399_999,customDay) } catch (_:Exception){} }
        when(period) { "Day" -> { cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; "Month" -> { cal.set(Calendar.DAY_OF_MONTH,1); cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; "Year" -> { cal.set(Calendar.DAY_OF_YEAR,1); cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; else -> return Triple(0L,now,"All time") }
        val label=when(period) { "Day" -> "Today"; "Month" -> SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(Date()); else -> cal.get(Calendar.YEAR).toString() }
        return Triple(cal.timeInMillis,now,label)
    }
    private fun trackRow(parent: LinearLayout,t:Track) {
        val r=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(8),dp(7),dp(8),dp(7)); background=android.graphics.drawable.GradientDrawable().apply { setColor(-1); cornerRadius=14f }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,3,0,3); layoutParams=lp }
        val art=TextView(this).apply { text="♫"; textSize=19f; gravity=Gravity.CENTER; setTextColor(GREEN); background=android.graphics.drawable.GradientDrawable().apply { setColor(MINT); cornerRadius=12f } }; r.addView(art,LinearLayout.LayoutParams(dp(44),dp(44)))
        val labels=LinearLayout(this).apply { orientation=1; setPadding(10,0,4,0); layoutParams=LinearLayout.LayoutParams(0,-2,1f) }; labels.addView(text(displayTitle(t.title),13f,DEEP,true).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
        labels.addView(text("${displayArtist(t.artist)}  ·  ${history.count(t.id)} plays",10f,MUTED).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
        r.addView(labels)
        val play=TextView(this).apply { text="▶"; textSize=18f; minimumWidth=dp(48); minimumHeight=dp(48); gravity=Gravity.CENTER; setTextColor(-1); background=android.graphics.drawable.GradientDrawable().apply { setColor(GREEN); cornerRadius=24f }; setOnClickListener { play(t) }; setOnLongClickListener { AlertDialog.Builder(this@MainActivity).setTitle(t.title).setItems(arrayOf("Play","Similar songs","Add to playlist","Start similar radio")) { _,which -> when(which){0->play(t);1->showSimilarSongs(t);2->showPlaylistDialog(t);3->startRadio(t)} }; true } }; r.addView(play,LinearLayout.LayoutParams(dp(48),dp(48))); parent.addView(r)
    }
    private fun play(t:Track) {
        try { player?.release() } catch (_:Exception) {}
        player=null
        playbackReady=false
        current=t
        val queuedIndex = queue.indexOfFirst { it.id == t.id }
        if (queuedIndex >= 0) queueIndex = queuedIndex
        try {
            player=MediaPlayer().apply {
                setDataSource(this@MainActivity,t.uri)
                setOnPreparedListener { mp ->
                    playbackReady=true
                    try { mp.start() } catch (_:Exception) {}
                    updatePlaybackNotification()
                    if (::root.isInitialized) render()
                }
                setOnCompletionListener { if (repeatEnabled) play(t) else next() }
                setOnErrorListener { _, _, _ ->
                    playbackReady=false
                    Toast.makeText(this@MainActivity,"This track could not be played",Toast.LENGTH_SHORT).show()
                    true
                }
                prepareAsync()
            }
            listeningStartMs = System.currentTimeMillis()
            listenedMs = 0L
            listenedRanges.clear()
            lastPositionMs = -1
            lastProgressTrackId = t.id
            lastRecordedTrackId = -1L
            nowPlayingLabel?.text="${t.title}  ·  ${t.artist}"
        } catch(e:Exception) {
            playbackReady=false
            Toast.makeText(this,"Couldn't play this track",Toast.LENGTH_SHORT).show()
        }
        if(::root.isInitialized) render()
        updatePlaybackNotification()
    }
    private fun smartShuffle() {
        if(tracks.isEmpty()) { Toast.makeText(this,"No music found. Add audio files and scan again.",Toast.LENGTH_LONG).show(); return }
        val now=System.currentTimeMillis(); queue=tracks.sortedBy { t -> val plays=history.count(t.id); val last=history.lastPlayed(t.id); (plays*100L) + (if(last==0L) -50_000_000L else max(0L, 50_000_000L-(now-last)/1000L)) }.toMutableList()
        // Shuffle within low-play-count groups, preserving the bias toward underplayed tracks.
        queue=queue.groupBy { history.count(it.id) }.toSortedMap().values.flatMap { it.shuffled() }.toMutableList(); queueIndex=0; play(queue[queueIndex]); tab="Home"; render(); Toast.makeText(this,"Smart shuffle started",Toast.LENGTH_SHORT).show()
    }
    private fun moodTags(t:Track):Set<String> {
        val text=(t.title+" "+t.album+" "+t.artist).lowercase(Locale.ROOT)
        val tags=mutableSetOf<String>()
        val moods=mapOf(
            "sad" to listOf("sad","sogam","sogam","kanneer","azhu","pirivu","miss","pain","lonely","marana","iravin","nizhal","uyire","uyir","marandha"),
            "romantic" to listOf("love","kadhal","kaadhal","anbe","anbu","uyire","romance","nenje","nenju","malar","malare","paarvai"),
            "folk" to listOf("folk","kuthu","dappan","parai","ooru","gramam","village","thara","local","gana","gaana","muthu","maari"),
            "dance" to listOf("dance","party","beat"," kuthu","mass","gethu","vaathi","vaathi","celebration"),
            "devotional" to listOf("devotional","amman","murugan","sivan","krishna","jesus","allah","bhakthi","om","deivam"),
            "melody" to listOf("melody","mellisa","nilave","nilavu","vennilave","thendral","poove","poo","raagam")
        )
        moods.forEach { (m,words)-> if(words.any { text.contains(it) }) tags.add(m) }
        if(t.artist.equals("Unknown artist",true)) tags.add("unknown")
        return tags
    }
    private fun similarityScore(seed:Track, candidate:Track, cachedPlays: Int = history.count(candidate.id)):Int {
        var score=0
        if(candidate.artist.equals(seed.artist,true)) score+=24
        // Same album/movie is deliberately excluded by default.
        if(seed.year>0 && candidate.year>0) score += (12 - kotlin.math.abs(seed.year-candidate.year).coerceAtMost(12))
        val a=moodTags(seed); val b=moodTags(candidate)
        score += a.intersect(b).size*18
        val wordsA=(seed.title+" "+seed.album).lowercase(Locale.ROOT).split(Regex("[^a-z0-9]+" )).filter{it.length>3}.toSet()
        val wordsB=(candidate.title+" "+candidate.album).lowercase(Locale.ROOT).split(Regex("[^a-z0-9]+" )).filter{it.length>3}.toSet()
        score += wordsA.intersect(wordsB).size*5
        if(a.isNotEmpty() && b.isNotEmpty() && a.intersect(b).isEmpty()) score-=15
        score -= cachedPlays*2
        if(history.lastPlayed(candidate.id)>0) score-=((System.currentTimeMillis()-history.lastPlayed(candidate.id))/86_400_000L).let { if(it<2) 10 else 0 }.toInt()
        return score
    }
    private fun similarTracks(seed:Track):List<Track> {
        // Keep recommendations cross-movie by default. Cache play counts during one ranking pass
        // so thousands of synchronous SQLite queries cannot freeze the UI.
        val candidates = tracks.filter { candidate ->
            candidate.id != seed.id && !(seed.albumId > 0 && candidate.albumId == seed.albumId) && !(seed.album.isNotBlank() && candidate.album.equals(seed.album, true))
        }
        val playCounts = candidates.associate { it.id to history.count(it.id) }
        return candidates.sortedByDescending { similarityScore(seed, it, playCounts[it.id] ?: 0) }.take(40)
    }
    private fun showSimilarSongs(seed:Track) {
        val loading = AlertDialog.Builder(this).setTitle("Finding similar songs…")
            .setMessage("Checking your library without blocking playback.")
            .setNegativeButton("Cancel", null).create()
        loading.setCanceledOnTouchOutside(true)
        loading.show()
        libraryExecutor.execute {
            val matches = similarTracks(seed)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                loading.dismiss()
                showSimilarSongsResults(seed, matches)
            }
        }
    }
    private fun showSimilarSongsResults(seed: Track, matches: List<Track>) {
        if (matches.isEmpty()) {
            Toast.makeText(this, "No other songs found", Toast.LENGTH_SHORT).show()
            return
        }
        val panel = LinearLayout(this).apply {
            orientation = 1
            setPadding(dp(16), dp(4), dp(16), dp(8))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        panel.addView(text("Audio-style discovery · same album/movie excluded", 12f, MUTED))
        val search = EditText(this).apply { hint = "Search recommendations"; setSingleLine(true); textSize = 14f }
        panel.addView(search)
        val scroller = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
        }
        val list = LinearLayout(this).apply { orientation = 1 }
        val recommendationRows = mutableListOf<Pair<Track, LinearLayout>>()
        matches.take(25).forEachIndexed { index, track ->
            val row = LinearLayout(this).apply {
                orientation = 0
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(8), dp(8))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(-1); cornerRadius = dp(12).toFloat()
                    setStroke(dp(1), 0xFFDCE9DF.toInt())
                }
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, dp(3), 0, dp(3))
                layoutParams = lp
            }
            val labels = LinearLayout(this).apply {
                orientation = 1
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            labels.addView(text(displayTitle(track.title), 14f, DEEP, true).apply {
                maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            labels.addView(text(displayArtist(track.artist), 12f, MUTED).apply {
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            val sharedTags = moodTags(track).intersect(moodTags(seed))
            val reason = when {
                track.artist.equals(seed.artist, true) -> "Same artist"
                sharedTags.isNotEmpty() -> "Shared tags: ${sharedTags.joinToString(", ")}"
                else -> "Metadata match"
            }
            labels.addView(text(reason, 10f, MUTED).apply { maxLines = 1 })
            row.addView(labels)
            val more = TextView(this).apply {
                text = "⋮"; textSize = 24f; gravity = Gravity.CENTER
                setTextColor(GREEN); minimumWidth = dp(40); minimumHeight = dp(44)
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(displayTitle(track.title))
                        .setItems(arrayOf("Play now", "Add to queue", "Add to playlist", "Start similar radio")) { _, action ->
                            when (action) {
                                0 -> play(track)
                                1 -> {
                                    val insertAt = (queueIndex + 1).coerceIn(0, queue.size)
                                    queue.add(insertAt, track)
                                    Toast.makeText(this@MainActivity, "Added to queue", Toast.LENGTH_SHORT).show()
                                }
                                2 -> showPlaylistDialog(track)
                                3 -> startRadio(track)
                            }
                        }.show()
                }
            }
            row.addView(more)
            row.setOnClickListener { play(track) }
            list.addView(row)
            recommendationRows += track to row
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString()?.trim().orEmpty()
                recommendationRows.forEach { (track, row) -> row.visibility = if (q.isBlank() || track.title.contains(q, true) || track.artist.contains(q, true)) View.VISIBLE else View.GONE }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        scroller.addView(list)
        panel.addView(scroller, LinearLayout.LayoutParams(-1, dp(460)))
        val dialog = AlertDialog.Builder(this)
            .setTitle("Similar songs")
            .setMessage("For: ${displayTitle(seed.title)}")
            .setView(panel)
            .setPositiveButton("Add top matches to playlist") { _, _ ->
                val input = EditText(this).apply {
                    hint = "Playlist name"
                    setText("Similar to ${displayTitle(seed.title)}")
                }
                AlertDialog.Builder(this).setTitle("Create similar-song playlist").setView(input)
                    .setPositiveButton("Create") { _, _ ->
                        val name = input.text.toString().trim()
                        if (name.isNotEmpty()) {
                            val prefs = getSharedPreferences("sivu_playlists", MODE_PRIVATE)
                            val names = prefs.getStringSet("names", emptySet())?.toMutableSet() ?: mutableSetOf()
                            names.add(name)
                            prefs.edit().putStringSet("names", names)
                                .putStringSet("playlist_$name", (listOf(seed) + matches.take(25)).map { it.id.toString() }.toSet())
                                .apply()
                            Toast.makeText(this, "Created $name", Toast.LENGTH_SHORT).show()
                        }
                    }.setNegativeButton("Cancel", null).show()
            }
            .setNegativeButton("Close", null)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), (resources.displayMetrics.heightPixels * 0.78f).toInt())
        }
        dialog.setCanceledOnTouchOutside(true)
        dialog.setCancelable(true)
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.white)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), (resources.displayMetrics.heightPixels * 0.78f).toInt())
    }
    private fun startRadio(seed:Track) {
        Toast.makeText(this, "Building Song Radio…", Toast.LENGTH_SHORT).show()
        libraryExecutor.execute {
            val recommendations = similarTracks(seed)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                queue = recommendations.toMutableList()
                queue.add(0, seed)
                queueIndex = 0
                play(seed)
                Toast.makeText(this, "Song Radio ready · ${recommendations.size} recommendations", Toast.LENGTH_LONG).show()
                if (::root.isInitialized) render()
            }
        }
    }
    private fun showFullPlayer() {
        if (current == null && tracks.isEmpty()) {
            Toast.makeText(this, "Your library is empty", Toast.LENGTH_SHORT).show()
            return
        }
        playerScreenOpen = true
        render()
    }

    private fun renderFullPlayerScreen() {
        val t = current ?: tracks.firstOrNull() ?: return
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(8), dp(20), dp(14))
            setBackgroundColor(0xFFFFFFFF.toInt())
            fitsSystemWindows = true
        }
        val top = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL }
        val back = TextView(this).apply {
            text = "‹"; textSize = 36f; gravity = Gravity.CENTER
            setTextColor(GREEN); minimumWidth = dp(52); minimumHeight = dp(48)
            contentDescription = "Back to library"
            setOnClickListener { playerScreenOpen = false; render() }
        }
        top.addView(back)
        val heading = text("NOW PLAYING", 13f, GREEN, true).apply { gravity = Gravity.CENTER }
        top.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val more = TextView(this).apply {
            text = "⋮"; textSize = 26f; gravity = Gravity.CENTER
            setTextColor(GREEN); minimumWidth = dp(44); minimumHeight = dp(48)
            setOnClickListener { showQueueDialog() }
        }
        top.addView(more); root.addView(top)

        val artFrame = FrameLayout(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply { setColor(MINT); cornerRadius = dp(26).toFloat() }
        }
        val fallback = TextView(this).apply {
            text = "♫"; textSize = 76f; gravity = Gravity.CENTER; setTextColor(GREEN)
        }
        artFrame.addView(fallback, FrameLayout.LayoutParams(-1, -1))
        val art = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        if (t.albumId > 0) {
            try { art.setImageURI(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), t.albumId)) } catch (_: Exception) {}
        }
        artFrame.addView(art, FrameLayout.LayoutParams(-1, -1))
        artFrame.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { swipeStartX = event.x; swipeStartY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - swipeStartX; val dy = event.y - swipeStartY
                    if (kotlin.math.abs(dx) > dp(70) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f) {
                        if (dx < 0) next() else previous()
                        true
                    } else false
                }
                else -> true
            }
        }
        val artLp = LinearLayout.LayoutParams(-1, 0, 4f); artLp.setMargins(0, dp(18), 0, dp(18)); root.addView(artFrame, artLp)

        root.addView(text(displayTitle(t.title), 22f, DEEP, true).apply { gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        root.addView(text(displayArtist(t.artist), 15f, MUTED).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        root.addView(text("A play counts after 80% actual listening", 11f, MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })

        val seek = SeekBar(this).apply { max = 1000; progress = 0; contentDescription = "Seek through track" }
        fullPlayerSeek = seek
        val seekLp = LinearLayout.LayoutParams(-1, dp(44)); seekLp.topMargin = dp(12); root.addView(seek, seekLp)
        val times = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL }
        val elapsed = text("0:00", 12f, MUTED); val total = text(formatTime(t.durationMs), 12f, MUTED)
        fullPlayerElapsed = elapsed; fullPlayerTotal = total
        times.addView(elapsed, LinearLayout.LayoutParams(0, -2, 1f)); times.addView(total); root.addView(times)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) try { player?.seekTo((progress / 1000f * t.durationMs).toInt()); lastPositionMs = -1 } catch (_: Exception) {}
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val controls = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(12)) }
        fun control(label: String, selected: Boolean = false, large: Boolean = false, action: () -> Unit) {
            val b = TextView(this).apply {
                text = label; textSize = if (large) 28f else 20f; gravity = Gravity.CENTER
                setTextColor(if (selected) -1 else GREEN)
                background = android.graphics.drawable.GradientDrawable().apply { setColor(if (selected) GREEN else MINT); cornerRadius = dp(32).toFloat() }
                minimumWidth = dp(if (large) 64 else 52); minimumHeight = dp(if (large) 64 else 52)
                contentDescription = when(label) { "Ⅱ" -> "Pause"; "▶" -> "Play"; "|◀" -> "Previous track"; "▶|" -> "Next track"; "⤨" -> "Shuffle"; else -> "Repeat" }
                setOnClickListener { action() }
            }
            val lp = LinearLayout.LayoutParams(-2, -2); lp.setMargins(dp(4), 0, dp(4), 0); controls.addView(b, lp)
        }
        control("⤨", shuffleEnabled) { toggleShuffle(); render() }
        control("|◀") { previous(); render() }
        control(if (tryIsPlaying()) "Ⅱ" else "▶", large = true) { togglePlayback(); render() }
        control("▶|") { next(); render() }
        control("↻", repeatEnabled) { repeatEnabled = !repeatEnabled; Toast.makeText(this, if (repeatEnabled) "Repeat on" else "Repeat off", Toast.LENGTH_SHORT).show(); render() }
        root.addView(controls)

        val actionRows = LinearLayout(this).apply { orientation = 1; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(4)) }
        val rowOne = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER }
        val rowTwo = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER }
        fun actionButton(parent: LinearLayout, label: String, action: () -> Unit) {
            val b = button(label, action)
            val lp = LinearLayout.LayoutParams(0, dp(48), 1f); lp.setMargins(dp(3), dp(3), dp(3), dp(3)); parent.addView(b, lp)
        }
        actionButton(rowOne, "＋ Playlist") { showPlaylistDialog(t) }
        actionButton(rowOne, "♫ Similar") { showSimilarSongs(t) }
        actionButton(rowTwo, "☷ Queue") { showQueueDialog() }
        actionButton(rowTwo, "⌂ Library") { playerScreenOpen = false; tab = "Library"; render() }
        actionRows.addView(rowOne); actionRows.addView(rowTwo); root.addView(actionRows)
        setContentView(root)
    }

    private fun formatTime(ms: Long): String {
        val sec = (ms / 1000).toInt()
        return String.format(Locale.getDefault(), "%d:%02d", sec / 60, sec % 60)
    }

    private fun showPlaylistDialog(track: Track) {
        val prefs = getSharedPreferences("sivu_playlists", MODE_PRIVATE)
        val existing = prefs.getStringSet("names", emptySet())?.toMutableSet() ?: mutableSetOf()
        val options = (existing.toList() + "＋ Create new playlist").toTypedArray()
        AlertDialog.Builder(this).setTitle("Add to playlist").setItems(options) { _, which ->
            if (which == options.lastIndex) {
                val input = EditText(this).apply { hint = "Playlist name" }
                AlertDialog.Builder(this).setTitle("Create playlist").setView(input)
                    .setPositiveButton("Create and add") { _, _ ->
                        val name = input.text.toString().trim()
                        if (name.isNotEmpty()) {
                            existing.add(name); prefs.edit().putStringSet("names", existing).apply()
                            addTrackToPlaylist(prefs, name, track)
                        }
                    }.setNegativeButton("Cancel", null).show()
            } else addTrackToPlaylist(prefs, options[which], track)
        }.setNegativeButton("Cancel", null).show()
    }

    private fun addTrackToPlaylist(prefs: android.content.SharedPreferences, name: String, track: Track) {
        val key = "playlist_" + name
        val ids = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.add(track.id.toString())
        prefs.edit().putStringSet(key, ids).apply()
        Toast.makeText(this, "Added to $name", Toast.LENGTH_SHORT).show()
    }

    private fun toggleShuffle() {
        shuffleEnabled = !shuffleEnabled
        if (shuffleEnabled) {
            val nowId = current?.id
            val rest = (if (queue.isNotEmpty()) queue else tracks.toMutableList()).filter { it.id != nowId }.shuffled()
            queue = mutableListOf<Track>().apply { if (current != null) add(current!!); addAll(rest) }
            queueIndex = if (current != null) 0 else 0
        } else if (queue.isEmpty()) queue = tracks.toMutableList()
        Toast.makeText(this, if (shuffleEnabled) "Shuffle on" else "Shuffle off", Toast.LENGTH_SHORT).show()
        updatePlaybackNotification()
    }

    private fun previous() {
        val p = player
        if (p != null && playbackReady) {
            try { if (p.currentPosition > 3000) { p.seekTo(0); return } } catch (_: Exception) {}
        }
        if (queue.isEmpty()) queue = tracks.toMutableList()
        if (queue.isEmpty()) return
        queueIndex = if (queueIndex <= 0) queue.lastIndex else queueIndex - 1
        play(queue[queueIndex])
    }

    private fun showQueueDialog() {
        if (queue.isEmpty()) current?.let { queue.add(it); queueIndex = 0 }
        if (queue.isEmpty()) { Toast.makeText(this, "Queue is empty", Toast.LENGTH_SHORT).show(); return }
        val labels = queue.mapIndexed { i, t -> (if (i == queueIndex) "▶  " else "    ") + t.title + " — " + t.artist }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Up next · ${queue.size} tracks").setItems(labels) { _, which -> queueIndex = which; play(queue[which]); if (playerScreenOpen) render() }
            .setNeutralButton("Clear queue") { _, _ -> queue.clear(); queueIndex = 0; Toast.makeText(this, "Queue cleared", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Close", null).show()
    }

    private fun next() {
        if (queue.isEmpty()) {
            if (tracks.isEmpty()) return
            queue = tracks.toMutableList()
            queueIndex = tracks.indexOfFirst { it.id == current?.id }.coerceAtLeast(0)
        }
        if (shuffleEnabled && queue.size > 1) {
            val currentId = current?.id
            val choices = queue.indices.filter { queue[it].id != currentId }
            queueIndex = choices.randomOrNull() ?: ((queueIndex + 1) % queue.size)
        } else queueIndex = (queueIndex + 1) % queue.size
        play(queue[queueIndex])
    }
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (playerScreenOpen) {
            playerScreenOpen = false
            render()
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() { handler.removeCallbacks(progressTicker); try { player?.release() } catch (_:Exception) {}; player=null; try { mediaSession?.isActive = false; mediaSession?.release() } catch (_: Exception) {}; mediaSession=null; super.onDestroy() }
}

# Sivu's Isaiaruvi — PocketBuilder project

A native Android local music player project for importing into an Android build app such as PocketBuilder.

## Import/build
1. Download this ZIP to your Android phone.
2. In PocketBuilder, choose its option to import/open an existing Android project or source ZIP.
3. Select this ZIP (or extract it first if PocketBuilder requires a folder).
4. Open the project folder `SivusIsaiaruvi` — the folder containing `settings.gradle.kts`.
5. Allow the builder to sync/download the Android Gradle plugins, then build an APK.
6. Install the APK and grant music/audio access when prompted.

If PocketBuilder only accepts a single source file or a web project, it may not support this native Kotlin/Gradle project format. Choose its existing Android/Gradle project import mode if available.

## App features
- Scans local music stored on the device
- Searchable song library
- Smart shuffle biased toward less-played songs and away from recent repeats
- Similar-song radio based on artist, album and title keywords (metadata-based; not acoustic similarity yet)
- Listening history and play-count insights by date range
- Compact emerald-and-white interface with a persistent mini-player

## Project details
- Native Android app written in Kotlin
- Gradle Kotlin DSL
- Namespace/application ID: `com.melo.localmusic`
- Minimum Android version: Android 8.0 (API 26)
- Version: 1.1.0


## Version 1.3 UI and playback fixes
- Applies system-bar safe-area handling for Android status/navigation areas.
- Uses larger 48dp playback controls with content descriptions.
- Keeps mini-player controls in sync with playback state and waits for MediaPlayer preparation before starting.
- Refines spacing and the Smart Shuffle card for a cleaner, more compact presentation.


## v1.5 Smart Discovery
- Meaningful listens count at 80% of track duration using sampled playback-position deltas; seeking does not count as listened time.
- Library views: songs, albums, artists, years, folders, saved playlists, and automatic mixes.
- Folder exclusions are applied during rescans using matching folder names.
- Similar songs and radio use best-effort metadata/mood keyword matching (artist, album, year, title/album keywords, listening history). This is not yet acoustic fingerprinting or machine-learning audio analysis.
- Long-press a track for Play, Similar songs, Add to playlist, and Similar radio.


## v1.6 Player & library reliability update
- Library category chips now scroll horizontally instead of overflowing the screen.
- Full-player controls include previous, play/pause, next, shuffle, and repeat; queue can be inspected and a queued track selected.
- Previous restarts the current track when playback is beyond the first few seconds; otherwise it moves to the previous queued track.
- Queue index is synchronized when a queued track is started.
- Meaningful-listen tracking now measures the union of forward-played time ranges, so seeking forward and replaying the same section cannot inflate the 80% threshold.
- Similar Songs remains metadata-based in v1.6. True audio-feature extraction (tempo, timbre, rhythm, tonal descriptors or embeddings) is not included yet and should be added only after checking library licensing and Android build compatibility.

Version: 1.6.0 (source update; build must be verified by GitHub Actions).

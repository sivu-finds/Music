# Sivu's Isaiaruvi — local music player for Android

A native Kotlin starter project for the Samsung Galaxy S24 Ultra with a premium white UI, local audio library scanning, playback, underplayed-first smart shuffle, local similar-song queue, and SQLite-backed listening history.

## Open and run
1. Install Android Studio (current stable) and a JDK supported by that Android Studio release.
2. Open this folder (`SivusIsaiaruviAndroid`) in Android Studio.
3. Allow Gradle sync to finish. The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.
4. Connect the Samsung S24 Ultra with Developer options + USB debugging enabled, or start an emulator.
5. Run the `app` configuration. Accept the music permission prompt.

## Current MVP features
- Reads audio tracks indexed by Android MediaStore; no upload or streaming account is used.
- Playback for local audio files, with previous screen mini-player controls for play/pause/next.
- Smart shuffle favors tracks with fewer recorded plays, then shuffles within play-count groups.
- Similar-song radio scores shared artist, album, and title/artist keywords.
- SQLite stores play events locally and exposes Day, Month, Year, All time, and custom-date counts plus per-song counts.
- White UI with forest-green accents.

## Important limitations of this starter
- This is source code, not a prebuilt APK. Build it with Android Studio to install it on your phone.
- The MVP does not yet provide background playback/media notification, lock-screen controls, audio fingerprinting, BPM/key/mood analysis, album-art extraction, or a full-range date picker. Similarity currently uses local metadata heuristics rather than an audio-embedding model.
- A play is counted when playback is initiated, not after a minimum listen duration. A production release should count a play after e.g. 30 seconds or 50% of a track.
- Smart shuffle and radio are local heuristics, not cloud AI; they work offline.

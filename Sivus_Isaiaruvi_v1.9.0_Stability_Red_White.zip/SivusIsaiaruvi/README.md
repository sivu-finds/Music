# Sivu's Isaiaruvi — v1.9.0 stability and visual update

This is an incremental update based on the v1.8.2 project.

## Included in this iteration
- White-and-signature-red visual palette across the existing screens.
- Background MediaStore library scanning so scanning does not block the UI thread.
- Similar-song ranking moved off the UI thread, with a loading/cancel dialog.
- Search field for filtering the Similar Songs list.
- Same album/movie exclusion by album ID and album name for Similar Songs / Song Radio.
- Dismissible Similar Songs dialog (Back and outside tap).
- Horizontal swipe on the Now Playing artwork to move to next/previous track.
- Version set to 1.9.0 / versionCode 10.

## Not yet implemented / must not be assumed complete
- Real audio DSP/feature extraction: Similar Songs still uses metadata heuristics, not measured audio features.
- Dedicated foreground Media3 playback service. Existing Android MediaSession/MediaPlayer implementation remains.
- Functional crossfade, equalizer, playback-speed control, ReplayGain, lyrics integration, full theme switching, backup/restore, and calendar Insights redesign.
- A verified Android build. The ZIP can be inspected and uploaded to GitHub Actions, but it has not been compiled in this environment.

Build with the repository's existing GitHub Actions workflow and inspect the full build log before installing.

# Sivu's Isaiaruvi — v1.13.0 UX Foundation

Android local music player project for the existing GitHub Actions APK workflow.

## UX and responsiveness work in this release
- Keep the main app shell, mini-player, and bottom navigation mounted while changing tabs and library categories; refresh only the active content region.
- Avoid rebuilding the full screen for play/pause and notification playback actions.
- Animate content-region changes and album artwork changes subtly rather than fading/replacing the entire activity for every action.
- Keep song, album, and artist lists paginated and retain the searchable Song Radio picker.
- Keep the Similar Songs dialog free of the redundant search field; selecting a recommendation closes the dialog before playback.
- Move Smart Shuffle history ranking off the main thread.
- Browse exact folder paths to exclude from MediaStore scanning.
- Add functional accent colours, light/dark/follow-system palette selection, playback speed, sleep timer, and system equalizer preset access where the device supports it.
- Keep the player repeat modes Off, All, and One, and provide Shuffle, Smart Shuffle, and Off choices.
- Remove the unnecessary “80% actual listening” label from the user-facing player UI.
- Simplify Insights per-track counts to a compact ranked list.

## Build
Upload the project files to the existing repository and keep its `.github/workflows/build-apk.yml`. Run the workflow and download the APK artifact if the job succeeds.

## Verification status
The source ZIP has been checked for archive integrity and Kotlin syntax was inspected with the local compiler parser. This environment does not include an Android SDK or Gradle installation, so no Android APK compilation or device test has been performed here. GitHub Actions is still required to verify the build.

## Known work for a truly production-ready release
This is a substantial responsiveness/UI foundation, not a claim that every premium-player feature is complete. Playback still uses the legacy `MediaPlayer` API inside the activity rather than a dedicated Media3 foreground service; robust gapless/crossfade playback, lyrics, ReplayGain, backup/restore, and device-level transition testing remain future work. Equalizer availability depends on Android audio effects exposed by the device.

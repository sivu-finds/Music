package com.melo.localmusic

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.media.MediaMetadata
import android.os.Handler
import android.os.Looper
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import android.view.MotionEvent
import java.util.concurrent.Executors
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

private var GREEN = 0xFFE51B35.toInt()
private var INK = 0xFF202020.toInt()
private var MUTED = 0xFF777777.toInt()
private var PALE = 0xFFF5F5F5.toInt()
private var DEEP = 0xFF202020.toInt()
private var MINT = 0xFFFCE8EC.toInt()
private const val REQ_AUDIO = 441

data class Track(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val durationMs: Long, val path: String = "", val year: Int = 0, val albumId: Long = -1L)

class PlayHistory(context: android.content.Context) : SQLiteOpenHelper(context, "sivus_isaiaruvi_history.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE plays(id INTEGER PRIMARY KEY AUTOINCREMENT, track_id INTEGER NOT NULL, title TEXT, artist TEXT, played_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX plays_date ON plays(played_at)")
        db.execSQL("CREATE INDEX plays_track ON plays(track_id)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun record(t: Track) { writableDatabase.execSQL("INSERT INTO plays(track_id,title,artist,played_at) VALUES(?,?,?,?)", arrayOf(t.id, t.title, t.artist, System.currentTimeMillis())) }
    fun count(id: Long): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM plays WHERE track_id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    fun lastPlayed(id: Long): Long = readableDatabase.rawQuery("SELECT MAX(played_at) FROM plays WHERE track_id=?", arrayOf(id.toString())).use { if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else 0L }
    fun total(from: Long = 0L, to: Long = Long.MAX_VALUE): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM plays WHERE played_at>=? AND played_at<=?", arrayOf(from.toString(), to.toString())).use { if(it.moveToFirst()) it.getInt(0) else 0 }
    fun allStats(): Map<Long, Pair<Int, Long>> {
        val out = HashMap<Long, Pair<Int, Long>>()
        readableDatabase.rawQuery("SELECT track_id, COUNT(*) AS c, MAX(played_at) AS last FROM plays GROUP BY track_id", null).use { c ->
            while (c.moveToNext()) out[c.getLong(0)] = c.getInt(1) to (if (c.isNull(2)) 0L else c.getLong(2))
        }
        return out
    }
    fun top(from: Long, to: Long): List<Pair<String,Int>> {
        val out = mutableListOf<Pair<String,Int>>()
        readableDatabase.rawQuery("SELECT title,COUNT(*) c FROM plays WHERE played_at>=? AND played_at<=? GROUP BY track_id ORDER BY c DESC LIMIT 8", arrayOf(from.toString(),to.toString())).use { c -> while(c.moveToNext()) out += (c.getString(0) ?: "Unknown") to c.getInt(1) }
        return out
    }
}

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var history: PlayHistory
    private val tracks = mutableListOf<Track>()
    private val libraryExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var scanInProgress = false
    private var swipeStartX = 0f
    private var swipeStartY = 0f
    private var player: MediaPlayer? = null
    private var mediaSession: MediaSession? = null
    private val notificationChannelId = "sivus_isaiaruvi_playback"
    private val playbackNotificationId = 1808
    private var current: Track? = null
    private var queue = mutableListOf<Track>()
    private var queueIndex = 0
    private var tab = "Home"
    private var period = "Month"
    private var customDay = ""
    private var nowPlayingLabel: TextView? = null
    private var playbackReady = false
    private var shuffleEnabled = false
    private var repeatMode = 0 // 0 = off, 1 = repeat all, 2 = repeat one
    private val handler = Handler(Looper.getMainLooper())
    private var listeningStartMs = 0L
    private var lastRecordedTrackId = -1L
    private var listenedMs = 0L
    private val listenedRanges = mutableListOf<Pair<Long, Long>>()
    private var lastPositionMs = -1
    private var lastProgressTrackId = -1L
    private var libraryMode = "Songs"
    private var albumDisplayMode = "List"
    private var libraryVisibleLimit = 100
    private var librarySearchQuery = ""
    private var lastArtworkSwipeAt = 0L
    private var playerScreenOpen = false
    private var fullPlayerSeek: SeekBar? = null
    private var fullPlayerElapsed: TextView? = null
    private var fullPlayerTotal: TextView? = null
    private var shellTab: String? = null
    private var contentTabRendered: String? = null
    private var mainContentView: LinearLayout? = null
    private var mainScrollView: ScrollView? = null
    private var globalSearchQuery = ""
    private var globalSearchMode = "Songs"
    private var openedCollectionName: String? = null
    private var openedCollectionTracks: List<Track> = emptyList()
    private var refreshResults: ((String) -> Unit) = {}
    private val navigationViews = mutableMapOf<String, TextView>()
    private var showingFullPlayerView = false
    private var playbackSpeed = 1.0f
    private var equalizer: android.media.audiofx.Equalizer? = null
    private val sleepTimerRunnable = Runnable { try { player?.pause() } catch (_: Exception) {}; updatePlaybackNotification(); updateFullPlayerControls(); Toast.makeText(this, "Sleep timer finished", Toast.LENGTH_SHORT).show() }
    private var miniTitleView: TextView? = null
    private var miniArtistView: TextView? = null
    private var miniPlayView: TextView? = null
    private var fullTitleView: TextView? = null
    private var fullArtistView: TextView? = null
    private var fullArtworkView: ImageView? = null
    private var fullPlayView: TextView? = null
    private var fullRepeatView: TextView? = null
    private var fullShuffleView: TextView? = null
    private val progressTicker = object : Runnable {
        override fun run() {
            val t = current
            val p = player
            if (t != null && p != null && playbackReady && tryIsPlaying()) {
                try {
                    val pos = p.currentPosition
                    if (lastProgressTrackId != t.id) { lastProgressTrackId = t.id; lastPositionMs = pos }
                    else if (lastPositionMs >= 0) {
                        val delta = pos - lastPositionMs
                        // Count real-time playback progress, not seeks or time spent paused.
                        // Count only forward playback segments. Seeking, pausing, and replaying an
                        // already-heard segment cannot inflate unique listened coverage.
                        if (delta in 1..1800) addListenedRange(lastPositionMs.toLong(), pos.toLong())
                        lastPositionMs = pos
                    }
                    val threshold = (t.durationMs * 0.80).toLong()
                    if (listenedMs >= threshold && lastRecordedTrackId != t.id) {
                        history.record(t)
                        lastRecordedTrackId = t.id
                        // Record silently; never rebuild the visible screen from the playback ticker.
                    }
                } catch (_: Exception) { lastPositionMs = -1 }
            } else lastPositionMs = -1
            if (playerScreenOpen) {
                try { val pos = player?.currentPosition?.toLong() ?: 0L; fullPlayerSeek?.progress = ((pos.toFloat() / (current?.durationMs ?: 1L).coerceAtLeast(1L)) * 1000).toInt(); fullPlayerElapsed?.text = formatTime(pos); fullPlayerTotal?.text = formatTime(current?.durationMs ?: 0L) } catch (_: Exception) {}
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        history = PlayHistory(this)
        applyPalette()
        playbackSpeed = getSharedPreferences("sivu_settings", MODE_PRIVATE).getFloat("playback_speed", 1.0f)
        createPlaybackNotificationChannel()
        mediaSession = MediaSession(this, "SivusIsaiaruvi").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { runOnUiThread {
                    if (player == null) current?.let { play(it) } ?: tracks.firstOrNull()?.let { play(it) }
                    else try { if (playbackReady && player?.isPlaying != true) player?.start() } catch (_: Exception) {}
                    updatePlaybackNotification(); updateFullPlayerControls()
                } }
                override fun onPause() { runOnUiThread {
                    try { if (playbackReady && player?.isPlaying == true) player?.pause() } catch (_: Exception) {}
                    updatePlaybackNotification(); updateFullPlayerControls()
                } }
                override fun onSkipToNext() { runOnUiThread { next(); updateFullPlayerControls(); updatePlaybackNotification() } }
                override fun onSkipToPrevious() { runOnUiThread { previous(); updateFullPlayerControls(); updatePlaybackNotification() } }
            })
            isActive = true
        }
        window.statusBarColor = 0xFFFFFFFF.toInt()
        window.navigationBarColor = 0xFFFFFFFF.toInt()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        if (hasAudioPermission()) { scan(); render() } else requestAudioPermission()
        handler.postDelayed(progressTicker, 1000L)
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun createPlaybackNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(notificationChannelId, "Music playback", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Now playing controls for Sivu’s Isaiaruvi"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notificationAction(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, MainActivity::class.java).apply {
            this.action = action
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(this, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun updatePlaybackNotification() {
        val t = current ?: return
        val session = mediaSession ?: return
        val playing = tryIsPlaying()
        val state = if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED
        session.setMetadata(MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, displayTitle(t.title))
            .putString(MediaMetadata.METADATA_KEY_ARTIST, displayArtist(t.artist))
            .putLong(MediaMetadata.METADATA_KEY_DURATION, t.durationMs)
            .build())
        session.setPlaybackState(PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO)
            .setState(state, try { player?.currentPosition?.toLong() ?: 0L } catch (_: Exception) { 0L }, if (playing) 1f else 0f)
            .build())
        val openIntent = notificationAction("OPEN_PLAYER", 10)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, notificationChannelId) else Notification.Builder(this)
        builder.setSmallIcon(R.drawable.ic_music_note)
            .setContentTitle(displayTitle(t.title))
            .setContentText(displayArtist(t.artist))
            .setContentIntent(openIntent)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .setShowWhen(false)
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_previous), "Previous", notificationAction("PREVIOUS", 11)).build())
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, if (playing) R.drawable.ic_pause else R.drawable.ic_play), if (playing) "Pause" else "Play", notificationAction("TOGGLE", 12)).build())
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_next), "Next", notificationAction("NEXT", 13)).build())
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_shuffle), if (shuffleEnabled) "Shuffle on" else "Shuffle", notificationAction("SHUFFLE", 14)).build())
        if (Build.VERSION.SDK_INT >= 21) builder.setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2))
        getSystemService(NotificationManager::class.java).notify(playbackNotificationId, builder.build())
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        when (intent.action) {
            "TOGGLE" -> togglePlayback()
            "NEXT" -> next()
            "PREVIOUS" -> previous()
            "SHUFFLE" -> toggleShuffle()
            "OPEN_PLAYER" -> playerScreenOpen = true
        }
        if (intent.action == "OPEN_PLAYER") { playerScreenOpen = true; render(true) }
        else if (intent.action != null) { updateFullPlayerControls(); updatePlaybackNotification() }
    }

    private fun playerControl(label: String, description: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        contentDescription = description
        textSize = if (label == "▶|") 16f else 20f
        gravity = Gravity.CENTER
        setTextColor(if (label == "▶") DEEP else -1)
        minimumWidth = dp(48)
        minimumHeight = dp(48)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(if (label == "▶") MINT else 0xFF1B684A.toInt())
            cornerRadius = dp(14).toFloat()
        }
        val lp = LinearLayout.LayoutParams(dp(48), dp(48))
        lp.setMargins(dp(3), 0, 0, 0)
        layoutParams = lp
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun tryIsPlaying(): Boolean = try { player?.isPlaying == true } catch (_: Exception) { false }

    private fun addListenedRange(start: Long, end: Long) {
        if (end <= start) return
        var mergedStart = start.coerceAtLeast(0L)
        var mergedEnd = end
        val merged = mutableListOf<Pair<Long, Long>>()
        var inserted = false
        for ((a, b) in listenedRanges.sortedBy { it.first }) {
            if (b < mergedStart) merged.add(a to b)
            else if (mergedEnd < a) {
                if (!inserted) { merged.add(mergedStart to mergedEnd); inserted = true }
                merged.add(a to b)
            } else {
                mergedStart = minOf(mergedStart, a)
                mergedEnd = maxOf(mergedEnd, b)
            }
        }
        if (!inserted) merged.add(mergedStart to mergedEnd)
        listenedRanges.clear()
        listenedRanges.addAll(merged)
        listenedMs = listenedRanges.sumOf { (a, b) -> (b - a).coerceAtLeast(0L) }
    }

    private fun togglePlayback() {
        val p = player
        if (p == null || current == null) {
            if (queue.isNotEmpty()) play(queue.getOrNull(queueIndex) ?: queue.first())
            else if (tracks.isNotEmpty()) play(tracks.first())
            else Toast.makeText(this, "No music found. Scan your library first.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            if (playbackReady && p.isPlaying) p.pause() else if (playbackReady) p.start()
            updateFullPlayerControls()
        } catch (_: IllegalStateException) {
            current?.let { play(it) }
        }
        updatePlaybackNotification()
        updateFullPlayerControls()
    }

    private fun hasAudioPermission(): Boolean = if (Build.VERSION.SDK_INT >= 33) checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    private fun requestAudioPermission() { requestPermissions(arrayOf(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE), REQ_AUDIO) }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == REQ_AUDIO) { if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) { scan(); render() } else showPermissionScreen() } }

    private fun scan() {
        if (scanInProgress) return
        scanInProgress = true
        if (::root.isInitialized) {
            Toast.makeText(this, "Scanning your music in the background…", Toast.LENGTH_SHORT).show()
        }
        libraryExecutor.execute {
            val found = mutableListOf<Track>()
            try {
                val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.IS_MUSIC, MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.YEAR, MediaStore.Audio.Media.ALBUM_ID)
                val excluded = getSharedPreferences("sivu_settings", MODE_PRIVATE).getString("excluded_folders", "").orEmpty().split(",", "\n").map { it.trim().lowercase(Locale.ROOT) }.filter { it.isNotBlank() }
                contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC}=1 AND ${MediaStore.Audio.Media.DURATION}>30000", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                    val idCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val titleCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artistCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST); val albumCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM); val durCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val pathCol=c.getColumnIndex(MediaStore.Audio.Media.DATA); val yearCol=c.getColumnIndex(MediaStore.Audio.Media.YEAR); val albumIdCol=c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                    while(c.moveToNext()) {
                        val id=c.getLong(idCol); val filePath=if(pathCol>=0) c.getString(pathCol).orEmpty() else ""
                        if(excluded.any { ex -> val norm = ex.trimEnd('/').lowercase(Locale.ROOT); norm.isNotBlank() && (filePath.lowercase(Locale.ROOT).startsWith(norm + "/") || filePath.lowercase(Locale.ROOT) == norm || filePath.lowercase(Locale.ROOT).contains("/" + norm + "/") || filePath.lowercase(Locale.ROOT).endsWith("/" + norm)) }) continue
                        val year=if(yearCol>=0 && !c.isNull(yearCol)) c.getInt(yearCol) else 0
                        found += Track(id, c.getString(titleCol) ?: "Unknown track", c.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "Unknown artist", c.getString(albumCol) ?: "", ContentUris.withAppendedId(collection,id), c.getLong(durCol), filePath, year, if(albumIdCol>=0 && !c.isNull(albumIdCol)) c.getLong(albumIdCol) else -1L)
                    }
                }
            } catch (_: Exception) { }
            runOnUiThread {
                tracks.clear(); tracks.addAll(found)
                scanInProgress = false
                if (::root.isInitialized && !playerScreenOpen) refreshMainContent()
                Toast.makeText(this, "Library ready · ${tracks.size} songs", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun isDarkPalette(): Boolean {
        val mode = getSharedPreferences("sivu_settings", MODE_PRIVATE).getInt("theme_mode", 0)
        return when (mode) { 1 -> false; 2 -> true; else -> (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES }
    }

    private fun applyPalette() {
        val prefs = getSharedPreferences("sivu_settings", MODE_PRIVATE)
        val dark = isDarkPalette()
        val accents = intArrayOf(0xFFE51B35.toInt(), 0xFF1769E0.toInt(), 0xFF7C4DFF.toInt(), 0xFF16865B.toInt(), 0xFFE67E22.toInt())
        GREEN = accents[prefs.getInt("accent_index", 0).coerceIn(0, accents.lastIndex)]
        DEEP = if (dark) 0xFFF4F4F4.toInt() else 0xFF202020.toInt()
        INK = if (dark) 0xFFF4F4F4.toInt() else 0xFF202020.toInt()
        MUTED = if (dark) 0xFFB7B7B7.toInt() else 0xFF777777.toInt()
        PALE = if (dark) 0xFF252525.toInt() else 0xFFF5F5F5.toInt()
        MINT = if (dark) 0xFF3A252A.toInt() else 0xFFFCE8EC.toInt()
        if (Build.VERSION.SDK_INT >= 23) {
            window.statusBarColor = if (dark) 0xFF151515.toInt() else 0xFFFFFFFF.toInt()
            window.navigationBarColor = if (dark) 0xFF151515.toInt() else 0xFFFFFFFF.toInt()
            window.decorView.systemUiVisibility = if (dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    private fun showSettings() {
        val prefs = getSharedPreferences("sivu_settings", MODE_PRIVATE)
        val box = LinearLayout(this).apply { orientation = 1; setPadding(dp(20), dp(8), dp(20), 0) }
        val excluded = EditText(this).apply {
            hint = "Excluded folder paths (browse below)"; setText(prefs.getString("excluded_folders", "") ?: "")
            minLines = 2; isSingleLine = false
        }
        box.addView(text("Exclude music folders", 16f, DEEP, true))
        box.addView(text("Browse and select exact music folders to exclude from your library.", 12f, MUTED))
        box.addView(excluded)
        box.addView(button("Browse music folders to exclude") {
            val folders = tracks.map { it.path.substringBeforeLast("/", "") }.filter { it.isNotBlank() }.distinct().sorted()
            if (folders.isEmpty()) { Toast.makeText(this, "Scan your library first", Toast.LENGTH_SHORT).show() }
            else {
                val selected = excluded.text.toString().split("\n", ",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
                val checked = BooleanArray(folders.size) { folder -> selected.any { it.equals(folders[folder], true) } }
                AlertDialog.Builder(this).setTitle("Choose folders to exclude")
                    .setMultiChoiceItems(folders.toTypedArray(), checked) { _, which, isChecked -> if (isChecked) selected.add(folders[which]) else selected.removeAll { it.equals(folders[which], true) } }
                    .setPositiveButton("Apply") { _, _ -> excluded.setText(selected.joinToString("\n")) }
                    .setNegativeButton("Cancel", null).show()
            }
        })
        val themeLabel = text("Appearance", 16f, DEEP, true).apply { setPadding(0, dp(14), 0, dp(4)) }
        box.addView(themeLabel)
        val themeOptions = arrayOf("Follow system", "Light", "Dark")
        val themeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, themeOptions)
            setSelection(prefs.getInt("theme_mode", 0).coerceIn(0, 2))
        }
        box.addView(themeSpinner)
        val accentLabel = text("Accent colour", 16f, DEEP, true).apply { setPadding(0, dp(14), 0, dp(4)) }
        box.addView(accentLabel)
        val accentOptions = arrayOf("Red", "Blue", "Purple", "Green", "Orange")
        val accentSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, accentOptions)
            setSelection(prefs.getInt("accent_index", 0).coerceIn(0, accentOptions.lastIndex))
        }
        box.addView(accentSpinner)
        val speedLabel = text("Playback speed", 16f, DEEP, true).apply { setPadding(0, dp(14), 0, dp(4)) }
        box.addView(speedLabel)
        val speedOptions = arrayOf("0.75×", "1.0× (Normal)", "1.25×", "1.5×", "1.75×", "2.0×")
        val speedValues = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        val speedSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, speedOptions)
            setSelection(speedValues.indices.minByOrNull { kotlin.math.abs(speedValues[it] - playbackSpeed) } ?: 1)
        }
        box.addView(speedSpinner)
        box.addView(button("Sleep timer") { showSleepTimer() })
        box.addView(button("Equalizer") { showEqualizer() })
        AlertDialog.Builder(this).setTitle("Isaiaruvi settings").setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("excluded_folders", excluded.text.toString()).putInt("theme_mode", themeSpinner.selectedItemPosition).putInt("accent_index", accentSpinner.selectedItemPosition).putFloat("playback_speed", speedValues[speedSpinner.selectedItemPosition]).apply()
                playbackSpeed = speedValues[speedSpinner.selectedItemPosition]
                applyPalette()
                try { player?.let { if (Build.VERSION.SDK_INT >= 23) it.playbackParams = it.playbackParams.setSpeed(playbackSpeed) } } catch (_: Exception) {}
                shellTab = null
                render(true)
                scan(); Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSleepTimer() {
        val options = arrayOf("5 minutes", "10 minutes", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes", "Cancel active timer")
        AlertDialog.Builder(this).setTitle("Sleep timer").setItems(options) { _, which ->
            handler.removeCallbacks(sleepTimerRunnable)
            if (which == options.lastIndex) Toast.makeText(this, "Sleep timer cancelled", Toast.LENGTH_SHORT).show()
            else { val mins = intArrayOf(5,10,15,30,45,60,90)[which]; handler.postDelayed(sleepTimerRunnable, mins * 60_000L); Toast.makeText(this, "Music will pause in $mins minutes", Toast.LENGTH_SHORT).show() }
        }.show()
    }

    private fun showEqualizer() {
        val p = player
        if (p == null || !playbackReady) { Toast.makeText(this, "Start a song before opening the equalizer", Toast.LENGTH_SHORT).show(); return }
        try {
            equalizer?.release()
            equalizer = android.media.audiofx.Equalizer(0, p.audioSessionId).apply { enabled = true }
            val eq = equalizer ?: return
            val presets = (0 until eq.numberOfPresets.toInt()).map { eq.getPresetName(it.toShort()) }
            if (presets.isEmpty()) { Toast.makeText(this, "No equalizer presets available on this device", Toast.LENGTH_SHORT).show(); return }
            AlertDialog.Builder(this).setTitle("Equalizer preset").setItems(presets.toTypedArray()) { _, which ->
                try { eq.usePreset(which.toShort()); Toast.makeText(this, presets[which], Toast.LENGTH_SHORT).show() } catch (_: Exception) { Toast.makeText(this, "Preset unavailable", Toast.LENGTH_SHORT).show() }
            }.setNegativeButton("Close", null).show()
        } catch (_: Exception) { Toast.makeText(this, "Equalizer is not supported by this audio output", Toast.LENGTH_SHORT).show() }
    }

    private fun showPermissionScreen() { root = LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(32,32,32,32); setBackgroundColor(-1) }; root.addView(text("Allow music access so Sivu's Isaiaruvi can find audio stored on your phone.",18f,INK)); root.addView(button("Grant music access") { requestAudioPermission() }); setContentView(root) }
    private fun text(s: String, size: Float=14f, color: Int=INK, bold: Boolean=false): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0,2,0,2) }
    // Clean source-site suffixes for display only; MediaStore metadata remains untouched.
    private fun displayTitle(value: String): String = value
        .replace(Regex("(?i)\\s*[-–—]\\s*MassTamilan(?:\\.com|\\.dev|\\.fm|\\.io)?\\s*$"), "")
        .replace(Regex("\\s{2,}"), " ").trim()
    private fun displayArtist(value: String): String = value
        .replace(Regex("(?i)\\s*[-–—]\\s*MassTamilan(?:\\.com|\\.dev|\\.fm|\\.io)?\\s*$"), "")
        .ifBlank { "Unknown artist" }.trim()
    private fun songCountLabel(count: Int): String = if (count == 1) "1 song" else "$count songs"
    private fun albumCollectionRow(name: String, items: List<Track>): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = 0; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = android.graphics.drawable.GradientDrawable().apply { setColor(if (isDarkPalette()) 0xFF202020.toInt() else -1); cornerRadius = dp(14).toFloat(); setStroke(dp(1), if (isDarkPalette()) 0xFF3A3A3A.toInt() else 0xFFDCE9DF.toInt()) }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(3), 0, dp(3)); layoutParams = lp
            isClickable = true; isFocusable = true
        }
        val cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = android.graphics.drawable.GradientDrawable().apply { setColor(MINT); cornerRadius = dp(8).toFloat() }
            val albumId = items.firstOrNull()?.albumId ?: -1L
            if (albumId > 0) try { setImageURI(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)) } catch (_: Exception) {}
        }
        row.addView(cover, LinearLayout.LayoutParams(dp(54), dp(54)))
        val labels = LinearLayout(this).apply { orientation = 1; setPadding(dp(12), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        labels.addView(text(displayTitle(name), 14f, DEEP, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        labels.addView(text(songCountLabel(items.size), 12f, MUTED))
        row.addView(labels)
        row.setOnClickListener { openCollection(name, items) }
        row.setOnLongClickListener { showGroup(name, items); true }
        return row
    }

    private fun collectionRow(label: String, action: () -> Unit, contextItems: List<Track>? = null, contextTitle: String = label.substringBefore("\n")): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        setTextColor(GREEN)
        gravity = Gravity.CENTER_VERTICAL or Gravity.START
        setPadding(dp(14), dp(12), dp(12), dp(12))
        maxLines = 2
        ellipsize = android.text.TextUtils.TruncateAt.END
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(if (isDarkPalette()) 0xFF202020.toInt() else -1); cornerRadius = dp(12).toFloat()
            setStroke(dp(1), if (isDarkPalette()) 0xFF3A3A3A.toInt() else 0xFFDCE9DF.toInt())
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, dp(3), 0, dp(3))
        layoutParams = lp
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
        if (contextItems != null) setOnLongClickListener { showGroup(contextTitle, contextItems); true }
    }

    private fun button(s: String, action: () -> Unit): Button = Button(this).apply {
        text=s
        textSize=13f
        isAllCaps=false
        minHeight=0
        minimumHeight=0
        minWidth=0
        minimumWidth=0
        setPadding(12,8,12,8)
        setTextColor(GREEN)
        background=android.graphics.drawable.GradientDrawable().apply {
            setColor(PALE)
            cornerRadius=14f
            setStroke(1,0xFFDCE9DF.toInt())
        }
        setOnClickListener { action() }
    }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation=1; setPadding(14,8,14,8); background = android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius=16f }; val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,4,0,4); layoutParams=p }
    private fun render(forceRebuild: Boolean = false) {
        if (playerScreenOpen) { showingFullPlayerView = true; renderFullPlayerScreen(); return }
        val returningFromPlayer = showingFullPlayerView
        showingFullPlayerView = false
        if (!forceRebuild && !returningFromPlayer && ::root.isInitialized && root.parent != null) {
            if (shellTab != tab) {
                shellTab = tab
                refreshMainContent()
                updateNavigationSelection()
            } else updateMiniPlayer()
            return
        }
        shellTab = tab
        navigationViews.clear()
        root=LinearLayout(this).apply { orientation=1; setBackgroundColor(if (isDarkPalette()) 0xFF121212.toInt() else 0xFFFFFFFF.toInt()); fitsSystemWindows = true; alpha = 1f }
        val header=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(18),dp(8),dp(18),dp(8)) }
        val brand=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        brand.addView(text("SIVU’S ISAIARUVI",19f,DEEP,true)); brand.addView(text("YOUR MUSIC. YOUR SPACE.",10f,MUTED,true))
        header.addView(brand)
        header.addView(button("⚙") { showSettings() })
        header.addView(button("⟳ Scan") { scan(); Toast.makeText(this, "Scanning music in background…", Toast.LENGTH_SHORT).show() })
        root.addView(header)
        val scroll=ScrollView(this).apply { isFillViewport=true; clipToPadding=false; overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS }; mainScrollView = scroll
        val content=LinearLayout(this).apply { orientation=1; setPadding(dp(18),dp(8),dp(18),dp(18)) }; mainContentView = content; scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        if (openedCollectionName != null) collectionDetail(content) else when(tab) { "Home" -> home(content); "Search" -> searchScreen(content); "Library" -> library(content); "Profile" -> profileScreen(content); "Insights" -> insights(content); else -> home(content) }
        val mini=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(12),dp(8),dp(10),dp(8)); background=android.graphics.drawable.GradientDrawable().apply { setColor(0xFF202020.toInt()); cornerRadius=dp(18).toFloat() }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(dp(12),dp(4),dp(12),dp(6)); layoutParams=lp }
        val trackName=if(current==null) "Choose a song to begin" else current!!.title
        val trackArtist=if(current==null) "Sivu’s Isaiaruvi" else current!!.artist
        val labels=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f); setPadding(0,0,dp(6),0) }
        miniTitleView = text(displayTitle(trackName),13f,-1,true).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END }
        miniArtistView = text(displayArtist(trackArtist),10f,0xFFBBD7C8.toInt()).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END }
        labels.addView(miniTitleView); labels.addView(miniArtistView)
        mini.addView(labels)
        labels.setOnClickListener { showFullPlayer() }
        mini.setOnClickListener { showFullPlayer() }
        miniPlayView = playerControl(if (playbackReady && tryIsPlaying()) "Ⅱ" else "▶", "Play or pause") { togglePlayback() }
        mini.addView(miniPlayView)
        mini.addView(playerControl("▶|", "Next track") { next() })
        root.addView(mini)
        val nav=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER; setPadding(dp(10),dp(3),dp(10),dp(10)); setBackgroundColor(if (isDarkPalette()) 0xFF121212.toInt() else 0xFFFFFFFF.toInt()); fitsSystemWindows = true }
        listOf("Home","Search","Library","Profile").forEach { t -> val selected=t==tab; val b=TextView(this).apply { text=(when(t){"Home"->"⌂";"Search"->"⌕";"Library"->"♫";else->"☻"})+"\n"+t; textSize=11f; gravity=Gravity.CENTER; setTypeface(null,if(selected) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL); setTextColor(if(selected) -1 else MUTED); setPadding(dp(6),dp(10),dp(6),dp(10)); minimumHeight=dp(48); background=android.graphics.drawable.GradientDrawable().apply { setColor(if(selected) GREEN else if (isDarkPalette()) 0xFF252525.toInt() else 0xFFF7F7F8.toInt()); cornerRadius=dp(16).toFloat() }; setOnClickListener { if (tab != t) { openedCollectionName = null; openedCollectionTracks = emptyList(); tab=t; render() } } }; navigationViews[t] = b; val lp=LinearLayout.LayoutParams(0,-2,1f); lp.setMargins(4,0,4,0); nav.addView(b,lp) }
        root.addView(nav); setContentView(root)
    }
    private fun refreshMainContent() {
        val content = mainContentView ?: run { render(true); return }
        val oldY = if (contentTabRendered == tab) (mainScrollView?.scrollY ?: 0) else 0
        content.removeAllViews()
        if (openedCollectionName != null) collectionDetail(content) else when (tab) { "Home" -> home(content); "Search" -> searchScreen(content); "Library" -> library(content); "Profile" -> profileScreen(content); "Insights" -> insights(content); else -> home(content) }
        contentTabRendered = tab
        updateNavigationSelection()
        // No whole-screen fade: it looked like a blink on every tap and made navigation feel slow.
        mainScrollView?.post { mainScrollView?.scrollTo(0, oldY.coerceAtMost((content.height - (mainScrollView?.height ?: 0)).coerceAtLeast(0))) }
    }

    private fun updateNavigationSelection() {
        navigationViews.forEach { (name, view) ->
            val selected = name == tab
            view.setTypeface(null, if (selected) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            view.setTextColor(if (selected) -1 else MUTED)
            view.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(if (selected) GREEN else if (isDarkPalette()) 0xFF252525.toInt() else 0xFFF7F7F8.toInt())
                cornerRadius = dp(16).toFloat()
            }
        }
    }

    private fun updateMiniPlayer() {
        val t = current
        miniTitleView?.text = displayTitle(t?.title ?: "Choose a song to begin")
        miniArtistView?.text = displayArtist(t?.artist ?: "Sivu’s Isaiaruvi")
        miniPlayView?.text = if (playbackReady && tryIsPlaying()) "Ⅱ" else "▶"
        miniPlayView?.contentDescription = if (playbackReady && tryIsPlaying()) "Pause" else "Play"
    }

    private fun searchScreen(c: LinearLayout) {
        c.addView(text("Search your music", 26f, DEEP, true))
        c.addView(text("Find songs, albums, artists and folders on your device.", 13f, MUTED))
        val search = EditText(this).apply {
            hint = "Song, movie/album, artist or folder"; setSingleLine(true); textSize = 16f
            setText(globalSearchQuery); setPadding(dp(16), dp(14), dp(16), dp(14))
            background = android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius = dp(18).toFloat() }
        }
        c.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14); bottomMargin = dp(12) })
        val modes = LinearLayout(this).apply { orientation = 0 }
        val results = LinearLayout(this).apply { orientation = 1 }
        fun refreshModes() {
            modes.removeAllViews()
            listOf("Songs", "Albums", "Artists", "Folders").forEach { mode ->
                val selected = globalSearchMode == mode
                val chip = button(mode) { globalSearchMode = mode; refreshResults(search.text.toString()); refreshModes() }
                chip.setTextColor(if (selected) -1 else GREEN)
                chip.background = android.graphics.drawable.GradientDrawable().apply { setColor(if (selected) GREEN else PALE); cornerRadius = dp(14).toFloat() }
                modes.addView(chip, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
            }
        }
        fun addResults(q: String) {
            results.removeAllViews()
            val matches = tracks.asSequence().filter { q.isBlank() || it.title.contains(q,true) || it.artist.contains(q,true) || it.album.contains(q,true) || it.path.contains(q,true) }
            when (globalSearchMode) {
                "Albums" -> {
                    val groups = matches.groupBy { it.album.ifBlank { "Unknown album" } }.toSortedMap().toList().take(100)
                    groups.forEach { (name, items) -> results.addView(albumCollectionRow(name, items)) }
                    if (groups.isEmpty()) results.addView(emptyStateView("No albums found", "Try a movie or album name."))
                }
                "Artists" -> {
                    val groups = matches.groupBy { it.artist.ifBlank { "Unknown artist" } }.toSortedMap().toList().take(100)
                    groups.forEach { (name, items) -> results.addView(collectionRow("♫  ${displayArtist(name)}\n${songCountLabel(items.size)}", { openCollection(name, items) }, items, name)) }
                    if (groups.isEmpty()) results.addView(emptyStateView("No artists found", "Try another search."))
                }
                "Folders" -> {
                    val groups = matches.groupBy { it.path.substringBeforeLast('/', "Unknown folder") }.toSortedMap().toList().take(100)
                    groups.forEach { (name, items) -> results.addView(collectionRow("▤  ${name.substringAfterLast('/')}\n${songCountLabel(items.size)}", { openCollection(name, items) }, items, name)) }
                    if (groups.isEmpty()) results.addView(emptyStateView("No folders found", "Try another search."))
                }
                else -> {
                    val songs = matches.take(if (q.isBlank()) 30 else 100).toList()
                    songs.forEach { trackRow(results, it) }
                    if (songs.isEmpty()) results.addView(emptyStateView("No songs found", "Try a song, artist, album or folder name."))
                }
            }
        }
        // Keep the local function reference stable for category-chip clicks.
            c.addView(modes); c.addView(text("RESULTS", 11f, MUTED, true).apply { setPadding(0, dp(14), 0, dp(6)) }); c.addView(results)
        // Kotlin local functions cannot be referenced before declaration; bridge refresh through this callback.
        refreshResults = { q -> addResults(q) }
        refreshModes()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { globalSearchQuery = s?.toString().orEmpty(); addResults(globalSearchQuery) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        addResults(globalSearchQuery)
    }

    private fun profileScreen(c: LinearLayout) {
        c.addView(text("Your space", 27f, DEEP, true))
        c.addView(text("Personalise Isaiaruvi and explore your listening.", 13f, MUTED))
        val summary = card()
        summary.addView(text("YOUR MUSIC", 11f, GREEN, true))
        summary.addView(text("${tracks.size} tracks on this device", 20f, DEEP, true))
        summary.addView(text("${history.total()} plays recorded", 13f, MUTED))
        c.addView(summary)
        fun profileAction(icon: String, title: String, subtitle: String, action: () -> Unit) {
            val row = card().apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL; isClickable = true; isFocusable = true; setOnClickListener { action() } }
            row.addView(text(icon, 22f, GREEN, true), LinearLayout.LayoutParams(dp(44), -2))
            val labels = LinearLayout(this).apply { orientation = 1; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            labels.addView(text(title, 15f, DEEP, true)); labels.addView(text(subtitle, 12f, MUTED))
            row.addView(labels); row.addView(text("›", 25f, MUTED)); c.addView(row)
        }
        profileAction("◷", "Listening insights", "Your top tracks and listening history") { tab = "Insights"; render() }
        profileAction("⚙", "Settings & appearance", "Theme, accent, folders and playback") { showSettings() }
        profileAction("▤", "Play queue", "View and manage what plays next") { showQueueDialog() }
        profileAction("♫", "Scan music library", "Refresh songs found on this device") { scan(); Toast.makeText(this, "Scanning music in the background…", Toast.LENGTH_SHORT).show() }
        profileAction("ⓘ", "About Isaiaruvi", "Local music, made personal") { AlertDialog.Builder(this).setTitle("Sivu’s Isaiaruvi").setMessage("A local music player for the music stored on your device.\n\nVersion 1.14.0").setPositiveButton("OK", null).show() }
    }

    private fun home(c: LinearLayout) {
        val welcome=LinearLayout(this).apply { orientation=1; setPadding(2,8,2,12) }
        welcome.addView(text("Your sound, your space.",22f,DEEP,true)); welcome.addView(text("A little more discovery. A lot less repetition.",12f,MUTED)); c.addView(welcome)
        val discovery = LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; layoutParams=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(14) } }
        val shuffleCard = LinearLayout(this).apply { orientation=1; setPadding(dp(12),dp(12),dp(12),dp(12)); background=android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,intArrayOf(DEEP,0xFF444444.toInt())).apply { cornerRadius=dp(18).toFloat() }; layoutParams=LinearLayout.LayoutParams(0,dp(124),1f).apply { marginEnd=dp(8) } }
        shuffleCard.addView(text("✦ SMART SHUFFLE",10f,MINT,true)); shuffleCard.addView(text("Rediscover your music",15f,-1,true)); shuffleCard.addView(button("Shuffle library ↗") { smartShuffle() }, LinearLayout.LayoutParams(-1, dp(40)))
        val radioCard = LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(dp(10),dp(12),dp(10),dp(12)); background=android.graphics.drawable.GradientDrawable().apply { setColor(MINT); cornerRadius=dp(18).toFloat() }; layoutParams=LinearLayout.LayoutParams(0,dp(124),1f) }
        radioCard.addView(text("♫",25f,GREEN,true).apply { gravity=Gravity.CENTER }); radioCard.addView(text("SONG RADIO",11f,GREEN,true).apply { gravity=Gravity.CENTER }); radioCard.addView(text("Choose a song",10f,MUTED).apply { gravity=Gravity.CENTER }); radioCard.setOnClickListener { showRadioPicker() }
        discovery.addView(shuffleCard); discovery.addView(radioCard); c.addView(discovery)
        val stats=LinearLayout(this).apply { orientation=0; setPadding(14,14,14,14); background=android.graphics.drawable.GradientDrawable().apply { setColor(if (isDarkPalette()) 0xFF202020.toInt() else -1); cornerRadius=20f }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,18); layoutParams=lp }
        fun stat(value:String,label:String): LinearLayout { val box=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }; box.addView(text(value,21f,GREEN,true)); box.addView(text(label,10f,MUTED)); return box }
        stats.addView(stat(tracks.size.toString(),"SONGS ON DEVICE")); val line=View(this).apply { setBackgroundColor(0xFFE3EBE5.toInt()) }; stats.addView(line,LinearLayout.LayoutParams(1,42)); stats.addView(stat(history.total().toString(),"PLAYS RECORDED")); c.addView(stats)
        sectionTitle(c,"Forgotten gems","Your least-played tracks")
        if(tracks.isEmpty()) c.addView(emptyStateView("No music found yet","Add audio files to your phone, then tap scan.")) else tracks.take(5).forEach { trackRow(c,it) }
        if(tracks.isEmpty()) c.addView(emptyStateView("Your library is waiting","Scan your device to see your songs here."))
    }
    private fun radioRow(parent: LinearLayout, t: Track) {
        val row = LinearLayout(this).apply {
            orientation = 0
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10),dp(8),dp(8),dp(8))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(if (isDarkPalette()) 0xFF242424.toInt() else -1)
                cornerRadius = 14f
            }
            val lp = LinearLayout.LayoutParams(-1,-2)
            lp.setMargins(0,3,0,3)
            layoutParams = lp
        }
        val glyph = TextView(this).apply {
            text = "♫"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(GREEN)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(MINT)
                cornerRadius = 12f
            }
        }
        row.addView(glyph, LinearLayout.LayoutParams(dp(40),dp(40)))
        val labels = LinearLayout(this).apply {
            orientation = 1
            setPadding(10,0,6,0)
            layoutParams = LinearLayout.LayoutParams(0,-2,1f)
        }
        val title = text(t.title,13f,DEEP,true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val artist = text(t.artist,10f,MUTED).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        labels.addView(title)
        labels.addView(artist)
        row.addView(labels)
        val action = TextView(this).apply {
            text = "Radio  ›"
            textSize = 11f
            setTextColor(GREEN)
            gravity = Gravity.CENTER
            setPadding(dp(10),dp(8),dp(10),dp(8))
            minimumWidth = dp(68)
            minimumHeight = dp(48)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(PALE)
                cornerRadius = 12f
            }
            setOnClickListener { startRadio(t) }
        }
        row.addView(action)
        parent.addView(row)
    }

    private fun sectionTitle(c:LinearLayout,title:String,subtitle:String) { val box=LinearLayout(this).apply { orientation=1; setPadding(2,7,2,7) }; box.addView(text(title,17f,DEEP,true)); box.addView(text(subtitle,11f,MUTED)); c.addView(box) }
    private fun emptyStateView(title:String,subtitle:String): LinearLayout = LinearLayout(this).apply { orientation=1; setPadding(14,14,14,14); background=android.graphics.drawable.GradientDrawable().apply { setColor(if (isDarkPalette()) 0xFF202020.toInt() else -1); cornerRadius=16f }; addView(text(title,14f,DEEP,true)); addView(text(subtitle,11f,MUTED)) }
    private fun library(c: LinearLayout) {
        albumDisplayMode=getSharedPreferences("sivu_ui",MODE_PRIVATE).getString("album_display","List")?:"List"
        c.addView(text("Your library",23f,DEEP,true)); c.addView(text("${tracks.size} tracks · stored on this device",12f,MUTED))
        val search=EditText(this).apply { hint="Search songs, artists or albums"; isSingleLine=true; setPadding(14,12,14,12); background=android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius=dp(16).toFloat() } }; c.addView(search)
        val modes=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
        listOf("Songs","Albums","Artists","Years","Folders","Playlists","Auto mixes").forEach { mode ->
            val b=button(mode) { if (libraryMode != mode) { libraryMode=mode; libraryVisibleLimit=100; refreshMainContent() } }
            b.setTextColor(if (libraryMode == mode) -1 else GREEN)
            b.background=android.graphics.drawable.GradientDrawable().apply { setColor(if (libraryMode == mode) GREEN else PALE); cornerRadius=dp(18).toFloat() }
            val lp=LinearLayout.LayoutParams(-2,-2); lp.setMargins(dp(3),dp(4),dp(3),dp(4)); modes.addView(b,lp)
        }
        c.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false; addView(modes) })
        val viewOptions=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(0,dp(4),0,dp(4)) }
        if (libraryMode == "Albums") {
            viewOptions.addView(text("Album display",12f,MUTED).apply { layoutParams=LinearLayout.LayoutParams(0,-2,1f) })
            val viewToggle=button(if(albumDisplayMode=="List") "☷ List" else "▦ Grid") { albumDisplayMode=if(albumDisplayMode=="List") "Grid" else "List"; getSharedPreferences("sivu_ui",MODE_PRIVATE).edit().putString("album_display",albumDisplayMode).apply(); refreshMainContent() }
            viewOptions.addView(viewToggle); c.addView(viewOptions)
        }
        val list=LinearLayout(this).apply { orientation=1 }; c.addView(list)
        fun fill(q:String) {
            list.removeAllViews()
            val matched=tracks.filter { it.title.contains(q,true)||it.artist.contains(q,true)||it.album.contains(q,true)||it.path.contains(q,true) }
            when(libraryMode) {
                "Albums" -> {
                    val albums=matched.groupBy { it.album.ifBlank { "Unknown album" } }.toSortedMap().toList()
                    if(albumDisplayMode=="Grid") {
                        val grid=android.widget.GridLayout(this@MainActivity).apply { columnCount=2; useDefaultMargins=false }
                        albums.take(libraryVisibleLimit).forEach { (name,items) ->
                            val tile=LinearLayout(this@MainActivity).apply { orientation=1; gravity=Gravity.CENTER_HORIZONTAL; setPadding(dp(8),dp(8),dp(8),dp(8)); background=android.graphics.drawable.GradientDrawable().apply { setColor(if (isDarkPalette()) 0xFF242424.toInt() else 0xFFF8F8F8.toInt()); cornerRadius=dp(12).toFloat() }; isClickable=true; isFocusable=true }
                            val cover=ImageView(this@MainActivity).apply { scaleType=ImageView.ScaleType.CENTER_CROP; setBackgroundColor(MINT); val id=items.firstOrNull()?.albumId?:-1L; if(id>0) try { setImageURI(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"),id)) } catch (_:Exception){} }
                            tile.addView(cover,LinearLayout.LayoutParams(-1,dp(130))); tile.addView(text(displayTitle(name),13f,DEEP,true).apply { maxLines=2; ellipsize=android.text.TextUtils.TruncateAt.END; gravity=Gravity.CENTER; setPadding(0,dp(5),0,0) }); tile.addView(text(songCountLabel(items.size),11f,MUTED).apply { gravity=Gravity.CENTER }); tile.setOnClickListener { openCollection(name,items) }; tile.setOnLongClickListener { showGroup(name,items); true }
                            val glp=android.widget.GridLayout.LayoutParams().apply { width=0; height=-2; columnSpec=android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED,1f); setMargins(dp(3),dp(3),dp(3),dp(3)) }; grid.addView(tile,glp)
                        }; list.addView(grid)
                    } else albums.take(libraryVisibleLimit).forEach { (name,items) -> list.addView(albumCollectionRow(name,items)) }
                    if(albums.size>libraryVisibleLimit) list.addView(button("Load more albums (${albums.size-libraryVisibleLimit} remaining)") { libraryVisibleLimit+=100; fill(q) })
                }
                "Artists" -> { val groups=matched.groupBy { it.artist }.toSortedMap().toList(); groups.take(libraryVisibleLimit).forEach { (name,items) -> list.addView(collectionRow("♫   ${displayArtist(name)}\n${songCountLabel(items.size)}", { openCollection(name,items) }, items, name)) }; if(groups.size>libraryVisibleLimit) list.addView(button("Load more artists (${groups.size-libraryVisibleLimit} remaining)") { libraryVisibleLimit+=100; fill(q) }) }
                "Years" -> matched.groupBy { if(it.year>0) it.year.toString() else "Year unknown" }.toSortedMap(compareByDescending { it }).forEach { (name,items) -> list.addView(collectionRow("◷   $name\n${songCountLabel(items.size)}", { openCollection(name,items) }, items, name)) }
                "Folders" -> matched.groupBy { it.path.substringBeforeLast('/', "Unknown folder") }.toSortedMap().forEach { (name,items) -> list.addView(collectionRow("▤   ${name.substringAfterLast('/')}\n${songCountLabel(items.size)}", { openCollection(name,items) }, items, name)) }
                "Playlists" -> { val prefs=getSharedPreferences("sivu_playlists", MODE_PRIVATE); val names=prefs.getStringSet("names", emptySet()).orEmpty().toList().sorted(); if(names.isEmpty()) list.addView(emptyStateView("No playlists yet","Use Add to playlist from a song or the full player.")); names.forEach { name -> val items=tracks.filter { prefs.getStringSet("playlist_$name",emptySet()).orEmpty().contains(it.id.toString()) }; list.addView(collectionRow("♫  $name\n${songCountLabel(items.size)}", { openCollection(name,items) }, items, name)) } }
                "Auto mixes" -> {
                    val stats=history.allStats()
                    list.addView(collectionRow("Recently added", action = { showGroup("Recently added",matched.sortedByDescending { it.id }.take(100)) }))
                    list.addView(collectionRow("Most played", action = { showGroup("Most played",matched.sortedByDescending { stats[it.id]?.first?:0 }.take(100)) }))
                    list.addView(collectionRow("Least played / forgotten gems", action = { showGroup("Forgotten gems",matched.sortedWith(compareBy<Track>{stats[it.id]?.first?:0}.thenBy{stats[it.id]?.second?:0L}).take(100)) }))
                    list.addView(collectionRow("Never played", action = { showGroup("Never played",matched.filter { (stats[it.id]?.first?:0)==0 }) }))
                }
                else -> matched.take(libraryVisibleLimit).forEach { trackRow(list,it) }
            }
            if(libraryMode=="Songs" && matched.size>libraryVisibleLimit) list.addView(button("Load more songs (${matched.size-libraryVisibleLimit} remaining)") { libraryVisibleLimit+=100; fill(q) })
        }
        fill(librarySearchQuery); search.setText(librarySearchQuery); search.setSelection(search.text.length); search.addTextChangedListener(object: android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){librarySearchQuery=s?.toString()?:"";libraryVisibleLimit=100;fill(librarySearchQuery)}; override fun afterTextChanged(s:android.text.Editable?){} })
        c.addView(button("Smart shuffle all songs") { smartShuffle() })
    }
    private fun showRadioPicker() {
        if(tracks.isEmpty()) { Toast.makeText(this,"Scan your music first",Toast.LENGTH_SHORT).show(); return }
        val box=LinearLayout(this).apply { orientation=1; setPadding(dp(16),dp(8),dp(16),0) }
        val search=EditText(this).apply { hint="Search song, movie/album, or artist"; isSingleLine=true }
        box.addView(search)
        val categories=LinearLayout(this).apply { orientation=0 }
        var category="Songs"
        var visibleLimit=100
        val categoryButtons=mutableMapOf<String,TextView>()
        val list=LinearLayout(this).apply { orientation=1 }
        val scroll=ScrollView(this).apply { isFillViewport=false; addView(list); layoutParams=LinearLayout.LayoutParams(-1,dp(420)) }
        fun refresh() {
            list.removeAllViews(); val q=search.text.toString().trim()
            val allResults=when(category) {
                "Albums" -> tracks.filter { it.album.contains(q,true) }.distinctBy { it.album.lowercase(Locale.ROOT) }.sortedBy { it.album.lowercase(Locale.ROOT) }
                "Artists" -> tracks.filter { it.artist.contains(q,true) }.distinctBy { it.artist.lowercase(Locale.ROOT) }.sortedBy { it.artist.lowercase(Locale.ROOT) }
                else -> tracks.filter { it.title.contains(q,true)||it.album.contains(q,true)||it.artist.contains(q,true) }.sortedBy { it.title.lowercase(Locale.ROOT) }
            }
            val results=allResults.take(visibleLimit)
            val albumCounts = if (category == "Albums") tracks.groupingBy { it.album }.eachCount() else emptyMap()
            results.forEach { t ->
                val label=when(category) { "Albums" -> "▣  ${t.album} · ${albumCounts[t.album] ?: 1} songs"; "Artists" -> "♫  ${t.artist}"; else -> "♫  ${displayTitle(t.title)}\n${displayArtist(t.artist)} · ${displayTitle(t.album)}" }
                list.addView(collectionRow(label, action = {
                    val seed=if(category=="Albums") tracks.firstOrNull { it.album==t.album }?:t else if(category=="Artists") tracks.firstOrNull { it.artist==t.artist }?:t else t
                    startRadio(seed); Toast.makeText(this,"Song radio started · ${displayTitle(seed.title)}",Toast.LENGTH_SHORT).show()
                    radioDialog?.dismiss()
                }))
            }
            if(allResults.isEmpty()) list.addView(text("No matches found",13f,MUTED))
            if(allResults.size>visibleLimit) list.addView(button("Load more (${allResults.size-visibleLimit} remaining)") { visibleLimit += 100; refresh() })
        }
        arrayOf("Songs","Albums","Artists").forEach { item -> val b=button(item) { category=item; visibleLimit=100; categoryButtons.forEach { (name,btn) -> btn.setTextColor(if(name==item) -1 else GREEN); btn.backgroundTintList=android.content.res.ColorStateList.valueOf(if(name==item) GREEN else PALE) }; refresh() }; categoryButtons[item]=b; categories.addView(b); b.setTextColor(if(item==category) -1 else GREEN); b.backgroundTintList=android.content.res.ColorStateList.valueOf(if(item==category) GREEN else PALE) }
        box.addView(categories); box.addView(scroll)
        search.addTextChangedListener(object:android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){visibleLimit=100;refresh()}; override fun afterTextChanged(s:android.text.Editable?){} })
        refresh()
        radioDialog=AlertDialog.Builder(this).setTitle("Create song radio").setView(box).setNegativeButton("Close",null).create().also { it.setOnDismissListener { radioDialog=null }; it.show() }
    }
    private var radioDialog: AlertDialog? = null

    private fun openCollection(name: String, items: List<Track>) {
        if (items.isEmpty()) { Toast.makeText(this, "No songs in this collection", Toast.LENGTH_SHORT).show(); return }
        openedCollectionName = name
        openedCollectionTracks = items.toList()
        refreshMainContent()
    }

    private fun collectionDetail(c: LinearLayout) {
        val name = openedCollectionName ?: return
        val items = openedCollectionTracks
        val top = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL }
        top.addView(button("‹ Back") {
            openedCollectionName = null; openedCollectionTracks = emptyList(); refreshMainContent()
        })
        top.addView(text(name, 21f, DEEP, true).apply { setPadding(dp(10), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        c.addView(top)
        c.addView(text("${items.size} songs", 12f, MUTED).apply { setPadding(dp(2), dp(5), 0, dp(8)) })
        val actions = LinearLayout(this).apply { orientation = 0 }
        actions.addView(button("▶ Play") { queue = items.toMutableList(); queueIndex = 0; play(items.first()) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        actions.addView(button("⇄ Shuffle") { queue = items.shuffled().toMutableList(); queueIndex = 0; shuffleEnabled = true; play(queue.first()) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        actions.addView(button("⋮ More") { showGroup(name, items) }, LinearLayout.LayoutParams(0, -2, 1f))
        c.addView(actions)
        val q = EditText(this).apply { hint = "Filter this collection"; setSingleLine(true); setPadding(dp(12), dp(9), dp(12), dp(9)); background = android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius = dp(12).toFloat() } }
        c.addView(q, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(6) })
        val list = LinearLayout(this).apply { orientation = 1 }; c.addView(list)
        fun fill(query: String) {
            list.removeAllViews()
            items.asSequence().filter { it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true) }.take(300).forEach { trackRow(list, it) }
        }
        q.addTextChangedListener(object : android.text.TextWatcher { override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}; override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { fill(s?.toString().orEmpty()) }; override fun afterTextChanged(s: android.text.Editable?) {} })
        fill("")
    }

    private fun showGroup(name:String, items:List<Track>) {
        if(items.isEmpty()) { Toast.makeText(this,"No songs in this collection",Toast.LENGTH_SHORT).show(); return }
        val options=arrayOf("Play collection","Shuffle collection","Add all to queue","Create playlist from collection")
        AlertDialog.Builder(this).setTitle(name).setItems(options) { _,which -> when(which) {
            0 -> { queue=items.toMutableList(); queueIndex=0; play(items.first()) }
            1 -> { queue=items.shuffled().toMutableList(); queueIndex=0; shuffleEnabled=true; play(queue.first()) }
            2 -> { queue=items.toMutableList(); queueIndex=0; Toast.makeText(this,"${items.size} songs added to queue",Toast.LENGTH_SHORT).show() }
            3 -> { val input=EditText(this).apply { hint="Playlist name"; setText(name) }; AlertDialog.Builder(this).setTitle("Create playlist").setView(input).setPositiveButton("Save") { _,_ -> val n=input.text.toString().trim(); if(n.isNotEmpty()) { val prefs=getSharedPreferences("sivu_playlists",MODE_PRIVATE); val names=prefs.getStringSet("names",emptySet())?.toMutableSet()?:mutableSetOf(); names.add(n); prefs.edit().putStringSet("names",names).apply(); prefs.edit().putStringSet("playlist_$n",items.map{it.id.toString()}.toSet()).apply(); Toast.makeText(this,"Created $n",Toast.LENGTH_SHORT).show() } }.setNegativeButton("Cancel",null).show() }
        } }.show()
    }
    private fun insights(c: LinearLayout) {
        c.addView(text("Listening insights",25f,DEEP,true)); c.addView(text("Your listening, made clear.",13f,MUTED))
        val row=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
        listOf("Day","Month","Year","All time").forEach { p -> val b=TextView(this).apply { text=p; textSize=12f; setTextColor(if(period==p) -1 else GREEN); setPadding(10,10,10,10); background=android.graphics.drawable.GradientDrawable().apply { setColor(if(period==p) GREEN else PALE); cornerRadius=18f }; setOnClickListener { period=p; refreshMainContent() } }; val lp=LinearLayout.LayoutParams(0,-2,1f); lp.setMargins(2,2,2,2); row.addView(b,lp) }; c.addView(row)
        val (from,to,label)=dateRange(); val total=history.total(from,to)
        val summary=card(); summary.addView(text(label.uppercase(Locale.getDefault()),12f,GREEN,true)); summary.addView(text("$total plays",28f,INK,true)); c.addView(summary)
        c.addView(text("Most played in this period",19f,DEEP,true)); val top=history.top(from,to); if(top.isEmpty()) c.addView(card().apply { addView(text("No plays recorded yet",15f,DEEP,true)); addView(text("Your most-played tracks will appear here as you listen.",12f,MUTED)) }) else top.forEachIndexed { i,p -> c.addView(card().apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; addView(text(String.format(Locale.getDefault(), "%02d", i+1),15f,GREEN,true), LinearLayout.LayoutParams(dp(34),-2)); val labels=LinearLayout(this@MainActivity).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }; labels.addView(text(displayTitle(p.first),14f,DEEP,true).apply { maxLines=2; ellipsize=android.text.TextUtils.TruncateAt.END }); labels.addView(text("${p.second} plays",11f,MUTED)); addView(labels) }) }
        c.addView(text("Custom date",19f,INK,true)); c.addView(text("Enter a date as YYYY-MM-DD",13f,MUTED)); val date=EditText(this).apply { hint="2026-10-22"; setSingleLine(); setText(customDay); setPadding(12,8,12,8) }; c.addView(date); c.addView(button("Show that day's plays") { customDay=date.text.toString().trim(); period="Custom"; refreshMainContent() })
        if(period=="Custom") { val (a,b,l)=dateRange(); c.addView(text("$l: ${history.total(a,b)} plays",16f,GREEN,true)) }
        c.addView(text("Per-song play counts",19f,DEEP,true)); val stats=history.allStats(); tracks.sortedByDescending { stats[it.id]?.first?:0 }.take(12).forEachIndexed { index, t ->
            val row = LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(12),dp(8),dp(12),dp(8)); background=android.graphics.drawable.GradientDrawable().apply { setColor(PALE); cornerRadius=dp(12).toFloat() }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(3),0,dp(3)); layoutParams=lp }
            row.addView(text("${index+1}",13f,GREEN,true),LinearLayout.LayoutParams(dp(28),-2))
            val labels=LinearLayout(this).apply { orientation=1; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
            labels.addView(text(displayTitle(t.title),13f,DEEP,true).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
            labels.addView(text(displayArtist(t.artist),10f,MUTED).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
            row.addView(labels); row.addView(text("${stats[t.id]?.first?:0}",13f,GREEN,true)); c.addView(row)
        }
    }
    private fun dateRange(): Triple<Long,Long,String> {
        val cal=Calendar.getInstance(); val now=System.currentTimeMillis()
        if(period=="Custom" && customDay.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) { try { val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply { isLenient=false }.parse(customDay)!!; val a=Calendar.getInstance().apply { time=d; set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis; return Triple(a,a+86_399_999,customDay) } catch (_:Exception){} }
        when(period) { "Day" -> { cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; "Month" -> { cal.set(Calendar.DAY_OF_MONTH,1); cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; "Year" -> { cal.set(Calendar.DAY_OF_YEAR,1); cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0) }; else -> return Triple(0L,now,"All time") }
        val label=when(period) { "Day" -> "Today"; "Month" -> SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(Date()); else -> cal.get(Calendar.YEAR).toString() }
        return Triple(cal.timeInMillis,now,label)
    }
    private fun trackRow(parent: LinearLayout,t:Track) {
        val r=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(8),dp(7),dp(8),dp(7)); background=android.graphics.drawable.GradientDrawable().apply { setColor(if (isDarkPalette()) 0xFF202020.toInt() else -1); cornerRadius=14f }; val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,3,0,3); layoutParams=lp }
        val art=TextView(this).apply { text="♫"; textSize=19f; gravity=Gravity.CENTER; setTextColor(GREEN); background=android.graphics.drawable.GradientDrawable().apply { setColor(MINT); cornerRadius=12f } }; r.addView(art,LinearLayout.LayoutParams(dp(44),dp(44)))
        val labels=LinearLayout(this).apply { orientation=1; setPadding(10,0,4,0); layoutParams=LinearLayout.LayoutParams(0,-2,1f) }; labels.addView(text(displayTitle(t.title),13f,DEEP,true).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
        labels.addView(text(displayArtist(t.artist),10f,MUTED).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END })
        r.addView(labels)
        val play=TextView(this).apply { text="▶"; textSize=18f; minimumWidth=dp(48); minimumHeight=dp(48); gravity=Gravity.CENTER; setTextColor(-1); background=android.graphics.drawable.GradientDrawable().apply { setColor(GREEN); cornerRadius=24f }; setOnClickListener { play(t) }; setOnLongClickListener { AlertDialog.Builder(this@MainActivity).setTitle(t.title).setItems(arrayOf("Play","Similar songs","Add to playlist","Start similar radio")) { _,which -> when(which){0->play(t);1->showSimilarSongs(t);2->showPlaylistDialog(t);3->startRadio(t)} }; true } }; r.addView(play,LinearLayout.LayoutParams(dp(48),dp(48))); parent.addView(r)
    }
    private fun play(t:Track) {
        try { player?.release() } catch (_:Exception) {}
        player=null
        playbackReady=false
        current=t
        val queuedIndex = queue.indexOfFirst { it.id == t.id }
        if (queuedIndex >= 0) queueIndex = queuedIndex
        try {
            player=MediaPlayer().apply {
                setDataSource(this@MainActivity,t.uri)
                setOnPreparedListener { mp ->
                    playbackReady=true
                    try { mp.start() } catch (_:Exception) {}
                    updatePlaybackNotification()
                    updateFullPlayerControls()
                    // Keep the current screen mounted during track start to avoid a visible jump.
                }
                setOnCompletionListener { if (repeatMode == 2) play(t) else if (repeatMode == 1 || queueIndex < queue.lastIndex) next() else { playbackReady = false; updatePlaybackNotification(); if (::root.isInitialized && !playerScreenOpen) updateMiniPlayer() } }
                setOnErrorListener { _, _, _ ->
                    playbackReady=false
                    Toast.makeText(this@MainActivity,"This track could not be played",Toast.LENGTH_SHORT).show()
                    true
                }
                prepareAsync()
            }
            listeningStartMs = System.currentTimeMillis()
            listenedMs = 0L
            listenedRanges.clear()
            lastPositionMs = -1
            lastProgressTrackId = t.id
            lastRecordedTrackId = -1L
            nowPlayingLabel?.text="${t.title}  ·  ${t.artist}"
            updateMiniPlayer()
            fullTitleView?.text = displayTitle(t.title)
            fullArtistView?.text = displayArtist(t.artist)
            fullArtworkView?.let { image ->
                image.animate().cancel()
                image.animate().alpha(0f).setDuration(90L).withEndAction {
                    image.setImageDrawable(null)
                    if (t.albumId > 0) image.setImageURI(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), t.albumId))
                    image.animate().alpha(1f).setDuration(180L).start()
                }.start()
            }
            updateFullPlayerControls()
        } catch(e:Exception) {
            playbackReady=false
            Toast.makeText(this,"Couldn't play this track",Toast.LENGTH_SHORT).show()
        }
        updatePlaybackNotification()
    }
    private fun smartShuffle() {
        if (tracks.isEmpty()) { Toast.makeText(this, "No music found. Add audio files and scan again.", Toast.LENGTH_LONG).show(); return }
        Toast.makeText(this, "Finding underplayed tracks…", Toast.LENGTH_SHORT).show()
        val snapshot = tracks.toList()
        libraryExecutor.execute {
            val now = System.currentTimeMillis()
            val stats = history.allStats()
            val sorted = snapshot.sortedBy { t ->
                val stat = stats[t.id]
                val plays = stat?.first ?: 0
                val last = stat?.second ?: 0L
                (plays * 100L) + (if (last == 0L) -50_000_000L else max(0L, 50_000_000L - (now - last) / 1000L))
            }.groupBy { stats[it.id]?.first ?: 0 }.toSortedMap().values.flatMap { it.shuffled() }.toMutableList()
            runOnUiThread {
                if (isFinishing || isDestroyed || sorted.isEmpty()) return@runOnUiThread
                queue = sorted
                queueIndex = 0
                play(queue[queueIndex])
                tab = "Home"
                render()
                Toast.makeText(this, "Smart shuffle started", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun moodTags(t:Track):Set<String> {
        val text=(t.title+" "+t.album+" "+t.artist).lowercase(Locale.ROOT)
        val tags=mutableSetOf<String>()
        val moods=mapOf(
            "sad" to listOf("sad","sogam","sogam","kanneer","azhu","pirivu","miss","pain","lonely","marana","iravin","nizhal","uyire","uyir","marandha"),
            "romantic" to listOf("love","kadhal","kaadhal","anbe","anbu","uyire","romance","nenje","nenju","malar","malare","paarvai"),
            "folk" to listOf("folk","kuthu","dappan","parai","ooru","gramam","village","thara","local","gana","gaana","muthu","maari"),
            "dance" to listOf("dance","party","beat"," kuthu","mass","gethu","vaathi","vaathi","celebration"),
            "devotional" to listOf("devotional","amman","murugan","sivan","krishna","jesus","allah","bhakthi","om","deivam"),
            "melody" to listOf("melody","mellisa","nilave","nilavu","vennilave","thendral","poove","poo","raagam")
        )
        moods.forEach { (m,words)-> if(words.any { text.contains(it) }) tags.add(m) }
        if(t.artist.equals("Unknown artist",true)) tags.add("unknown")
        return tags
    }
    private fun similarityScore(seed:Track, candidate:Track, cachedPlays: Int = history.count(candidate.id), cachedLastPlayed: Long = history.lastPlayed(candidate.id)):Int {
        var score=0
        if(candidate.artist.equals(seed.artist,true)) score+=24
        // Same album/movie is deliberately excluded by default.
        if(seed.year>0 && candidate.year>0) score += (12 - kotlin.math.abs(seed.year-candidate.year).coerceAtMost(12))
        val a=moodTags(seed); val b=moodTags(candidate)
        score += a.intersect(b).size*18
        val wordsA=(seed.title+" "+seed.album).lowercase(Locale.ROOT).split(Regex("[^a-z0-9]+" )).filter{it.length>3}.toSet()
        val wordsB=(candidate.title+" "+candidate.album).lowercase(Locale.ROOT).split(Regex("[^a-z0-9]+" )).filter{it.length>3}.toSet()
        score += wordsA.intersect(wordsB).size*5
        if(a.isNotEmpty() && b.isNotEmpty() && a.intersect(b).isEmpty()) score-=15
        score -= cachedPlays*2
        if(cachedLastPlayed>0) score-=((System.currentTimeMillis()-cachedLastPlayed)/86_400_000L).let { if(it<2) 10 else 0 }.toInt()
        return score
    }
    private fun similarTracks(seed:Track):List<Track> {
        // Cross-movie discovery by default. A fresh randomized, weighted ranking is generated
        // for every request so the same seed does not always return the same fixed top-N set.
        // Keep scoring off the main thread (callers use libraryExecutor).
        val candidates = tracks.filter { candidate ->
            candidate.id != seed.id &&
                !(seed.albumId > 0 && candidate.albumId == seed.albumId) &&
                !(seed.album.isNotBlank() && candidate.album.equals(seed.album, true))
        }
        if (candidates.isEmpty()) return emptyList()
        // Read history in one grouped query instead of querying SQLite once per candidate.
        val stats = history.allStats()
        val ranked = candidates.map { track ->
            val stat = stats[track.id]
            track to similarityScore(seed, track, stat?.first ?: 0, stat?.second ?: 0L)
        }.sortedByDescending { it.second }
        val best = ranked.first().second
        // Keep a broad quality window, then randomize within score bands instead of always
        // selecting the exact same 40 tracks. Random weight still favors closer matches.
        val pool = ranked.filter { it.second >= best - 38 }.toMutableList()
        if (pool.size < 40) {
            ranked.take((40 + pool.size).coerceAtMost(ranked.size)).forEach { pair ->
                if (pool.none { it.first.id == pair.first.id }) pool.add(pair)
            }
        }
        val prefs = getSharedPreferences("similar_song_discovery", MODE_PRIVATE)
        val memoryKey = "seed_${seed.id}"
        val recentlySuggested = prefs.getString(memoryKey, "").orEmpty()
            .split(',').mapNotNull { it.toLongOrNull() }.toSet()
        // Prefer songs not shown for this seed recently. If the library is small, gracefully
        // fall back to the full quality pool rather than returning too few songs.
        val freshPool = pool.filter { it.first.id !in recentlySuggested }
        val selectedPool = if (freshPool.size >= minOf(12, pool.size)) freshPool else pool
        val random = kotlin.random.Random(System.nanoTime() xor System.currentTimeMillis())
        val remaining = selectedPool.toMutableList()
        val result = mutableListOf<Track>()
        val artistCounts = mutableMapOf<String, Int>()
        val albumCounts = mutableMapOf<String, Int>()
        while (remaining.isNotEmpty() && result.size < 40) {
            val weighted = remaining.map { pair ->
                val artist = pair.first.artist.lowercase(Locale.ROOT)
                val album = pair.first.album.lowercase(Locale.ROOT)
                val quality = (pair.second - (best - 45)).coerceAtLeast(1)
                val diversityPenalty = 1.0 / (1 + (artistCounts[artist] ?: 0) * 1.8 + (albumCounts[album] ?: 0) * 1.4)
                pair to (quality.toDouble() * diversityPenalty * (0.65 + random.nextDouble() * 0.7))
            }
            val total = weighted.sumOf { it.second }
            var pick = random.nextDouble() * total
            var selected = weighted.last().first
            for ((pair, weight) in weighted) {
                pick -= weight
                if (pick <= 0.0) { selected = pair; break }
            }
            result.add(selected.first)
            remaining.removeAll { it.first.id == selected.first.id }
            val artist = selected.first.artist.lowercase(Locale.ROOT)
            val album = selected.first.album.lowercase(Locale.ROOT)
            artistCounts[artist] = (artistCounts[artist] ?: 0) + 1
            albumCounts[album] = (albumCounts[album] ?: 0) + 1
        }
        // Remember this batch per seed, so the next request deliberately explores another set.
        val previous = recentlySuggested.toMutableSet()
        previous.addAll(result.map { it.id })
        // Keep a bounded memory so the preference remains small and older recommendations can return.
        val keep = previous.toList().takeLast(120)
        prefs.edit().putString(memoryKey, keep.joinToString(",")).apply()
        return result
    }
    private fun showSimilarSongs(seed:Track) {
        val loading = AlertDialog.Builder(this).setTitle("Finding similar songs…")
            .setMessage("Checking your library without blocking playback.")
            .setNegativeButton("Cancel", null).create()
        loading.setCanceledOnTouchOutside(true)
        loading.show()
        libraryExecutor.execute {
            val matches = similarTracks(seed)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                loading.dismiss()
                showSimilarSongsResults(seed, matches)
            }
        }
    }
    private fun showSimilarSongsResults(seed: Track, matches: List<Track>) {
        if (matches.isEmpty()) {
            Toast.makeText(this, "No other songs found", Toast.LENGTH_SHORT).show()
            return
        }
        val panel = LinearLayout(this).apply {
            orientation = 1
            setPadding(dp(16), dp(4), dp(16), dp(8))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        panel.addView(text("Audio-style discovery · same album/movie excluded", 12f, MUTED))
        val scroller = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
        }
        val list = LinearLayout(this).apply { orientation = 1 }
        lateinit var dialog: AlertDialog
        matches.take(25).forEachIndexed { index, track ->
            val row = LinearLayout(this).apply {
                orientation = 0
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(8), dp(8))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(-1); cornerRadius = dp(12).toFloat()
                    setStroke(dp(1), 0xFFDCE9DF.toInt())
                }
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, dp(3), 0, dp(3))
                layoutParams = lp
            }
            val labels = LinearLayout(this).apply {
                orientation = 1
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            labels.addView(text(displayTitle(track.title), 14f, DEEP, true).apply {
                maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            labels.addView(text(displayArtist(track.artist), 12f, MUTED).apply {
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            val sharedTags = moodTags(track).intersect(moodTags(seed))
            val reason = when {
                track.artist.equals(seed.artist, true) -> "Same artist"
                sharedTags.isNotEmpty() -> "Shared tags: ${sharedTags.joinToString(", ")}"
                else -> "Metadata match"
            }
            labels.addView(text(reason, 10f, MUTED).apply { maxLines = 1 })
            row.addView(labels)
            val more = TextView(this).apply {
                text = "⋮"; textSize = 24f; gravity = Gravity.CENTER
                setTextColor(GREEN); minimumWidth = dp(40); minimumHeight = dp(44)
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(displayTitle(track.title))
                        .setItems(arrayOf("Play now", "Add to queue", "Add to playlist", "Start similar radio")) { _, action ->
                            when (action) {
                                0 -> { dialog.dismiss(); play(track) }
                                1 -> {
                                    val insertAt = (queueIndex + 1).coerceIn(0, queue.size)
                                    queue.add(insertAt, track)
                                    Toast.makeText(this@MainActivity, "Added to queue", Toast.LENGTH_SHORT).show()
                                }
                                2 -> showPlaylistDialog(track)
                                3 -> startRadio(track)
                            }
                        }.show()
                }
            }
            row.addView(more)
            row.setOnClickListener { dialog.dismiss(); play(track) }
            list.addView(row)
        }
        scroller.addView(list)
        panel.addView(scroller, LinearLayout.LayoutParams(-1, dp(460)))
        dialog = AlertDialog.Builder(this)
            .setTitle("Similar songs")
            .setMessage("For: ${displayTitle(seed.title)}")
            .setView(panel)
            .setPositiveButton("Add top matches to playlist") { _, _ ->
                val input = EditText(this).apply {
                    hint = "Playlist name"
                    setText("Similar to ${displayTitle(seed.title)}")
                }
                AlertDialog.Builder(this).setTitle("Create similar-song playlist").setView(input)
                    .setPositiveButton("Create") { _, _ ->
                        val name = input.text.toString().trim()
                        if (name.isNotEmpty()) {
                            val prefs = getSharedPreferences("sivu_playlists", MODE_PRIVATE)
                            val names = prefs.getStringSet("names", emptySet())?.toMutableSet() ?: mutableSetOf()
                            names.add(name)
                            prefs.edit().putStringSet("names", names)
                                .putStringSet("playlist_$name", (listOf(seed) + matches.take(25)).map { it.id.toString() }.toSet())
                                .apply()
                            Toast.makeText(this, "Created $name", Toast.LENGTH_SHORT).show()
                        }
                    }.setNegativeButton("Cancel", null).show()
            }
            .setNegativeButton("Close", null)
            .create()
        dialog.setOnShowListener {
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), (resources.displayMetrics.heightPixels * 0.78f).toInt())
        }
        dialog.setCanceledOnTouchOutside(true)
        dialog.setCancelable(true)
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.white)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), (resources.displayMetrics.heightPixels * 0.78f).toInt())
    }
    private fun startRadio(seed:Track) {
        Toast.makeText(this, "Building Song Radio…", Toast.LENGTH_SHORT).show()
        libraryExecutor.execute {
            val recommendations = similarTracks(seed)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                queue = recommendations.toMutableList()
                queue.add(0, seed)
                queueIndex = 0
                play(seed)
                Toast.makeText(this, "Song Radio ready · ${recommendations.size} recommendations", Toast.LENGTH_LONG).show()
                if (::root.isInitialized) render()
            }
        }
    }
    private fun showFullPlayer() {
        if (current == null && tracks.isEmpty()) {
            Toast.makeText(this, "Your library is empty", Toast.LENGTH_SHORT).show()
            return
        }
        playerScreenOpen = true
        render(true)
    }

    private fun renderFullPlayerScreen() {
        val t = current ?: tracks.firstOrNull() ?: return
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(8), dp(20), dp(14))
            setBackgroundColor(if (isDarkPalette()) 0xFF121212.toInt() else 0xFFFFFFFF.toInt())
            fitsSystemWindows = true
        }
        val top = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL }
        val back = TextView(this).apply {
            text = "‹"; textSize = 36f; gravity = Gravity.CENTER
            setTextColor(GREEN); minimumWidth = dp(52); minimumHeight = dp(48)
            contentDescription = "Back to library"
            setOnClickListener { playerScreenOpen = false; render() }
        }
        top.addView(back)
        val heading = text("NOW PLAYING", 13f, GREEN, true).apply { gravity = Gravity.CENTER }
        top.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val more = TextView(this).apply {
            text = "⋮"; textSize = 26f; gravity = Gravity.CENTER
            setTextColor(GREEN); minimumWidth = dp(44); minimumHeight = dp(48)
            setOnClickListener { showQueueDialog() }
        }
        top.addView(more); root.addView(top)

        val artFrame = FrameLayout(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply { setColor(MINT); cornerRadius = dp(26).toFloat() }
        }
        val fallback = TextView(this).apply {
            text = "♫"; textSize = 76f; gravity = Gravity.CENTER; setTextColor(GREEN)
        }
        artFrame.addView(fallback, FrameLayout.LayoutParams(-1, -1))
        val art = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        fullArtworkView = art
        if (t.albumId > 0) {
            try { art.setImageURI(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), t.albumId)) } catch (_: Exception) {}
        }
        artFrame.addView(art, FrameLayout.LayoutParams(-1, -1))
        artFrame.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { swipeStartX = event.x; swipeStartY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - swipeStartX; val dy = event.y - swipeStartY
                    val now = android.os.SystemClock.elapsedRealtime()
                    if (kotlin.math.abs(dx) > dp(70) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f && now - lastArtworkSwipeAt > 280L) {
                        lastArtworkSwipeAt = now
                        if (dx < 0) next() else previous()
                        true
                    } else false
                }
                else -> true
            }
        }
        val artLp = LinearLayout.LayoutParams(-1, 0, 4f); artLp.setMargins(0, dp(18), 0, dp(18)); root.addView(artFrame, artLp)

        fullTitleView = text(displayTitle(t.title), 22f, DEEP, true).apply { gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        fullArtistView = text(displayArtist(t.artist), 15f, MUTED).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        root.addView(fullTitleView); root.addView(fullArtistView)
        

        val seek = SeekBar(this).apply { max = 1000; progress = 0; contentDescription = "Seek through track" }
        fullPlayerSeek = seek
        val seekLp = LinearLayout.LayoutParams(-1, dp(44)); seekLp.topMargin = dp(12); root.addView(seek, seekLp)
        val times = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER_VERTICAL }
        val elapsed = text("0:00", 12f, MUTED); val total = text(formatTime(t.durationMs), 12f, MUTED)
        fullPlayerElapsed = elapsed; fullPlayerTotal = total
        times.addView(elapsed, LinearLayout.LayoutParams(0, -2, 1f)); times.addView(total); root.addView(times)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) try { player?.seekTo((progress / 1000f * (current?.durationMs ?: t.durationMs)).toInt()); lastPositionMs = -1 } catch (_: Exception) {}
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val controls = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(12)) }
        fun control(label: String, selected: Boolean = false, large: Boolean = false, action: () -> Unit) {
            val b = TextView(this).apply {
                text = label; textSize = if (large) 28f else 20f; gravity = Gravity.CENTER
                setTextColor(if (selected) -1 else GREEN)
                background = android.graphics.drawable.GradientDrawable().apply { setColor(if (selected) GREEN else MINT); cornerRadius = dp(32).toFloat() }
                width = dp(58); height = dp(58)
                contentDescription = when(label) { "Ⅱ" -> "Pause"; "▶" -> "Play"; "|◀" -> "Previous track"; "▶|" -> "Next track"; "⤨" -> "Shuffle"; else -> "Repeat" }
                setOnClickListener { action() }
            }
            when (label) { "Ⅱ", "▶" -> fullPlayView = b; "↻ ALL", "↻ ONE", "↻" -> fullRepeatView = b; "⤨" -> fullShuffleView = b }
            val lp = LinearLayout.LayoutParams(-2, -2); lp.setMargins(dp(4), 0, dp(4), 0); controls.addView(b, lp)
        }
        control("⤨", shuffleEnabled) {
            AlertDialog.Builder(this).setTitle("Shuffle mode").setItems(arrayOf("Shuffle current queue", "Smart shuffle · underplayed first", "Turn shuffle off")) { _, choice ->
                when (choice) {
                    0 -> { if (!shuffleEnabled) toggleShuffle(); updateFullPlayerControls() }
                    1 -> { shuffleEnabled = true; smartShuffle(); updateFullPlayerControls() }
                    2 -> { shuffleEnabled = false; Toast.makeText(this, "Shuffle off", Toast.LENGTH_SHORT).show(); updatePlaybackNotification(); updateFullPlayerControls() }
                }
            }.show()
        }
        control("|◀") { previous(); updateFullPlayerControls() }
        control(if (tryIsPlaying()) "Ⅱ" else "▶", large = true) { togglePlayback(); updateFullPlayerControls() }
        control("▶|") { next(); updateFullPlayerControls() }
        control(when(repeatMode){1->"↻ ALL";2->"↻ ONE";else->"↻"}, repeatMode != 0) {
            repeatMode = (repeatMode + 1) % 3
            Toast.makeText(this, when(repeatMode){1->"Repeat all";2->"Repeat one";else->"Repeat off"}, Toast.LENGTH_SHORT).show()
            updateFullPlayerControls()
        }
        root.addView(controls)

        val actionRows = LinearLayout(this).apply { orientation = 1; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(4)) }
        val rowOne = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER }
        val rowTwo = LinearLayout(this).apply { orientation = 0; gravity = Gravity.CENTER }
        fun actionButton(parent: LinearLayout, label: String, action: () -> Unit) {
            val b = button(label, action)
            val lp = LinearLayout.LayoutParams(0, dp(48), 1f); lp.setMargins(dp(3), dp(3), dp(3), dp(3)); parent.addView(b, lp)
        }
        actionButton(rowOne, "＋ Playlist") { showPlaylistDialog(t) }
        actionButton(rowOne, "♫ Similar") { showSimilarSongs(t) }
        actionButton(rowTwo, "☷ Queue") { showQueueDialog() }
        actionButton(rowTwo, "⌂ Library") { playerScreenOpen = false; tab = "Library"; render(true) }
        actionRows.addView(rowOne); actionRows.addView(rowTwo); root.addView(actionRows)
        setContentView(root)
    }

    private fun updateFullPlayerControls() {
        fullPlayView?.text = if (tryIsPlaying()) "Ⅱ" else "▶"
        fullRepeatView?.apply {
            text = when (repeatMode) { 1 -> "↻ ALL"; 2 -> "↻ ONE"; else -> "↻" }
            setTextColor(if (repeatMode != 0) -1 else GREEN)
            background = android.graphics.drawable.GradientDrawable().apply { setColor(if (repeatMode != 0) GREEN else MINT); cornerRadius = dp(32).toFloat() }
        }
        fullShuffleView?.apply {
            setTextColor(if (shuffleEnabled) -1 else GREEN)
            background = android.graphics.drawable.GradientDrawable().apply { setColor(if (shuffleEnabled) GREEN else MINT); cornerRadius = dp(32).toFloat() }
        }
        updateMiniPlayer()
    }

    private fun formatTime(ms: Long): String {
        val sec = (ms / 1000).toInt()
        return String.format(Locale.getDefault(), "%d:%02d", sec / 60, sec % 60)
    }

    private fun showPlaylistDialog(track: Track) {
        val prefs = getSharedPreferences("sivu_playlists", MODE_PRIVATE)
        val existing = prefs.getStringSet("names", emptySet())?.toMutableSet() ?: mutableSetOf()
        val options = (existing.toList() + "＋ Create new playlist").toTypedArray()
        AlertDialog.Builder(this).setTitle("Add to playlist").setItems(options) { _, which ->
            if (which == options.lastIndex) {
                val input = EditText(this).apply { hint = "Playlist name" }
                AlertDialog.Builder(this).setTitle("Create playlist").setView(input)
                    .setPositiveButton("Create and add") { _, _ ->
                        val name = input.text.toString().trim()
                        if (name.isNotEmpty()) {
                            existing.add(name); prefs.edit().putStringSet("names", existing).apply()
                            addTrackToPlaylist(prefs, name, track)
                        }
                    }.setNegativeButton("Cancel", null).show()
            } else addTrackToPlaylist(prefs, options[which], track)
        }.setNegativeButton("Cancel", null).show()
    }

    private fun addTrackToPlaylist(prefs: android.content.SharedPreferences, name: String, track: Track) {
        val key = "playlist_" + name
        val ids = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.add(track.id.toString())
        prefs.edit().putStringSet(key, ids).apply()
        Toast.makeText(this, "Added to $name", Toast.LENGTH_SHORT).show()
    }

    private fun toggleShuffle() {
        shuffleEnabled = !shuffleEnabled
        if (shuffleEnabled) {
            val nowId = current?.id
            val rest = (if (queue.isNotEmpty()) queue else tracks.toMutableList()).filter { it.id != nowId }.shuffled()
            queue = mutableListOf<Track>().apply { if (current != null) add(current!!); addAll(rest) }
            queueIndex = if (current != null) 0 else 0
        } else if (queue.isEmpty()) queue = tracks.toMutableList()
        Toast.makeText(this, if (shuffleEnabled) "Shuffle on" else "Shuffle off", Toast.LENGTH_SHORT).show()
        updatePlaybackNotification()
    }

    private fun previous() {
        val p = player
        if (p != null && playbackReady) {
            try { if (p.currentPosition > 3000) { p.seekTo(0); return } } catch (_: Exception) {}
        }
        if (queue.isEmpty()) queue = tracks.toMutableList()
        if (queue.isEmpty()) return
        queueIndex = if (queueIndex <= 0) queue.lastIndex else queueIndex - 1
        play(queue[queueIndex])
    }

    private fun showQueueDialog() {
        if (queue.isEmpty()) current?.let { queue.add(it); queueIndex = 0 }
        if (queue.isEmpty()) { Toast.makeText(this, "Queue is empty", Toast.LENGTH_SHORT).show(); return }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), 0) }
        val scroll = ScrollView(this)
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(rows)
        body.addView(scroll, LinearLayout.LayoutParams(-1, dp(440)))
        var limit = 100
        lateinit var dialog: AlertDialog
        fun fill() {
            rows.removeAllViews()
            queue.take(limit).forEachIndexed { i, t ->
                val row = collectionRow((if (i == queueIndex) "▶  " else "") + displayTitle(t.title) + "\n" + displayArtist(t.artist), {
                    queueIndex = i; dialog.dismiss(); play(queue[i])
                })
                rows.addView(row)
            }
            if (queue.size > limit) rows.addView(button("Load more (${queue.size-limit} remaining)") { limit += 100; fill() })
        }
        fill()
        dialog = AlertDialog.Builder(this).setTitle("Up next · ${queue.size} tracks").setView(body)
            .setNeutralButton("Clear queue") { _, _ -> queue.clear(); queueIndex = 0; Toast.makeText(this, "Queue cleared", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Close", null).create()
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), (resources.displayMetrics.heightPixels * 0.78f).toInt())
    }

    private fun next() {
        if (queue.isEmpty()) {
            if (tracks.isEmpty()) return
            queue = tracks.toMutableList()
            queueIndex = tracks.indexOfFirst { it.id == current?.id }.coerceAtLeast(0)
        }
        if (shuffleEnabled && queue.size > 1) {
            val currentId = current?.id
            val choices = queue.indices.filter { queue[it].id != currentId }
            queueIndex = choices.randomOrNull() ?: ((queueIndex + 1) % queue.size)
        } else if (queueIndex < queue.lastIndex) queueIndex++
        else if (repeatMode == 1) queueIndex = 0
        else return
        play(queue[queueIndex])
    }
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (openedCollectionName != null) { openedCollectionName = null; openedCollectionTracks = emptyList(); refreshMainContent(); return }
        if (playerScreenOpen) {
            playerScreenOpen = false
            render()
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() { handler.removeCallbacks(progressTicker); handler.removeCallbacks(sleepTimerRunnable); try { equalizer?.release() } catch (_: Exception) {}; equalizer=null; try { player?.release() } catch (_:Exception) {}; player=null; try { mediaSession?.isActive = false; mediaSession?.release() } catch (_: Exception) {}; mediaSession=null; super.onDestroy() }
}

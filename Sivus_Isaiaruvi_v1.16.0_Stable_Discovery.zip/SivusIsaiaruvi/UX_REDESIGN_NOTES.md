# v1.16.0 stability and discovery notes

## Collection and navigation behavior
- Tap album, artist, year, folder or playlist to open its tracks.
- Long-press a collection for Play collection, Shuffle collection, Add all to queue, and Create playlist from collection.
- Search stays in Search while opening search results.
- Android Back closes collection detail before leaving the current section.

## Similar Songs
- Excludes the seed track and same album/movie by default.
- Uses local metadata for relevance ranking.
- Randomized weighted sampling favors stronger matches but varies results between requests.
- Penalizes repeated artists/albums within a batch.
- Stores a bounded per-seed history of recently suggested track IDs to prefer fresh tracks next time.
- Reads play-count and last-played stats using one grouped history query rather than a pair of SQLite queries for every candidate.

## Honest verification status
- ZIP integrity check: passed.
- Android compilation: not run in this environment (no configured Android SDK/Gradle build).
- Runtime and responsiveness tests: not run on a physical device.
- This release is a stability candidate, not a verified stable release until GitHub Actions and device checks pass.

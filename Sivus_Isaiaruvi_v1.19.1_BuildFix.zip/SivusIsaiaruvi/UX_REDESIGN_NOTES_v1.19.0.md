# Sivu's Isaiaruvi 1.19.0 — UX fixes

## Changes
- Added a prominent **Create playlist** action directly in Explore > Playlists, including when the playlist list is empty.
- Added persistent List/Grid layout selection to Explore > Albums, matching the album layout preference used by Library.
- Added a real Android date picker to Listening Insights instead of requiring manual `YYYY-MM-DD` typing.
- Improved custom-date action copy and touch target sizing.
- Preserved the existing no-fade navigation behavior and debounced Explore search input.
- Bumped Android version to 1.19.0 (versionCode 21).

## Verification status
- ZIP archive integrity should be checked after packaging.
- This environment does not have a configured Android SDK/Gradle wrapper, so a successful Android build and device test cannot be claimed.
- Tab-switch latency may still need profiling on-device. The current Activity rebuilds views and performs some collection grouping on the UI thread; a full asynchronous repository/adapter refactor is a separate performance task.

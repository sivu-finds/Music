# Sivu's Isaiaruvi

Android local music player project.

## Latest UX update: 1.19.0
- Explore > Playlists now includes a visible Create playlist button.
- Explore > Albums supports List/Grid display selection.
- Listening Insights custom dates use Android's calendar picker.

See `UX_REDESIGN_NOTES_v1.19.0.md` for changes and verification limits.

Build with Android Studio or the repository's configured GitHub Actions workflow. Do not treat ZIP integrity as proof of a successful Android build.

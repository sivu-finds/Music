# Sivu's Isaiaruvi 1.18.0 — screenshot-driven UX corrections

## Corrections in this candidate
- Fixed the Home heading so it uses a real line break instead of displaying the literal `\n`.
- Made the entire Made For Your Mood / Smart Shuffle card clickable and removed the cramped, almost invisible nested button.
- Added palette-aware dialog builders so dialogs use dark surfaces in dark mode and light surfaces in light mode. This applies to Song Radio, queue, collection menus, settings, playlist actions, similar-song dialogs, and shuffle choices.
- Styled the custom Insights date field explicitly for readable text, hint, padding, and surface colour.
- Increased spacing and touch height for Insights period selectors and corrected inactive label contrast.
- Bumped Android version to 1.18.0 / versionCode 20.

## Important known limits
- This is a source-level UI correction candidate, not a claim of zero lag. A real Android SDK build and Samsung device test are still required.
- The app still uses the existing Activity/MediaPlayer architecture. A full move to Media3/Compose and a measured background-library architecture would be a larger migration and is not represented as completed here.
- Similar Songs uses local metadata, not audio fingerprinting.
